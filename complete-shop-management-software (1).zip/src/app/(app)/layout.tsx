import type { ReactNode } from "react";
import { AppFrame } from "@/components/AppFrame";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  const shop = await getSettings();
  return (
    <AppFrame
      shop={{
        shopName: shop.shopName,
        logo: shop.logo,
        address: shop.address,
        mobile: shop.mobile,
        email: shop.email,
      }}
      username={user.name || user.username}
    >
      {children}
    </AppFrame>
  );
}
