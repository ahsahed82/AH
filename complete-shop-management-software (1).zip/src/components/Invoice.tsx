import type { Settings } from "@/db/schema";
import { formatAmount, formatDate, formatDateTime, formatMoney, formatQty } from "@/lib/format";
import { amountInWords } from "@/lib/number-words";

export type InvoiceSale = {
  id: number;
  invoiceNo: string;
  saleDate: Date | string;
  subtotal: string;
  discount: string;
  total: string;
  paid: string;
  due: string;
  paymentMethod: string;
  note: string | null;
};

export type InvoiceItem = {
  id: number;
  productName: string;
  sku: string | null;
  quantity: string;
  unitPrice: string;
  total: string;
};

export function Invoice({
  shop,
  sale,
  items,
  customer,
}: {
  shop: Settings;
  sale: InvoiceSale;
  items: InvoiceItem[];
  customer: { name: string; mobile: string | null; address: string | null } | null;
}) {
  const laterPaid = Math.max(
    0,
    Math.round((Number(sale.total) - Number(sale.paid) - Number(sale.due)) * 100) / 100,
  );

  return (
    <div className="print-sheet mx-auto w-full max-w-[210mm] bg-white p-6 text-slate-900 shadow-sm print:p-0 sm:p-8">
      <div className="flex flex-col gap-4 border-b-2 border-emerald-700 pb-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-3">
          {shop.showLogoOnPrint && shop.logo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={shop.logo} alt={`${shop.shopName} logo`} className="h-16 w-16 object-contain" />
          ) : null}
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-emerald-900 sm:text-2xl">{shop.shopName}</h1>
            {shop.address ? <p className="mt-0.5 max-w-xs text-xs text-slate-600">{shop.address}</p> : null}
            <p className="mt-0.5 text-xs text-slate-600">
              {shop.mobile ? `Mobile: ${shop.mobile}` : ""}
              {shop.mobile && shop.email ? " · " : ""}
              {shop.email ? `Email: ${shop.email}` : ""}
            </p>
            <p className="text-[11px] text-slate-500">Country: {shop.country} · Currency: BDT (৳)</p>
          </div>
        </div>
        <div className="text-left sm:text-right">
          <p className="inline-block rounded bg-emerald-700 px-3 py-1 text-sm font-bold uppercase tracking-widest text-white">
            Invoice
          </p>
          <table className="mt-2 ml-auto text-xs">
            <tbody>
              <tr>
                <td className="pr-3 text-slate-500">Invoice no</td>
                <td className="font-bold">{sale.invoiceNo}</td>
              </tr>
              <tr>
                <td className="pr-3 text-slate-500">Invoice date</td>
                <td className="font-semibold">{formatDate(sale.saleDate)}</td>
              </tr>
              <tr>
                <td className="pr-3 text-slate-500">Payment method</td>
                <td className="font-semibold">{sale.paymentMethod}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-lg border border-slate-200 p-3">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Bill to</p>
          <p className="mt-1 text-sm font-bold">{customer?.name ?? "Walk-in customer"}</p>
          {customer?.mobile ? <p className="text-xs text-slate-600">Mobile: {customer.mobile}</p> : null}
          {customer?.address ? <p className="text-xs text-slate-600">{customer.address}</p> : null}
        </div>
        <div className="rounded-lg border border-slate-200 p-3">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Amount in words</p>
          <p className="mt-1 text-xs font-medium capitalize text-slate-700">{amountInWords(Number(sale.total))}</p>
          <p className="mt-1 text-[11px] text-slate-500">
            Printed: {formatDateTime(new Date())} (Asia/Dhaka)
          </p>
        </div>
      </div>

      <div className="mt-4 overflow-hidden rounded-lg border border-slate-200">
        <table className="w-full border-collapse text-xs sm:text-sm">
          <thead>
            <tr className="bg-slate-100 text-left">
              <th className="px-2 py-2 font-semibold">SL</th>
              <th className="px-2 py-2 font-semibold">Product description</th>
              <th className="px-2 py-2 text-right font-semibold">Qty</th>
              <th className="px-2 py-2 text-right font-semibold">Unit price</th>
              <th className="px-2 py-2 text-right font-semibold">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className="print-avoid-break border-t border-slate-100">
                <td className="px-2 py-1.5 text-slate-500">{index + 1}</td>
                <td className="px-2 py-1.5">
                  <span className="font-medium">{item.productName}</span>
                  {item.sku ? <span className="ml-1 text-[10px] text-slate-400">({item.sku})</span> : null}
                </td>
                <td className="px-2 py-1.5 text-right">{formatQty(item.quantity)}</td>
                <td className="px-2 py-1.5 text-right">{formatAmount(item.unitPrice)}</td>
                <td className="px-2 py-1.5 text-right font-semibold">{formatAmount(item.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:justify-between">
        <div className="max-w-sm text-xs text-slate-600">
          {sale.note ? <p className="mb-1"><strong>Note:</strong> {sale.note}</p> : null}
          {shop.invoiceTerms ? <p className="text-[11px]">{shop.invoiceTerms}</p> : null}
          <div className="mt-6 border-t border-dashed border-slate-300 pt-1 text-[11px] text-slate-500">
            Customer signature
          </div>
        </div>
        <table className="min-w-[240px] text-sm">
          <tbody>
            <tr>
              <td className="py-0.5 pr-4 text-slate-600">Subtotal</td>
              <td className="py-0.5 text-right font-semibold">{formatMoney(sale.subtotal)}</td>
            </tr>
            <tr>
              <td className="py-0.5 pr-4 text-slate-600">Discount</td>
              <td className="py-0.5 text-right font-semibold text-rose-600">− {formatMoney(sale.discount)}</td>
            </tr>
            <tr className="border-t border-slate-300">
              <td className="py-1 pr-4 font-bold">Grand total</td>
              <td className="py-1 text-right font-bold">{formatMoney(sale.total)}</td>
            </tr>
            <tr>
              <td className="py-0.5 pr-4 text-slate-600">Paid (during sale)</td>
              <td className="py-0.5 text-right">{formatMoney(sale.paid)}</td>
            </tr>
            {laterPaid > 0 ? (
              <tr>
                <td className="py-0.5 pr-4 text-slate-600">Paid later</td>
                <td className="py-0.5 text-right">{formatMoney(laterPaid)}</td>
              </tr>
            ) : null}
            <tr className="border-t border-slate-300">
              <td className="py-1 pr-4 font-bold">Due</td>
              <td className="py-1 text-right font-bold text-rose-600">{formatMoney(sale.due)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-5 flex flex-col gap-3 border-t border-slate-200 pt-3 text-[11px] text-slate-500 sm:flex-row sm:items-end sm:justify-between">
        <p>{shop.invoiceNote || "Thank you for your business."}</p>
        <div className="text-center">
          <div className="mb-1 w-40 border-t border-slate-400" />
          <p>Authorised signature</p>
        </div>
      </div>
    </div>
  );
}
