"use client";

import { Icon } from "./icons";

export function PrintButton({ label = "Print report" }: { label?: string }) {
  return (
    <button type="button" className="btn btn-primary" onClick={() => window.print()}>
      <Icon name="print" className="h-4 w-4" /> {label}
    </button>
  );
}
