import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers, authSessions } from "@/db/schema";

export const SESSION_COOKIE = "shop_session";
const SESSION_DAYS = 30;

export type SessionUser = { id: number; username: string; name: string };

/* ------------------------------ password hashing ----------------------------- */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split("$");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

export function validateCredentials(username: unknown, password: unknown): { username: string; password: string } {
  const user = typeof username === "string" ? username.trim().toLowerCase() : "";
  const pass = typeof password === "string" ? password : "";
  if (!/^[a-z0-9._-]{3,30}$/.test(user)) {
    throw new Error("Username must be 3–30 characters (letters, numbers, dot, dash or underscore).");
  }
  if (pass.length < 8) throw new Error("Password must be at least 8 characters long.");
  if (pass.length > 200) throw new Error("Password is too long.");
  return { username: user, password: pass };
}

/* --------------------------------- sessions ---------------------------------- */
function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/**
 * Cookie policy:
 * - Production is always HTTPS here. We use SameSite=None + Secure so the
 *   session also works when the app is opened inside an embedded preview
 *   panel (iframe). SameSite=Lax cookies are silently dropped by browsers in
 *   that context, which made correct credentials appear to "not work".
 * - Development (plain http://localhost) uses Lax without Secure.
 * CSRF is mitigated by requiring JSON content-type on state-changing APIs
 * (cross-site HTML forms cannot send application/json).
 */
function sessionCookieOptions() {
  const production = process.env.NODE_ENV === "production";
  return {
    httpOnly: true,
    sameSite: production ? ("none" as const) : ("lax" as const),
    secure: production,
    path: "/",
  };
}

export async function createSession(userId: number): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(authSessions).values({ tokenHash: hashToken(token), userId, expiresAt });
  // Opportunistic cleanup of expired sessions.
  await db.delete(authSessions).where(lt(authSessions.expiresAt, new Date()));
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    ...sessionCookieOptions(),
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  });
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(authSessions).where(eq(authSessions.tokenHash, hashToken(token)));
  }
  store.set(SESSION_COOKIE, "", { ...sessionCookieOptions(), maxAge: 0 });
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [row] = await db
    .select({ id: adminUsers.id, username: adminUsers.username, name: adminUsers.name })
    .from(authSessions)
    .innerJoin(adminUsers, eq(authSessions.userId, adminUsers.id))
    .where(and(eq(authSessions.tokenHash, hashToken(token)), gt(authSessions.expiresAt, new Date())))
    .limit(1);
  return row ?? null;
}

export async function adminExists(): Promise<boolean> {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(adminUsers);
  return (row?.count ?? 0) > 0;
}

/** For server layouts/pages: redirects to /login (or /setup on first run). */
export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (user) return user;
  const exists = await adminExists();
  redirect(exists ? "/login" : "/setup");
}

export type ApiAuthResult =
  | { ok: true; user: SessionUser }
  | { ok: false; response: Response };

/** For API route handlers: returns 401 JSON when not signed in. */
export async function requireApiUser(): Promise<ApiAuthResult> {
  const user = await getSessionUser();
  if (user) return { ok: true, user };
  return {
    ok: false,
    response: Response.json(
      { error: "Authentication required. Please sign in again." },
      { status: 401 },
    ),
  };
}

/* ------------------------- simple login rate limiting ------------------------ */
const globalThrottle = globalThis as typeof globalThis & {
  __shopLoginAttempts?: Map<string, { count: number; lockedUntil: number }>;
};
const attempts = globalThrottle.__shopLoginAttempts ?? new Map();
globalThrottle.__shopLoginAttempts = attempts;

export function checkLoginThrottle(key: string): void {
  const entry = attempts.get(key);
  if (entry && entry.lockedUntil > Date.now()) {
    const seconds = Math.ceil((entry.lockedUntil - Date.now()) / 1000);
    throw new Error(`Too many failed attempts. Try again in ${seconds} seconds.`);
  }
}

export function recordLoginFailure(key: string): void {
  const entry = attempts.get(key) ?? { count: 0, lockedUntil: 0 };
  entry.count += 1;
  if (entry.count >= 5) {
    entry.lockedUntil = Date.now() + 30_000;
    entry.count = 0;
  }
  attempts.set(key, entry);
}

export function clearLoginFailures(key: string): void {
  attempts.delete(key);
}
