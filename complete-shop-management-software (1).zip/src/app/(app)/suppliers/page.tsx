import { getSuppliers } from "@/lib/queries";
import { PartyClient } from "@/components/PartyClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Suppliers" };

export default async function SuppliersPage() {
  const suppliers = await getSuppliers();
  return (
    <PartyClient
      mode="supplier"
      basePath="/suppliers"
      apiPath="/api/suppliers"
      rows={suppliers.map((supplier) => ({
        id: supplier.id,
        name: supplier.name,
        mobile: supplier.mobile,
        address: supplier.address,
        openingBalance: supplier.openingBalance,
        totalBusiness: supplier.totalPurchases,
        totalPaid: supplier.totalPaid,
        due: supplier.due,
        count: supplier.purchaseCount,
      }))}
    />
  );
}
