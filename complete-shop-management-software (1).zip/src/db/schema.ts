import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  timestamp,
  boolean,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------- Admin & auth -------------------------------- */
export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  name: text("name").notNull().default("Administrator"),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const authSessions = pgTable("auth_sessions", {
  id: serial("id").primaryKey(),
  tokenHash: text("token_hash").notNull().unique(),
  userId: integer("user_id")
    .notNull()
    .references(() => adminUsers.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ---------------------------------- Settings --------------------------------- */
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  shopName: text("shop_name").notNull().default("My Retail Shop"),
  logo: text("logo"),
  address: text("address").notNull().default(""),
  mobile: text("mobile").notNull().default(""),
  email: text("email").notNull().default(""),
  country: text("country").notNull().default("Bangladesh"),
  currency: text("currency").notNull().default("BDT"),
  timezone: text("timezone").notNull().default("Asia/Dhaka"),
  dateFormat: text("date_format").notNull().default("DD-MM-YYYY"),
  invoicePrefix: text("invoice_prefix").notNull().default("INV"),
  purchasePrefix: text("purchase_prefix").notNull().default("PUR"),
  invoiceNote: text("invoice_note").notNull().default("Thank you for shopping with us!"),
  invoiceTerms: text("invoice_terms").notNull().default("Goods sold are not returnable without the original invoice."),
  receiptFooter: text("receipt_footer").notNull().default("Thank you! Please visit again."),
  showLogoOnPrint: boolean("show_logo_on_print").notNull().default(true),
  lowStockThresholdAlert: boolean("low_stock_alert").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* -------------------------------- Categories -------------------------------- */
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* --------------------------------- Products --------------------------------- */
export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    sku: text("sku").notNull().unique(),
    barcode: text("barcode").unique(),
    categoryId: integer("category_id").references(() => categories.id, {
      onDelete: "set null",
    }),
    unit: text("unit").notNull().default("pcs"),
    purchasePrice: numeric("purchase_price", { precision: 14, scale: 2 })
      .notNull()
      .default("0"),
    sellingPrice: numeric("selling_price", { precision: 14, scale: 2 })
      .notNull()
      .default("0"),
    currentStock: numeric("current_stock", { precision: 14, scale: 3 })
      .notNull()
      .default("0"),
    minStock: numeric("min_stock", { precision: 14, scale: 3 })
      .notNull()
      .default("0"),
    imageUrl: text("image_url"),
    description: text("description"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("products_name_idx").on(table.name)],
);

/* --------------------------------- Customers -------------------------------- */
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile"),
  address: text("address"),
  openingBalance: numeric("opening_balance", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* --------------------------------- Suppliers -------------------------------- */
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile"),
  address: text("address"),
  openingBalance: numeric("opening_balance", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ----------------------------------- Sales ---------------------------------- */
export const sales = pgTable(
  "sales",
  {
    id: serial("id").primaryKey(),
    invoiceNo: text("invoice_no").notNull().unique(),
    customerId: integer("customer_id").references(() => customers.id, {
      onDelete: "restrict",
    }),
    saleDate: timestamp("sale_date", { withTimezone: true }).notNull().defaultNow(),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    due: numeric("due", { precision: 14, scale: 2 }).notNull().default("0"),
    paymentMethod: text("payment_method").notNull().default("Cash"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sales_date_idx").on(table.saleDate)],
);

export const saleItems = pgTable("sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id")
    .notNull()
    .references(() => sales.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id, {
    onDelete: "restrict",
  }),
  productName: text("product_name").notNull(),
  sku: text("sku"),
  quantity: numeric("quantity", { precision: 14, scale: 3 }).notNull(),
  unitPrice: numeric("unit_price", { precision: 14, scale: 2 }).notNull(),
  costPrice: numeric("cost_price", { precision: 14, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 14, scale: 2 }).notNull(),
});

/* --------------------------------- Purchases -------------------------------- */
export const purchases = pgTable(
  "purchases",
  {
    id: serial("id").primaryKey(),
    purchaseNo: text("purchase_no").notNull().unique(),
    supplierId: integer("supplier_id").references(() => suppliers.id, {
      onDelete: "restrict",
    }),
    purchaseDate: timestamp("purchase_date", { withTimezone: true }).notNull().defaultNow(),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    due: numeric("due", { precision: 14, scale: 2 }).notNull().default("0"),
    paymentMethod: text("payment_method").notNull().default("Cash"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("purchases_date_idx").on(table.purchaseDate)],
);

export const purchaseItems = pgTable("purchase_items", {
  id: serial("id").primaryKey(),
  purchaseId: integer("purchase_id")
    .notNull()
    .references(() => purchases.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id, {
    onDelete: "restrict",
  }),
  productName: text("product_name").notNull(),
  sku: text("sku"),
  quantity: numeric("quantity", { precision: 14, scale: 3 }).notNull(),
  unitPrice: numeric("unit_price", { precision: 14, scale: 2 }).notNull(),
  total: numeric("total", { precision: 14, scale: 2 }).notNull(),
});

/* ----------------------------- Customer payments ---------------------------- */
export const customerPayments = pgTable("customer_payments", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id")
    .notNull()
    .references(() => customers.id, { onDelete: "cascade" }),
  saleId: integer("sale_id").references(() => sales.id, { onDelete: "set null" }),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  paymentMethod: text("payment_method").notNull().default("Cash"),
  paymentDate: timestamp("payment_date", { withTimezone: true }).notNull().defaultNow(),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ----------------------------- Supplier payments ---------------------------- */
export const supplierPayments = pgTable("supplier_payments", {
  id: serial("id").primaryKey(),
  supplierId: integer("supplier_id")
    .notNull()
    .references(() => suppliers.id, { onDelete: "cascade" }),
  purchaseId: integer("purchase_id").references(() => purchases.id, {
    onDelete: "set null",
  }),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  paymentMethod: text("payment_method").notNull().default("Cash"),
  paymentDate: timestamp("payment_date", { withTimezone: true }).notNull().defaultNow(),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* --------------------------------- Expenses --------------------------------- */
export const expenses = pgTable(
  "expenses",
  {
    id: serial("id").primaryKey(),
    category: text("category").notNull(),
    expenseDate: timestamp("expense_date", { withTimezone: true }).notNull().defaultNow(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    description: text("description"),
    paymentMethod: text("payment_method").notNull().default("Cash"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("expenses_date_idx").on(table.expenseDate)],
);

/* ------------------------------ Stock movements ----------------------------- */
export const stockMovements = pgTable(
  "stock_movements",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    type: text("type").notNull(), // opening | purchase | sale | adjustment | return | reversal
    quantity: numeric("quantity", { precision: 14, scale: 3 }).notNull(),
    referenceType: text("reference_type"),
    referenceId: integer("reference_id"),
    referenceNo: text("reference_no"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("stock_movements_product_idx").on(table.productId)],
);

export type Settings = typeof settings.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Customer = typeof customers.$inferSelect;
export type Supplier = typeof suppliers.$inferSelect;
export type Sale = typeof sales.$inferSelect;
export type SaleItem = typeof saleItems.$inferSelect;
export type Purchase = typeof purchases.$inferSelect;
export type PurchaseItem = typeof purchaseItems.$inferSelect;
export type Expense = typeof expenses.$inferSelect;
export type StockMovement = typeof stockMovements.$inferSelect;
export type CustomerPayment = typeof customerPayments.$inferSelect;
export type SupplierPayment = typeof supplierPayments.$inferSelect;
