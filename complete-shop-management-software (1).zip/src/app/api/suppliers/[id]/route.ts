import { eq, sql } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { purchases, suppliers } from "@/db/schema";
import { ApiError, fail, idFromParam, ok, optionalText, parseMoney, readJson, requiredText } from "@/lib/api-helpers";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const supplierId = idFromParam({ id });
    const body = await readJson(request);
    const [existing] = await db.select().from(suppliers).where(eq(suppliers.id, supplierId)).limit(1);
    if (!existing) throw new ApiError("Supplier not found.", 404);
    const [updated] = await db
      .update(suppliers)
      .set({
        name: requiredText(body.name ?? existing.name, "Supplier name", 120),
        mobile: body.mobile === undefined ? existing.mobile : optionalText(body.mobile, 30),
        address: body.address === undefined ? existing.address : optionalText(body.address, 400),
        openingBalance: money(parseMoney(body.openingBalance ?? existing.openingBalance, "Opening balance")),
        updatedAt: new Date(),
      })
      .where(eq(suppliers.id, supplierId))
      .returning();
    return ok({ supplier: updated, message: "Supplier updated." });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const supplierId = idFromParam({ id });
    const [used] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(purchases)
      .where(eq(purchases.supplierId, supplierId));
    if ((used?.count ?? 0) > 0) {
      throw new ApiError(
        "This supplier has purchase history and cannot be deleted. Deleting would break purchase and due history.",
        409,
      );
    }
    const deleted = await db.delete(suppliers).where(eq(suppliers.id, supplierId)).returning({ id: suppliers.id });
    if (deleted.length === 0) throw new ApiError("Supplier not found.", 404);
    return ok({ message: "Supplier deleted." });
  } catch (error) {
    return fail(error);
  }
}
