import {
  ArrowLeft,
  Banknote,
  BarChart3,
  Boxes,
  Check,
  Download,
  Eye,
  EyeOff,
  Factory,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Pencil,
  Plus,
  Printer,
  ReceiptText,
  RefreshCw,
  Save,
  Search,
  Settings,
  ShieldCheck,
  ShoppingCart,
  TriangleAlert,
  Trash2,
  Truck,
  Upload,
  UserRound,
  Users,
  Wallet,
  X,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";

type IconName =
  | "dashboard"
  | "pos"
  | "sales"
  | "purchases"
  | "products"
  | "inventory"
  | "customers"
  | "suppliers"
  | "expenses"
  | "reports"
  | "settings"
  | "plus"
  | "print"
  | "search"
  | "menu"
  | "close"
  | "download"
  | "upload"
  | "trash"
  | "edit"
  | "eye"
  | "eye-off"
  | "cash"
  | "warning"
  | "check"
  | "back"
  | "save"
  | "refresh"
  | "logout"
  | "user"
  | "key"
  | "shield";

const ICONS: Record<IconName, LucideIcon> = {
  dashboard: LayoutDashboard,
  pos: ShoppingCart,
  sales: ReceiptText,
  purchases: Truck,
  products: Package,
  inventory: Boxes,
  customers: Users,
  suppliers: Factory,
  expenses: Wallet,
  reports: BarChart3,
  settings: Settings,
  plus: Plus,
  print: Printer,
  search: Search,
  menu: Menu,
  close: X,
  download: Download,
  upload: Upload,
  trash: Trash2,
  edit: Pencil,
  eye: Eye,
  "eye-off": EyeOff,
  cash: Banknote,
  warning: TriangleAlert,
  check: Check,
  back: ArrowLeft,
  save: Save,
  refresh: RefreshCw,
  logout: LogOut,
  user: UserRound,
  key: KeyRound,
  shield: ShieldCheck,
};

export function Icon({
  name,
  className = "h-5 w-5",
  ...rest
}: { name: IconName; className?: string } & LucideProps) {
  const Component = ICONS[name];
  return <Component className={className} strokeWidth={1.8} aria-hidden="true" {...rest} />;
}

export type { IconName };
