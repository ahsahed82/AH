import { eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import {
  ApiError,
  fail,
  optionalText,
  ok,
  readJson,
  requiredText,
} from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

function validateLogo(value: unknown): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string") throw new ApiError("Invalid logo file.");
  if (!value.startsWith("data:image/")) throw new ApiError("Logo must be an uploaded image.");
  if (value.length > 2_500_000) throw new ApiError("Logo is too large. Please use an image under 1.8 MB.");
  return value;
}

export async function GET() {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    return ok(await getSettings());
  } catch (error) {
    return fail(error);
  }
}

export async function PUT(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson<Record<string, unknown>>(request);
    const current = await getSettings();

    const shopName = requiredText(body.shopName ?? current.shopName, "Shop name", 120);
    const email = optionalText(body.email, 160);
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new ApiError("Please enter a valid email address.");
    }

    const values = {
      shopName,
      logo: 'logo' in body ? validateLogo(body.logo) : current.logo,
      address: optionalText(body.address, 400) ?? "",
      mobile: optionalText(body.mobile, 40) ?? "",
      email: email ?? "",
      country: optionalText(body.country, 80) ?? "Bangladesh",
      currency: "BDT",
      timezone: "Asia/Dhaka",
      dateFormat: "DD-MM-YYYY",
      invoicePrefix: requiredText(body.invoicePrefix ?? current.invoicePrefix ?? "INV", "Invoice prefix", 12)
        .replace(/[^A-Za-z0-9-]/g, "")
        .toUpperCase() || "INV",
      purchasePrefix: requiredText(body.purchasePrefix ?? current.purchasePrefix ?? "PUR", "Purchase prefix", 12)
        .replace(/[^A-Za-z0-9-]/g, "")
        .toUpperCase() || "PUR",
      invoiceNote: optionalText(body.invoiceNote, 500) ?? "",
      invoiceTerms: optionalText(body.invoiceTerms, 1000) ?? "",
      receiptFooter: optionalText(body.receiptFooter, 300) ?? "",
      showLogoOnPrint: body.showLogoOnPrint !== false,
      lowStockThresholdAlert: body.lowStockThresholdAlert !== false,
      updatedAt: new Date(),
    };

    const [updated] = await db.update(settings).set(values).where(eq(settings.id, current.id)).returning();
    return ok({ settings: updated, message: "Settings saved successfully." });
  } catch (error) {
    return fail(error);
  }
}
