import Link from "next/link";
import { Icon } from "@/components/icons";
import { Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney, formatQty } from "@/lib/format";
import { getDashboard } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

function BarChart({
  data,
  valueKey,
  compareKey,
  height = 150,
}: {
  data: { label: string; sales: number; purchases?: number }[];
  valueKey: string;
  compareKey?: string;
  height?: number;
}) {
  const max = Math.max(
    1,
    ...data.map((d) =>
      Math.max(
        Number((d as unknown as Record<string, number>)[valueKey] ?? 0),
        compareKey ? Number((d as unknown as Record<string, number>)[compareKey] ?? 0) : 0,
      ),
    ),
  );
  return (
    <div className="flex items-end gap-2 sm:gap-4" style={{ height }}>
      {data.map((entry) => {
        const row = entry as unknown as Record<string, number>;
        const primary = Number(row[valueKey] ?? 0);
        const secondary = compareKey ? Number(row[compareKey] ?? 0) : 0;
        return (
          <div key={entry.label} className="flex h-full min-w-0 flex-1 flex-col justify-end gap-1">
            <div className="flex flex-1 items-end justify-center gap-1">
              <div
                className="w-full max-w-8 rounded-t bg-emerald-500/90 transition-all"
                style={{ height: `${Math.max(primary > 0 ? 4 : 0, (primary / max) * 100)}%` }}
                title={`Sales: ${formatMoney(primary)}`}
              />
              {compareKey ? (
                <div
                  className="w-full max-w-8 rounded-t bg-sky-300 transition-all"
                  style={{ height: `${Math.max(secondary > 0 ? 4 : 0, (secondary / max) * 100)}%` }}
                  title={`Purchases: ${formatMoney(secondary)}`}
                />
              ) : null}
            </div>
            <p className="truncate text-center text-[10px] text-slate-500">{entry.label}</p>
          </div>
        );
      })}
    </div>
  );
}

export default async function DashboardPage() {
  const [data, shop] = await Promise.all([getDashboard(), getSettings()]);
  const hasActivity = data.salesCount > 0 || data.purchaseCount > 0 || data.totalProducts > 0;

  return (
    <div>
      <PageHeader
        title={`Welcome to ${shop.shopName}`}
        subtitle={`${shop.address || "Shop address not set"} · Business date ${formatDate(new Date())} (Asia/Dhaka)`}
        actions={
          <>
            <Link href="/pos" className="btn btn-primary">
              <Icon name="plus" className="h-4 w-4" /> New Sale
            </Link>
            <Link href="/purchases/new" className="btn btn-secondary">
              <Icon name="purchases" className="h-4 w-4" /> New Purchase
            </Link>
            <Link href="/reports" className="btn btn-secondary">
              <Icon name="reports" className="h-4 w-4" /> Reports
            </Link>
          </>
        }
      />

      {!hasActivity ? (
        <div className="mb-5">
          <Card className="border-emerald-200 bg-emerald-50/60">
            <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-emerald-900">Your shop is ready for real data</p>
                <p className="text-xs text-emerald-800">
                  Start by adding products and your shop details in Settings. Every figure on this dashboard is
                  calculated from actual saved transactions — nothing here is demo data.
                </p>
              </div>
              <div className="flex gap-2">
                <Link href="/settings" className="btn btn-secondary btn-sm">Shop Settings</Link>
                <Link href="/products" className="btn btn-primary btn-sm">Add Products</Link>
              </div>
            </div>
          </Card>
        </div>
      ) : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
        <StatCard
          label="Today's Sales"
          value={formatMoney(data.todaySales)}
          hint={`${data.todaySalesCount} invoice(s) today`}
          tone="green"
          icon={<Icon name="pos" className="h-4 w-4" />}
        />
        <StatCard
          label="Total Sales"
          value={formatMoney(data.salesTotal)}
          hint={`${data.salesCount} invoice(s) all time`}
          tone="blue"
          icon={<Icon name="sales" className="h-4 w-4" />}
        />
        <StatCard
          label="Total Purchases"
          value={formatMoney(data.totalPurchases)}
          hint={`${data.purchaseCount} purchase(s)`}
          tone="violet"
          icon={<Icon name="purchases" className="h-4 w-4" />}
        />
        <StatCard
          label="Total Expenses"
          value={formatMoney(data.totalExpenses)}
          hint={`${formatMoney(data.monthExpenses)} this month`}
          tone="amber"
          icon={<Icon name="expenses" className="h-4 w-4" />}
        />
        <StatCard
          label="Net Profit"
          value={formatMoney(data.netProfit)}
          hint={`Gross ${formatMoney(data.grossProfit)} − expenses`}
          tone={data.netProfit >= 0 ? "green" : "red"}
          icon={<Icon name="reports" className="h-4 w-4" />}
        />
        <StatCard
          label="Stock Value (cost)"
          value={formatMoney(data.stockValue)}
          hint={`${formatQty(data.stockUnits)} units on hand`}
          tone="slate"
          icon={<Icon name="inventory" className="h-4 w-4" />}
        />
        <StatCard
          label="Customer Due"
          value={formatMoney(data.customerDue)}
          hint="Receivable from customers"
          tone="amber"
          icon={<Icon name="customers" className="h-4 w-4" />}
        />
        <StatCard
          label="Supplier Due"
          value={formatMoney(data.supplierDue)}
          hint="Payable to suppliers"
          tone="red"
          icon={<Icon name="suppliers" className="h-4 w-4" />}
        />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {[
          { label: "Products", value: String(data.totalProducts), href: "/products" },
          { label: "Customers", value: String(data.customerCount), href: "/customers" },
          { label: "Suppliers", value: String(data.supplierCount), href: "/suppliers" },
          { label: "Low Stock", value: String(data.lowStockCount), href: "/inventory?stock=low" },
          { label: "Out of Stock", value: String(data.outOfStockCount), href: "/inventory?stock=out" },
          { label: "This Month Sales", value: formatMoney(data.monthSales), href: "/reports" },
        ].map((item) => (
          <Link key={item.label} href={item.href} className="card px-3 py-2.5 transition hover:border-emerald-300">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{item.label}</p>
            <p className="mt-1 truncate text-sm font-bold tabular-nums text-slate-900">{item.value}</p>
          </Link>
        ))}
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Sales — last 7 days"
            subtitle="Actual daily sales totals in BDT"
            actions={<Badge tone="green">{formatMoney(data.days.reduce((s, d) => s + d.sales, 0))}</Badge>}
          />
          <div className="card-pad">
            <BarChart data={data.days} valueKey="sales" />
          </div>
        </Card>
        <Card>
          <CardHeader
            title="Sales vs purchases — last 6 months"
            subtitle="Monthly comparison"
            actions={
              <div className="flex items-center gap-3 text-[11px] text-slate-500">
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Sales</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-sky-300" /> Purchases</span>
              </div>
            }
          />
          <div className="card-pad">
            <BarChart data={data.months} valueKey="sales" compareKey="purchases" />
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Recent sales"
            subtitle="Latest invoices saved in the database"
            actions={<Link href="/sales" className="btn btn-secondary btn-sm">View all</Link>}
          />
          {data.recentSales.length === 0 ? (
            <EmptyState title="No sales yet" description="Create your first sale from the POS screen." />
          ) : (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Invoice</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th className="text-right">Total</th>
                    <th className="text-right">Due</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {data.recentSales.map((sale) => (
                    <tr key={sale.id}>
                      <td className="font-semibold text-slate-900">{sale.invoiceNo}</td>
                      <td className="whitespace-nowrap text-xs">{formatDateTime(sale.saleDate)}</td>
                      <td className="truncate">{sale.customerName ?? "Walk-in"}</td>
                      <td className="text-right font-medium">{formatMoney(sale.total)}</td>
                      <td className="text-right">
                        {Number(sale.due) > 0 ? (
                          <Badge tone="amber">{formatMoney(sale.due)}</Badge>
                        ) : (
                          <Badge tone="green">Paid</Badge>
                        )}
                      </td>
                      <td className="text-right">
                        <Link href={`/sales/${sale.id}`} className="text-xs font-semibold text-emerald-700 hover:underline">
                          View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <div className="flex flex-col gap-4">
          <Card>
            <CardHeader
              title="Low stock alerts"
              subtitle="At or below minimum stock"
              actions={<Link href="/inventory" className="btn btn-secondary btn-sm">Inventory</Link>}
            />
            {data.lowStockProducts.length === 0 ? (
              <EmptyState title="Stock levels look healthy" />
            ) : (
              <ul className="divide-y divide-slate-100">
                {data.lowStockProducts.map((product) => (
                  <li key={product.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-800">{product.name}</p>
                      <p className="text-[11px] text-slate-500">{product.sku}</p>
                    </div>
                    <Badge tone={Number(product.currentStock) <= 0 ? "red" : "amber"}>
                      {formatQty(product.currentStock)} / {formatQty(product.minStock)} {product.unit}
                    </Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Top products" subtitle="By revenue, all time" />
            {data.topProducts.length === 0 ? (
              <EmptyState title="No product sales yet" />
            ) : (
              <ul className="divide-y divide-slate-100">
                {data.topProducts.map((product) => (
                  <li key={product.name} className="flex items-center justify-between gap-3 px-4 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-800">{product.name}</p>
                      <p className="text-[11px] text-slate-500">{formatQty(product.qty)} sold</p>
                    </div>
                    <span className="text-sm font-semibold">{formatMoney(product.revenue)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      <Card className="mt-4">
        <CardHeader
          title="Module status"
          subtitle="Verified during this build. No placeholder screens remain."
        />
        <div className="grid gap-2 p-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            "Dashboard",
            "Products & Categories",
            "Inventory & Stock History",
            "POS / Sales & Invoices",
            "Purchases",
            "Customers & Payments",
            "Suppliers & Payments",
            "Expenses",
            "Reports & Print",
            "Invoice & Receipt Printing",
            "Settings (Bangladesh / BDT)",
            "Backup & Restore",
            "Admin Login & Security",
          ].map((module) => (
            <div key={module} className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2">
              <span className="grid h-5 w-5 place-items-center rounded-full bg-emerald-100 text-emerald-700">
                <Icon name="check" className="h-3.5 w-3.5" />
              </span>
              <span className="truncate text-xs font-medium text-slate-700">{module}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-slate-100 px-4 py-3 text-[11px] text-slate-500">
          All dashboard figures are calculated live from PostgreSQL records. There is no sample or hardcoded
          statistics anywhere in the application.
        </div>
      </Card>
    </div>
  );
}
