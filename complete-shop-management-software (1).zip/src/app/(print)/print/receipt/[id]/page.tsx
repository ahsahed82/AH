import { notFound } from "next/navigation";
import { Receipt } from "@/components/Receipt";
import { PrintToolbar } from "@/components/PrintToolbar";
import { getSale } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Print receipt" };

export default async function PrintReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const saleId = Number(id);
  if (!Number.isInteger(saleId)) notFound();
  const [data, shop] = await Promise.all([getSale(saleId), getSettings()]);
  if (!data) notFound();

  return (
    <div className="receipt-page mx-auto">
      <style>{`@media print { @page { size: 80mm auto; margin: 3mm; } }`}</style>
      <div className="print:hidden">
        <PrintToolbar title={`Receipt ${data.sale.invoiceNo} — 80mm thermal`} />
      </div>
      <Receipt
        shop={shop}
        sale={data.sale}
        items={data.items}
        customer={data.customerName ? { name: data.customerName, mobile: data.customerMobile } : null}
      />
    </div>
  );
}
