"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { ProductRow } from "@/lib/queries";
import { Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { Alert, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, jsonBody } from "@/lib/client";
import { formatDateTime, formatMoney, formatQty } from "@/lib/format";

type Movement = {
  id: number;
  productId: number;
  productName: string | null;
  sku: string | null;
  unit: string | null;
  type: string;
  quantity: string;
  referenceNo: string | null;
  note: string | null;
  createdAt: Date | string;
};

const TYPE_STYLES: Record<string, { tone: "green" | "red" | "amber" | "blue" | "slate"; label: string }> = {
  opening: { tone: "blue", label: "Opening" },
  purchase: { tone: "green", label: "Purchase" },
  sale: { tone: "red", label: "Sale" },
  adjustment: { tone: "amber", label: "Adjustment" },
  return: { tone: "green", label: "Return" },
  reversal: { tone: "slate", label: "Reversal" },
};

export function InventoryClient({
  products,
  movements,
  initialStock,
}: {
  products: ProductRow[];
  movements: Movement[];
  initialStock: string;
}) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [stockFilter, setStockFilter] = useState(initialStock);
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState("");
  const [mode, setMode] = useState<"in" | "out" | "set">("in");
  const [quantity, setQuantity] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [movementType, setMovementType] = useState("all");

  const selectedProduct = products.find((p) => String(p.id) === selectedProductId);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return products.filter((product) => {
      const current = Number(product.currentStock);
      const min = Number(product.minStock);
      if (stockFilter === "low" && !(current > 0 && current <= min)) return false;
      if (stockFilter === "out" && current > 0) return false;
      if (stockFilter === "in" && current <= min) return false;
      if (!term) return true;
      return `${product.name} ${product.sku} ${product.barcode ?? ""}`.toLowerCase().includes(term);
    });
  }, [products, search, stockFilter]);

  const filteredMovements = useMemo(
    () => movements.filter((m) => movementType === "all" || m.type === movementType),
    [movements, movementType],
  );

  const stockValue = products.reduce((sum, p) => sum + Number(p.currentStock) * Number(p.purchasePrice), 0);
  const lowCount = products.filter((p) => Number(p.currentStock) > 0 && Number(p.currentStock) <= Number(p.minStock)).length;
  const outCount = products.filter((p) => Number(p.currentStock) <= 0).length;

  async function saveAdjustment() {
    setBusy(true);
    setNotice(null);
    try {
      const result = await api<{ message: string }>("/api/stock", jsonBody({
        productId: Number(selectedProductId),
        mode,
        quantity,
        note,
      }));
      setNotice({ tone: "success", text: result.message });
      setAdjustOpen(false);
      setQuantity("");
      setNote("");
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Adjustment failed." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Inventory & Stock Movements"
        subtitle="Stock is updated automatically by sales, purchases and adjustments."
        actions={
          <button type="button" className="btn btn-primary" onClick={() => { setAdjustOpen(true); setNotice(null); }}>
            <Icon name="inventory" className="h-4 w-4" /> Stock adjustment
          </button>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Stock value (cost)" value={formatMoney(stockValue)} tone="green" />
        <StatCard label="Products tracked" value={String(products.length)} tone="blue" />
        <StatCard label="Low stock" value={String(lowCount)} tone="amber" />
        <StatCard label="Out of stock" value={String(outCount)} tone="red" />
      </div>

      <Card className="mt-4">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              className="input pl-9"
              placeholder="Search product or SKU…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <select className="select sm:w-48" value={stockFilter} onChange={(e) => setStockFilter(e.target.value)}>
            <option value="all">All stock levels</option>
            <option value="in">Healthy stock</option>
            <option value="low">Low stock</option>
            <option value="out">Out of stock</option>
          </select>
        </div>
        {filtered.length === 0 ? (
          <EmptyState title="No products match this filter" description="Add products first or change the filter." />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th className="text-right">Current stock</th>
                  <th className="text-right">Minimum</th>
                  <th className="text-right">Stock value</th>
                  <th>Status</th>
                  <th className="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((product) => {
                  const current = Number(product.currentStock);
                  const min = Number(product.minStock);
                  return (
                    <tr key={product.id}>
                      <td>
                        <p className="font-semibold text-slate-900">{product.name}</p>
                        <p className="text-[11px] text-slate-500">{product.sku} · {product.categoryName ?? "Uncategorised"}</p>
                      </td>
                      <td className="text-right font-semibold">
                        {formatQty(current)} <span className="text-xs font-normal text-slate-500 lowercase">{product.unit}</span>
                      </td>
                      <td className="text-right">{formatQty(min)}</td>
                      <td className="text-right">{formatMoney(current * Number(product.purchasePrice))}</td>
                      <td>
                        {current <= 0 ? (
                          <Badge tone="red">Out of stock</Badge>
                        ) : current <= min ? (
                          <Badge tone="amber">Low stock</Badge>
                        ) : (
                          <Badge tone="green">In stock</Badge>
                        )}
                      </td>
                      <td className="text-right">
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm"
                          onClick={() => {
                            setSelectedProductId(String(product.id));
                            setAdjustOpen(true);
                            setNotice(null);
                          }}
                        >
                          Adjust
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="mt-4">
        <CardHeader
          title="Stock movement history"
          subtitle="Every sale, purchase, adjustment and reversal is recorded here"
          actions={
            <select className="select w-40" value={movementType} onChange={(e) => setMovementType(e.target.value)}>
              <option value="all">All types</option>
              <option value="opening">Opening</option>
              <option value="purchase">Purchase</option>
              <option value="sale">Sale</option>
              <option value="adjustment">Adjustment</option>
              <option value="reversal">Reversal</option>
            </select>
          }
        />
        {filteredMovements.length === 0 ? (
          <EmptyState title="No stock movements yet" description="Movements appear after opening stock, purchases, sales or adjustments." />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date & time</th>
                  <th>Product</th>
                  <th>Type</th>
                  <th className="text-right">Quantity</th>
                  <th>Reference</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
                {filteredMovements.map((movement) => {
                  const style = TYPE_STYLES[movement.type] ?? TYPE_STYLES.adjustment;
                  const value = Number(movement.quantity);
                  return (
                    <tr key={movement.id}>
                      <td className="whitespace-nowrap text-xs">{formatDateTime(movement.createdAt)}</td>
                      <td>
                        <p className="font-medium text-slate-900">{movement.productName ?? "Deleted product"}</p>
                        <p className="text-[11px] text-slate-500">{movement.sku ?? "—"}</p>
                      </td>
                      <td><Badge tone={style.tone}>{style.label}</Badge></td>
                      <td className={`text-right font-semibold ${value < 0 ? "text-rose-600" : "text-emerald-700"}`}>
                        {value > 0 ? "+" : ""}{formatQty(value)} <span className="text-[11px] font-normal lowercase text-slate-500">{movement.unit}</span>
                      </td>
                      <td className="text-xs">{movement.referenceNo ?? "—"}</td>
                      <td className="max-w-[220px] truncate text-xs" title={movement.note ?? ""}>{movement.note ?? "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={adjustOpen}
        title="Stock adjustment"
        description="Record opening stock, stock in, stock out or a physical count correction."
        onClose={() => setAdjustOpen(false)}
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setAdjustOpen(false)}>Cancel</button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={saveAdjustment}
              disabled={busy || !selectedProductId || !quantity}
            >
              {busy ? "Saving…" : "Save adjustment"}
            </button>
          </>
        }
      >
        {notice && notice.tone === "error" ? <div className="mb-3"><Alert tone="error">{notice.text}</Alert></div> : null}
        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="adjust-product">Product *</label>
            <select
              id="adjust-product"
              className="select"
              value={selectedProductId}
              onChange={(e) => setSelectedProductId(e.target.value)}
            >
              <option value="">Select a product</option>
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.name} ({formatQty(product.currentStock)} {product.unit} available)
                </option>
              ))}
            </select>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="adjust-mode">Adjustment type</label>
              <select
                id="adjust-mode"
                className="select"
                value={mode}
                onChange={(e) => setMode(e.target.value as "in" | "out" | "set")}
              >
                <option value="in">Stock in (add)</option>
                <option value="out">Stock out (remove)</option>
                <option value="set">Set exact stock (count)</option>
              </select>
            </div>
            <div>
              <label className="label" htmlFor="adjust-qty">
                {mode === "set" ? "Counted quantity *" : "Quantity *"}
              </label>
              <input
                id="adjust-qty"
                className="input"
                type="number"
                min="0"
                step="0.001"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
          </div>
          {selectedProduct ? (
            <p className="rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-600">
              Current: <strong>{formatQty(selectedProduct.currentStock)} {selectedProduct.unit}</strong>
              {quantity ? (
                <>
                  {" → "}New:{" "}
                  <strong>
                    {formatQty(
                      mode === "in"
                        ? Number(selectedProduct.currentStock) + Number(quantity || 0)
                        : mode === "out"
                          ? Number(selectedProduct.currentStock) - Number(quantity || 0)
                          : Number(quantity || 0),
                    )}{" "}
                    {selectedProduct.unit}
                  </strong>
                </>
              ) : null}
            </p>
          ) : null}
          <div>
            <label className="label" htmlFor="adjust-note">Reason / note</label>
            <input
              id="adjust-note"
              className="input"
              placeholder="e.g. Opening stock, damaged goods, physical count"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
