import { eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, purchaseItems, purchases, stockMovements } from "@/db/schema";
import { getPurchase } from "@/lib/queries";
import { ApiError, fail, idFromParam, ok } from "@/lib/api-helpers";
import { qty } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const purchase = await getPurchase(idFromParam({ id }));
    if (!purchase) throw new ApiError("Purchase not found.", 404);
    return ok({ purchase });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const purchaseId = idFromParam({ id });
    const purchaseNo = await db.transaction(async (tx) => {
      const [purchase] = await tx.select().from(purchases).where(eq(purchases.id, purchaseId)).limit(1).for("update");
      if (!purchase) throw new ApiError("Purchase not found.", 404);
      const items = await tx.select().from(purchaseItems).where(eq(purchaseItems.purchaseId, purchaseId));

      for (const item of items) {
        if (!item.productId) continue;
        const [product] = await tx
          .select({ id: products.id, name: products.name, unit: products.unit, currentStock: products.currentStock })
          .from(products)
          .where(eq(products.id, item.productId))
          .limit(1)
          .for("update");
        if (!product) continue;
        if (Number(product.currentStock) < Number(item.quantity)) {
          throw new ApiError(
            `Cannot delete this purchase because ${product.name} stock has already been sold. Current stock: ${Number(product.currentStock)} ${product.unit ?? ""}. Reduce stock manually first.`,
            409,
          );
        }
        await tx
          .update(products)
          .set({
            currentStock: qty(Number(product.currentStock) - Number(item.quantity)),
            updatedAt: new Date(),
          })
          .where(eq(products.id, product.id));
        await tx.insert(stockMovements).values({
          productId: product.id,
          type: "reversal",
          quantity: qty(-Number(item.quantity)),
          referenceType: "purchase_delete",
          referenceId: purchase.id,
          referenceNo: purchase.purchaseNo,
          note: "Purchase deleted — stock removed",
        });
      }

      await tx.delete(purchases).where(eq(purchases.id, purchaseId));
      return purchase.purchaseNo;
    });

    return ok({ message: `${purchaseNo} deleted and stock has been reversed.` });
  } catch (error) {
    return fail(error);
  }
}
