import { sql } from "drizzle-orm";
import type { PgTable } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  adminUsers,
  categories,
  customerPayments,
  customers,
  expenses,
  products,
  purchaseItems,
  purchases,
  saleItems,
  sales,
  settings,
  stockMovements,
  supplierPayments,
  suppliers,
} from "@/db/schema";

export const BACKUP_APP = "shop-management-bd";
export const BACKUP_VERSION = 1;

type RestoreTable = {
  key: string;
  table: PgTable;
  dateColumns: string[];
  dbName: string;
};

/** Insert order respects foreign-key dependencies. */
export const RESTORE_TABLES: RestoreTable[] = [
  { key: "adminUsers", table: adminUsers, dateColumns: ["createdAt"], dbName: "admin_users" },
  { key: "settings", table: settings, dateColumns: ["updatedAt"], dbName: "settings" },
  { key: "categories", table: categories, dateColumns: ["createdAt"], dbName: "categories" },
  { key: "customers", table: customers, dateColumns: ["createdAt", "updatedAt"], dbName: "customers" },
  { key: "suppliers", table: suppliers, dateColumns: ["createdAt", "updatedAt"], dbName: "suppliers" },
  { key: "products", table: products, dateColumns: ["createdAt", "updatedAt"], dbName: "products" },
  { key: "purchases", table: purchases, dateColumns: ["purchaseDate", "createdAt"], dbName: "purchases" },
  {
    key: "purchaseItems",
    table: purchaseItems,
    dateColumns: [],
    dbName: "purchase_items",
  },
  { key: "sales", table: sales, dateColumns: ["saleDate", "createdAt"], dbName: "sales" },
  { key: "saleItems", table: saleItems, dateColumns: [], dbName: "sale_items" },
  {
    key: "customerPayments",
    table: customerPayments,
    dateColumns: ["paymentDate", "createdAt"],
    dbName: "customer_payments",
  },
  {
    key: "supplierPayments",
    table: supplierPayments,
    dateColumns: ["paymentDate", "createdAt"],
    dbName: "supplier_payments",
  },
  { key: "expenses", table: expenses, dateColumns: ["expenseDate", "createdAt"], dbName: "expenses" },
  {
    key: "stockMovements",
    table: stockMovements,
    dateColumns: ["createdAt"],
    dbName: "stock_movements",
  },
];

/**
 * adminUsers is optional so backups made before authentication was enabled
 * (v1) can still be restored — in that case the current admin account is kept.
 * Login sessions are never included in backups.
 */
export const REQUIRED_KEYS = RESTORE_TABLES.map((t) => t.key).filter((key) => key !== "adminUsers");

export type BackupPayload = {
  meta: {
    app: string;
    version: number;
    exportedAt: string;
    shopName: string;
    currency: string;
    timezone: string;
    counts: Record<string, number>;
  };
  data: Record<string, Record<string, unknown>[]>;
};

export async function buildBackup(): Promise<BackupPayload> {
  const [
    adminRows,
    settingsRows,
    categoryRows,
    customerRows,
    supplierRows,
    productRows,
    purchaseRows,
    purchaseItemRows,
    salesRows,
    saleItemRows,
    customerPaymentRows,
    supplierPaymentRows,
    expenseRows,
    stockMovementRows,
  ] = await Promise.all([
    db.select().from(adminUsers),
    db.select().from(settings),
    db.select().from(categories),
    db.select().from(customers),
    db.select().from(suppliers),
    db.select().from(products),
    db.select().from(purchases),
    db.select().from(purchaseItems),
    db.select().from(sales),
    db.select().from(saleItems),
    db.select().from(customerPayments),
    db.select().from(supplierPayments),
    db.select().from(expenses),
    db.select().from(stockMovements),
  ]);

  const data = {
    adminUsers: adminRows,
    settings: settingsRows,
    categories: categoryRows,
    customers: customerRows,
    suppliers: supplierRows,
    products: productRows,
    purchases: purchaseRows,
    purchaseItems: purchaseItemRows,
    sales: salesRows,
    saleItems: saleItemRows,
    customerPayments: customerPaymentRows,
    supplierPayments: supplierPaymentRows,
    expenses: expenseRows,
    stockMovements: stockMovementRows,
  };

  const counts = Object.fromEntries(
    Object.entries(data).map(([key, rows]) => [key, rows.length]),
  );

  const shopName = settingsRows[0]?.shopName ?? "Shop";

  return {
    meta: {
      app: BACKUP_APP,
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      shopName,
      currency: "BDT",
      timezone: "Asia/Dhaka",
      counts,
    },
    data: data as unknown as BackupPayload["data"],
  };
}

/** Validate a parsed backup file before touching the database. */
export function validateBackup(payload: unknown): BackupPayload {
  if (!payload || typeof payload !== "object") {
    throw new Error("The selected file is not a valid JSON backup.");
  }
  const candidate = payload as Partial<BackupPayload>;
  if (!candidate.meta || candidate.meta.app !== BACKUP_APP) {
    throw new Error("This file was not created by this shop management application.");
  }
  const version = Number(candidate.meta.version);
  if (!Number.isFinite(version) || version < 1) throw new Error("Backup version is missing.");
  if (version > BACKUP_VERSION) {
    throw new Error(
      `This backup was created by a newer version (v${version}). This application supports v${BACKUP_VERSION}.`,
    );
  }
  if (!candidate.data || typeof candidate.data !== "object") {
    throw new Error("The backup file does not contain any data section.");
  }
  for (const key of REQUIRED_KEYS) {
    const rows = (candidate.data as Record<string, unknown>)[key];
    if (!Array.isArray(rows)) throw new Error(`Backup is incomplete: "${key}" is missing.`);
  }
  const adminRows = (candidate.data as Record<string, unknown>).adminUsers;
  if (adminRows !== undefined && !Array.isArray(adminRows)) {
    throw new Error('Backup is invalid: "adminUsers" must be a list.');
  }
  return candidate as BackupPayload;
}

function reviveDates(row: Record<string, unknown>, dateColumns: string[]) {
  const next: Record<string, unknown> = { ...row };
  for (const column of dateColumns) {
    const value = next[column];
    if (typeof value === "string" && value) {
      const parsed = new Date(value);
      if (Number.isNaN(parsed.getTime())) delete next[column];
      else next[column] = parsed;
    }
  }
  return next;
}

/**
 * Replace all business data in a single transaction. If anything fails the
 * transaction rolls back, so a partial restore can never be committed.
 */
export async function restoreBackup(payload: BackupPayload) {
  return db.transaction(async (tx) => {
    const hasAdminSection = Array.isArray(payload.data.adminUsers);
    // Remove existing rows in reverse dependency order.
    for (const definition of [...RESTORE_TABLES].reverse()) {
      // Never delete the admin account when the backup has no admin section.
      if (definition.key === "adminUsers" && !hasAdminSection) continue;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await tx.delete(definition.table as any);
    }

    const restored: Record<string, number> = {};

    for (const definition of RESTORE_TABLES) {
      const rows = payload.data[definition.key];
      // Older backups have no admin account section: keep the current login.
      if (definition.key === "adminUsers" && !Array.isArray(rows)) {
        restored[definition.key] = 0;
        continue;
      }
      if (!rows || rows.length === 0) {
        restored[definition.key] = 0;
        continue;
      }
      const values = rows.map((row) => reviveDates(row, definition.dateColumns));
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await tx.insert(definition.table as any).values(values as any);
      restored[definition.key] = values.length;
    }

    // Realign serial sequences so new records do not collide with restored ids.
    for (const definition of RESTORE_TABLES) {
      if (definition.key === "adminUsers" && !hasAdminSection) continue;
      await tx.execute(
        // Table names come from a fixed allow-list, never from user input.
        sql.raw(
          `select setval(pg_get_serial_sequence('${definition.dbName}', 'id'), coalesce((select max(id) from ${definition.dbName}), 1), (select count(*) > 0 from ${definition.dbName}))`,
        ),
      );
    }

    return restored;
  });
}
