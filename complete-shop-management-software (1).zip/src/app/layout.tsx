import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Bricolage_Grotesque, Hind_Siliguri } from "next/font/google";
import "./globals.css";

const displayFont = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const bodyFont = Hind_Siliguri({
  subsets: ["latin", "bengali"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Shop Management",
    template: "%s · Shop Management",
  },
  description:
    "Bangladesh retail shop management: point of sale, inventory, purchases, customers, suppliers, expenses, reports and backups.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-BD" className={`${displayFont.variable} ${bodyFont.variable}`}>
      <body className="min-h-screen bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
