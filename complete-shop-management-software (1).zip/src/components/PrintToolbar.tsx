"use client";

import { useRouter } from "next/navigation";
import { Icon } from "./icons";

export function PrintToolbar({ title }: { title: string }) {
  const router = useRouter();
  return (
    <div className="no-print mx-auto mb-3 flex max-w-[210mm] flex-wrap items-center justify-between gap-2 px-2">
      <div>
        <p className="text-sm font-semibold text-slate-800">{title}</p>
        <p className="text-[11px] text-slate-500">
          Use your browser print dialog. Margins: default · Background graphics: on.
        </p>
      </div>
      <div className="flex gap-2">
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => router.back()}>
          <Icon name="back" className="h-4 w-4" /> Back
        </button>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => window.close()}>
          Close
        </button>
        <button type="button" className="btn btn-primary btn-sm" onClick={() => window.print()}>
          <Icon name="print" className="h-4 w-4" /> Print
        </button>
      </div>
    </div>
  );
}
