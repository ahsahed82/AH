"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert } from "@/components/Modal";
import { api, jsonBody } from "@/lib/client";
import { formatMoney, todayDhaka } from "@/lib/format";

const METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer"];

export function PaymentForm({
  kind,
  partyId,
  partyName,
  due,
}: {
  kind: "customer" | "supplier";
  partyId: number;
  partyName: string;
  due: number;
}) {
  const router = useRouter();
  const [amount, setAmount] = useState(due > 0 ? due.toFixed(2) : "");
  const [method, setMethod] = useState("Cash");
  const [paymentDate, setPaymentDate] = useState(todayDhaka());
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function save() {
    setBusy(true);
    setNotice(null);
    try {
      const result = await api<{ message: string }>("/api/payments", jsonBody({
        kind,
        customerId: kind === "customer" ? partyId : undefined,
        supplierId: kind === "supplier" ? partyId : undefined,
        amount,
        paymentMethod: method,
        paymentDate,
        note,
      }));
      setNotice({ tone: "success", text: result.message });
      setAmount("");
      setNote("");
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Payment failed." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3 p-4">
      {notice ? <Alert tone={notice.tone}>{notice.text}</Alert> : null}
      {due <= 0 ? (
        <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {partyName} has no outstanding due. Payments are blocked to keep balances accurate.
        </p>
      ) : (
        <>
          <div className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-900">
            Current due: <strong>{formatMoney(due)}</strong>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="payment-amount">Amount (৳)</label>
              <input
                id="payment-amount"
                type="number"
                min="0.01"
                max={due}
                step="0.01"
                className="input"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="payment-method">Payment method</label>
              <select id="payment-method" className="select" value={method} onChange={(e) => setMethod(e.target.value)}>
                {METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="payment-date">Payment date</label>
              <input id="payment-date" type="date" className="input" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="payment-note">Note</label>
              <input id="payment-note" className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional" />
            </div>
          </div>
          <button type="button" className="btn btn-primary w-full" onClick={save} disabled={busy || !amount}>
            {busy ? "Saving…" : `Record ${kind} payment`}
          </button>
        </>
      )}
    </div>
  );
}
