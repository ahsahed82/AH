import { redirect } from "next/navigation";
import { adminExists, getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { LoginClient } from "./LoginClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect("/");
  if (!(await adminExists())) redirect("/setup");
  const shop = await getSettings();
  return <LoginClient shopName={shop.shopName} logo={shop.logo} />;
}
