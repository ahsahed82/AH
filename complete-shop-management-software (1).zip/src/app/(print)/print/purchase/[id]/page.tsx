import { notFound } from "next/navigation";
import { PrintToolbar } from "@/components/PrintToolbar";
import { PurchaseDocument } from "@/components/PurchaseDocument";
import { getPurchase } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Print purchase" };

export default async function PrintPurchasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const purchaseId = Number(id);
  if (!Number.isInteger(purchaseId)) notFound();
  const [data, shop] = await Promise.all([getPurchase(purchaseId), getSettings()]);
  if (!data) notFound();

  return (
    <div>
      <PrintToolbar title={`Purchase ${data.purchase.purchaseNo} — A4`} />
      <PurchaseDocument
        shop={shop}
        purchase={data.purchase}
        items={data.items}
        supplier={data.supplierName ? { name: data.supplierName, mobile: data.supplierMobile, address: data.supplierAddress } : null}
      />
    </div>
  );
}
