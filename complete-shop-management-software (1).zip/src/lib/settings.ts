import { cache } from "react";
import { db } from "@/db";
import { settings, type Settings } from "@/db/schema";

export const DEFAULT_SETTINGS = {
  shopName: "My Retail Shop",
  address: "",
  mobile: "",
  email: "",
  country: "Bangladesh",
  currency: "BDT",
  timezone: "Asia/Dhaka",
  dateFormat: "DD-MM-YYYY",
};

/**
 * The settings row is the single source of truth for business identity.
 * A row is created lazily (id = 1) so the UI never renders an undefined shop.
 */
export const getSettings = cache(async (): Promise<Settings> => {
  const existing = await db.select().from(settings).limit(1);
  if (existing.length > 0) return existing[0];

  await db.insert(settings).values({ id: 1 }).onConflictDoNothing();
  const created = await db.select().from(settings).limit(1);
  if (created.length > 0) return created[0];

  return {
    id: 1,
    ...DEFAULT_SETTINGS,
    logo: null,
    invoicePrefix: "INV",
    purchasePrefix: "PUR",
    invoiceNote: "Thank you for shopping with us!",
    invoiceTerms: "Goods sold are not returnable without the original invoice.",
    receiptFooter: "Thank you! Please visit again.",
    showLogoOnPrint: true,
    lowStockThresholdAlert: true,
    updatedAt: new Date(),
  };
});
