"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Alert } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { Badge, PageHeader } from "@/components/ui";
import { api, jsonBody } from "@/lib/client";
import { formatMoney, formatQty } from "@/lib/format";

type PosProduct = {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  unit: string;
  sellingPrice: string;
  purchasePrice: string;
  currentStock: string;
};

type PosCustomer = { id: number; name: string; mobile: string | null; due: string };
type CartLine = { productId: number; name: string; unit: string; price: number; quantity: number; stock: number };
type SavedSale = { id: number; invoiceNo: string; total: number; paid: number; due: number };

const PAYMENT_METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer", "Credit"];

export function PosClient({
  products,
  customers,
  defaultDate,
  shopName,
}: {
  products: PosProduct[];
  customers: PosCustomer[];
  defaultDate: string;
  shopName: string;
}) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [saleDate, setSaleDate] = useState(defaultDate);
  const [discount, setDiscount] = useState("");
  const [paidAmount, setPaidAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [savedSale, setSavedSale] = useState<SavedSale | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const filteredProducts = useMemo(() => {
    const term = search.trim().toLowerCase();
    const list = products.filter((product) => !term || product.name.toLowerCase().includes(term) || product.sku.toLowerCase().includes(term) || (product.barcode ?? "").toLowerCase().includes(term));
    return list.slice(0, 24);
  }, [products, search]);

  const subtotal = useMemo(
    () => Math.round(cart.reduce((sum, line) => sum + line.quantity * line.price, 0) * 100) / 100,
    [cart],
  );
  const discountValue = Math.min(Math.max(Number(discount) || 0, 0), subtotal);
  const total = Math.round((subtotal - discountValue) * 100) / 100;
  const paid = Math.min(Math.max(Number(paidAmount) || 0, 0), total);
  const due = Math.round((total - paid) * 100) / 100;
  const selectedCustomer = customers.find((c) => String(c.id) === customerId);
  const totalUnits = cart.reduce((sum, line) => sum + line.quantity, 0);

  function addToCart(product: PosProduct) {
    setSavedSale(null);
    setNotice(null);
    if (Number(product.currentStock) <= 0) {
      setNotice({ tone: "error", text: `${product.name} is out of stock.` });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((line) => line.productId === product.id);
      if (existing) {
        if (existing.quantity + 1 > existing.stock) {
          setNotice({ tone: "error", text: `Only ${formatQty(existing.stock)} ${product.unit} of ${product.name} in stock.` });
          return prev;
        }
        return prev.map((line) =>
          line.productId === product.id ? { ...line, quantity: Math.round((line.quantity + 1) * 1000) / 1000 } : line,
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          unit: product.unit,
          price: Number(product.sellingPrice),
          quantity: 1,
          stock: Number(product.currentStock),
        },
      ];
    });
  }

  function handleBarcodeEnter(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key !== "Enter") return;
    event.preventDefault();
    const term = search.trim().toLowerCase();
    if (!term) return;
    const match = products.find(
      (p) => (p.barcode ?? "").toLowerCase() === term || p.sku.toLowerCase() === term,
    );
    if (match) {
      addToCart(match);
      setSearch("");
    }
  }

  function updateQuantity(productId: number, value: string) {
    const quantity = Number(value);
    setCart((prev) =>
      prev.map((line) => {
        if (line.productId !== productId) return line;
        if (!Number.isFinite(quantity) || quantity <= 0) return { ...line, quantity: 0.001 };
        if (quantity > line.stock) {
          setNotice({ tone: "error", text: `Only ${formatQty(line.stock)} ${line.unit} available for ${line.name}.` });
          return { ...line, quantity: line.stock };
        }
        return { ...line, quantity: Math.round(quantity * 1000) / 1000 };
      }),
    );
  }

  function updatePrice(productId: number, value: string) {
    const price = Number(value);
    setCart((prev) =>
      prev.map((line) => (line.productId === productId ? { ...line, price: Number.isFinite(price) && price >= 0 ? price : 0 } : line)),
    );
  }

  function resetCart() {
    setCart([]);
    setDiscount("");
    setPaidAmount("");
    setPaymentMethod("Cash");
    setNote("");
    setCustomerId("");
    setSaleDate(defaultDate);
    setSearch("");
  }

  async function saveSale() {
    if (cart.length === 0) {
      setNotice({ tone: "error", text: "Add at least one product to the cart." });
      return;
    }
    setSaving(true);
    setNotice(null);
    try {
      const result = await api<{ id: number; invoiceNo: string; total: number; paid: number; due: number; message: string }>(
        "/api/sales",
        jsonBody({
          customerId: customerId ? Number(customerId) : null,
          saleDate,
          items: cart.map((line) => ({ productId: line.productId, quantity: line.quantity, unitPrice: line.price })),
          discount: discountValue,
          paidAmount: paid,
          paymentMethod,
          note: note || null,
        }),
      );
      setSavedSale({ id: result.id, invoiceNo: result.invoiceNo, total: result.total, paid: result.paid, due: result.due });
      setNotice({ tone: "success", text: result.message });
      resetCart();
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Sale could not be saved." });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="New Sale (POS)"
        subtitle={`Selling for ${shopName} · prices in BDT (৳)`}
        actions={
          <Link href="/sales" className="btn btn-secondary">
            <Icon name="sales" className="h-4 w-4" /> Sales history
          </Link>
        }
      />

      {notice ? (
        <div className="mb-4">
          <Alert tone={notice.tone}>{notice.text}</Alert>
          {savedSale ? (
            <div className="mt-2 flex flex-wrap gap-2">
              <Link href={`/sales/${savedSale.id}`} className="btn btn-secondary btn-sm">
                <Icon name="eye" className="h-4 w-4" /> View invoice
              </Link>
              <Link href={`/print/sale/${savedSale.id}`} target="_blank" className="btn btn-secondary btn-sm">
                <Icon name="print" className="h-4 w-4" /> Print invoice (A4)
              </Link>
              <Link href={`/print/receipt/${savedSale.id}`} target="_blank" className="btn btn-primary btn-sm">
                <Icon name="print" className="h-4 w-4" /> Print receipt (80mm)
              </Link>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="space-y-4 xl:col-span-7">
          <div className="card p-4">
            <div className="relative">
              <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                ref={searchRef}
                className="input pl-9"
                placeholder="Search product name / SKU, or scan barcode and press Enter"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={handleBarcodeEnter}
              />
            </div>
            <p className="muted mt-2">
              {products.length} active product(s) · click a card to add to the cart
            </p>
            <div className="mt-3 grid max-h-[420px] grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
              {filteredProducts.length === 0 ? (
                <p className="col-span-full py-6 text-center text-sm text-slate-500">
                  No products found. {products.length === 0 ? "Add products first." : "Try another search."}
                </p>
              ) : (
                filteredProducts.map((product) => {
                  const stock = Number(product.currentStock);
                  return (
                    <button
                      key={product.id}
                      type="button"
                      onClick={() => addToCart(product)}
                      className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 p-2.5 text-left transition hover:border-emerald-400 hover:bg-emerald-50/50 disabled:opacity-50"
                      disabled={stock <= 0}
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-800">{product.name}</p>
                        <p className="text-[11px] text-slate-500">
                          {product.sku} · {formatQty(stock)} {product.unit} left
                        </p>
                      </div>
                      <span className="shrink-0 text-sm font-bold text-emerald-700">{formatMoney(product.sellingPrice)}</span>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>

        <div className="xl:col-span-5">
          <div className="card xl:sticky xl:top-20">
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
              <div>
                <h2 className="section-title">Current cart</h2>
                <p className="muted">{cart.length} item line(s) · {formatQty(totalUnits)} unit(s)</p>
              </div>
              {cart.length > 0 ? (
                <button type="button" className="btn btn-ghost btn-sm text-rose-600" onClick={resetCart}>
                  Clear
                </button>
              ) : null}
            </div>

            <div className="max-h-[300px] overflow-y-auto">
              {cart.length === 0 ? (
                <div className="empty-state">
                  <p className="text-sm font-semibold text-slate-600">Cart is empty</p>
                  <p className="text-xs">Search or tap a product to begin.</p>
                </div>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {cart.map((line) => (
                    <li key={line.productId} className="px-4 py-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-slate-800">{line.name}</p>
                          <p className="text-[11px] text-slate-500">
                            Stock {formatQty(line.stock)} {line.unit}
                          </p>
                        </div>
                        <button
                          type="button"
                          className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                          onClick={() => setCart((prev) => prev.filter((l) => l.productId !== line.productId))}
                          aria-label={`Remove ${line.name}`}
                        >
                          <Icon name="close" className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="mt-2 grid grid-cols-3 gap-2">
                        <div>
                          <label className="label">Qty</label>
                          <input
                            type="number"
                            min="0.001"
                            step="0.001"
                            className="input py-1.5"
                            value={line.quantity}
                            onChange={(e) => updateQuantity(line.productId, e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="label">Rate (৳)</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            className="input py-1.5"
                            value={line.price}
                            onChange={(e) => updatePrice(line.productId, e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="label">Line total</label>
                          <p className="pt-2 text-right text-sm font-semibold tabular-nums">{formatMoney(line.quantity * line.price)}</p>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-3 border-t border-slate-100 px-4 py-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="sale-customer">Customer</label>
                  <select id="sale-customer" className="select" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
                    <option value="">Walk-in customer</option>
                    {customers.map((customer) => (
                      <option key={customer.id} value={customer.id}>
                        {customer.name}{customer.mobile ? ` · ${customer.mobile}` : ""} (due ৳{Number(customer.due).toFixed(2)})
                      </option>
                    ))}
                  </select>
                  <p className="muted mt-1">
                    Walk-in sales cannot have a due. <Link href="/customers" className="text-emerald-700 underline">Add customer</Link>
                  </p>
                </div>
                <div>
                  <label className="label" htmlFor="sale-date">Sale date</label>
                  <input id="sale-date" type="date" className="input" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} />
                </div>
                <div>
                  <label className="label" htmlFor="sale-method">Payment method</label>
                  <select id="sale-method" className="select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                    {PAYMENT_METHODS.map((method) => <option key={method} value={method}>{method}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="sale-discount">Discount (৳)</label>
                  <input
                    id="sale-discount"
                    type="number"
                    min="0"
                    max={subtotal}
                    step="0.01"
                    className="input"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="label" htmlFor="sale-paid">Paid amount (৳)</label>
                  <input
                    id="sale-paid"
                    type="number"
                    min="0"
                    max={total}
                    step="0.01"
                    className="input"
                    value={paidAmount}
                    onChange={(e) => setPaidAmount(e.target.value)}
                    placeholder="0.00"
                  />
                  <div className="mt-1 flex gap-1">
                    <button type="button" className="text-[11px] font-semibold text-emerald-700 underline" onClick={() => setPaidAmount(String(total))}>
                      Full
                    </button>
                    <button type="button" className="text-[11px] font-semibold text-emerald-700 underline" onClick={() => setPaidAmount("0")}>
                      None
                    </button>
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="sale-note">Note</label>
                  <input id="sale-note" className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional note for this sale" />
                </div>
              </div>

              {!customerId && due > 0 ? (
                <Alert tone="warning">Select a customer to record this sale with {formatMoney(due)} due.</Alert>
              ) : null}
              {selectedCustomer && Number(selectedCustomer.due) > 0 ? (
                <p className="text-[11px] text-amber-700">
                  {selectedCustomer.name} already has an outstanding due of {formatMoney(selectedCustomer.due)}.
                </p>
              ) : null}

              <div className="rounded-xl bg-slate-50 p-3 text-sm">
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Subtotal</span><span className="font-semibold tabular-nums">{formatMoney(subtotal)}</span></div>
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Discount</span><span className="font-semibold tabular-nums text-rose-600">− {formatMoney(discountValue)}</span></div>
                <div className="mt-1 flex justify-between border-t border-slate-200 pt-2 text-base"><span className="font-semibold text-slate-900">Grand total</span><span className="font-bold tabular-nums text-slate-900">{formatMoney(total)}</span></div>
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Paid</span><span className="tabular-nums">{formatMoney(paid)}</span></div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-600">Due</span>
                  <span className={due > 0 ? "font-semibold text-rose-600" : "font-semibold text-emerald-700"}>{formatMoney(due)}</span>
                </div>
              </div>

              <button
                type="button"
                className="btn btn-primary w-full py-2.5 text-base"
                onClick={saveSale}
                disabled={saving || cart.length === 0 || (!customerId && due > 0)}
              >
                {saving ? "Saving sale…" : `Save sale · ${formatMoney(total)}`}
              </button>
              {savedSale ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs">
                  <p className="font-semibold text-emerald-900">Sale saved: {savedSale.invoiceNo}</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Link href={`/print/receipt/${savedSale.id}`} target="_blank" className="btn btn-secondary btn-sm">Receipt</Link>
                    <Link href={`/print/sale/${savedSale.id}`} target="_blank" className="btn btn-secondary btn-sm">Invoice</Link>
                    <Link href={`/sales/${savedSale.id}`} className="btn btn-ghost btn-sm">Details</Link>
                  </div>
                </div>
              ) : null}
              <p className="flex items-center gap-1 text-[11px] text-slate-500">
                <Badge tone="green">Stock safe</Badge> Stock decreases automatically when the sale is saved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
