import { eq, sql } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { ApiError, fail, idFromParam, ok, optionalText, readJson, requiredText } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const categoryId = idFromParam({ id });
    const body = await readJson(request);
    const name = requiredText(body.name, "Category name", 80);
    const [updated] = await db
      .update(categories)
      .set({ name, description: optionalText(body.description, 300) })
      .where(eq(categories.id, categoryId))
      .returning();
    if (!updated) throw new ApiError("Category not found.", 404);
    return ok({ category: updated, message: "Category updated." });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const categoryId = idFromParam({ id });
    const [used] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(products)
      .where(eq(products.categoryId, categoryId));
    if ((used?.count ?? 0) > 0) {
      throw new ApiError(
        `This category is used by ${used.count} product(s). Move those products to another category first.`,
        409,
      );
    }
    const deleted = await db.delete(categories).where(eq(categories.id, categoryId)).returning({ id: categories.id });
    if (deleted.length === 0) throw new ApiError("Category not found.", 404);
    return ok({ message: "Category deleted." });
  } catch (error) {
    return fail(error);
  }
}
