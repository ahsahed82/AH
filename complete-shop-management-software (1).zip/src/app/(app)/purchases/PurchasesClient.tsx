"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { Alert, ConfirmDialog } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, deleteRequest } from "@/lib/client";
import { formatDate, formatMoney } from "@/lib/format";

type PurchaseRow = {
  id: number;
  purchaseNo: string;
  purchaseDate: Date | string;
  supplierId: number | null;
  supplierName: string | null;
  supplierMobile: string | null;
  subtotal: string;
  discount: string;
  total: string;
  paid: string;
  due: string;
  paymentMethod: string;
  itemCount: number;
};

export function PurchasesClient({ purchases }: { purchases: PurchaseRow[] }) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [dueOnly, setDueOnly] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<PurchaseRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return purchases.filter((purchase) => {
      if (dueOnly && Number(purchase.due) <= 0) return false;
      if (term && !`${purchase.purchaseNo} ${purchase.supplierName ?? ""} ${purchase.supplierMobile ?? ""}`.toLowerCase().includes(term)) return false;
      if (from || to) {
        const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(purchase.purchaseDate));
        if (from && day < from) return false;
        if (to && day > to) return false;
      }
      return true;
    });
  }, [purchases, search, from, to, dueOnly]);

  const totals = filtered.reduce(
    (acc, row) => ({
      total: acc.total + Number(row.total),
      paid: acc.paid + Number(row.paid),
      due: acc.due + Number(row.due),
    }),
    { total: 0, paid: 0, due: 0 },
  );

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const result = await api<{ message: string }>(`/api/purchases/${deleteTarget.id}`, deleteRequest());
      setNotice({ tone: "success", text: result.message });
      setDeleteTarget(null);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Purchase could not be deleted." });
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Purchases"
        subtitle="Stock increases automatically when a purchase is saved"
        actions={
          <Link href="/purchases/new" className="btn btn-primary">
            <Icon name="plus" className="h-4 w-4" /> New Purchase
          </Link>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Purchases (filtered)" value={formatMoney(totals.total)} hint={`${filtered.length} record(s)`} tone="blue" />
        <StatCard label="Paid to suppliers" value={formatMoney(totals.paid)} tone="green" />
        <StatCard label="Outstanding due" value={formatMoney(totals.due)} tone="amber" />
        <StatCard label="Suppliers" value={String(new Set(purchases.map((p) => p.supplierId).filter(Boolean)).size)} tone="slate" />
      </div>

      <Card className="mt-4">
        <div className="grid gap-2 border-b border-slate-100 p-4 sm:grid-cols-2 lg:grid-cols-5">
          <div className="relative lg:col-span-2">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input className="input pl-9" placeholder="Search purchase no / supplier" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
          <input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <input type="checkbox" checked={dueOnly} onChange={(e) => setDueOnly(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
              Due only
            </label>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setSearch(""); setFrom(""); setTo(""); setDueOnly(false); }}>Clear</button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title={purchases.length === 0 ? "No purchases yet" : "No purchases match your filters"}
            description="Record a purchase to increase stock and track supplier dues."
            action={<Link href="/purchases/new" className="btn btn-primary btn-sm">New purchase</Link>}
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Purchase no</th>
                  <th>Date</th>
                  <th>Supplier</th>
                  <th className="text-right">Items</th>
                  <th className="text-right">Total</th>
                  <th className="text-right">Paid</th>
                  <th className="text-right">Due</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((purchase) => (
                  <tr key={purchase.id}>
                    <td>
                      <Link href={`/purchases/${purchase.id}`} className="font-semibold text-emerald-800 hover:underline">
                        {purchase.purchaseNo}
                      </Link>
                    </td>
                    <td className="whitespace-nowrap text-xs">{formatDate(purchase.purchaseDate)}</td>
                    <td className="truncate">{purchase.supplierName ?? "Cash purchase"}</td>
                    <td className="text-right">{purchase.itemCount}</td>
                    <td className="text-right font-semibold">{formatMoney(purchase.total)}</td>
                    <td className="text-right">{formatMoney(purchase.paid)}</td>
                    <td className="text-right">
                      {Number(purchase.due) > 0 ? <Badge tone="amber">{formatMoney(purchase.due)}</Badge> : <Badge tone="green">Paid</Badge>}
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-0.5">
                        <Link href={`/purchases/${purchase.id}`} className="btn btn-ghost btn-sm" title="View">
                          <Icon name="eye" className="h-4 w-4" />
                        </Link>
                        <Link href={`/print/purchase/${purchase.id}`} target="_blank" className="btn btn-ghost btn-sm" title="Print">
                          <Icon name="print" className="h-4 w-4" />
                        </Link>
                        <button type="button" className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50" onClick={() => setDeleteTarget(purchase)} title="Delete">
                          <Icon name="trash" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete purchase?"
        message={
          <>
            <p><strong>{deleteTarget?.purchaseNo}</strong> will be deleted and purchased quantities removed from stock.</p>
            <p className="mt-2 text-xs text-slate-500">
              Deletion is blocked if that stock has already been sold, so inventory can never go negative.
            </p>
          </>
        }
        confirmLabel="Delete purchase"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
