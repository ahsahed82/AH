"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, ConfirmDialog, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, deleteRequest, jsonBody } from "@/lib/client";
import { formatMoney, todayDhaka } from "@/lib/format";

const METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer"];

export function SaleActions({
  saleId,
  invoiceNo,
  total,
  due,
  customerId,
  customerName,
}: {
  saleId: number;
  invoiceNo: string;
  total: number;
  due: number;
  customerId: number | null;
  customerName: string | null;
}) {
  const router = useRouter();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [amount, setAmount] = useState(due > 0 ? due.toFixed(2) : "");
  const [method, setMethod] = useState("Cash");
  const [paymentDate, setPaymentDate] = useState(todayDhaka());
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function handleDelete() {
    setDeleting(true);
    try {
      const result = await api<{ message: string }>(`/api/sales/${saleId}`, deleteRequest());
      router.push(`/sales?deleted=1`);
      router.refresh();
      setNotice({ tone: "success", text: result.message });
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Delete failed." });
      setConfirmOpen(false);
    } finally {
      setDeleting(false);
    }
  }

  async function savePayment() {
    setBusy(true);
    setNotice(null);
    try {
      const result = await api<{ message: string }>("/api/payments", jsonBody({
        kind: "customer",
        customerId,
        saleId,
        amount,
        paymentMethod: method,
        paymentDate,
        note,
      }));
      setNotice({ tone: "success", text: result.message });
      setPaymentOpen(false);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Payment failed." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3">
      {notice ? <Alert tone={notice.tone}>{notice.text}</Alert> : null}
      {customerId && due > 0 ? (
        <button type="button" className="btn btn-primary w-full" onClick={() => setPaymentOpen(true)}>
          <Icon name="cash" className="h-4 w-4" /> Record customer payment
        </button>
      ) : null}
      {customerId && due > 0 ? (
        <p className="text-[11px] text-slate-500">
          Receive a payment from {customerName} against this invoice. This reduces the customer's outstanding due.
        </p>
      ) : null}
      <button
        type="button"
        className="btn btn-secondary w-full text-rose-600"
        onClick={() => setConfirmOpen(true)}
      >
        <Icon name="trash" className="h-4 w-4" /> Delete sale & return stock
      </button>
      <p className="text-[11px] text-slate-500">
        Deleting invoice {invoiceNo} restores {formatMoney(total)} of sales history and returns all items to stock.
      </p>

      <ConfirmDialog
        open={confirmOpen}
        title="Delete sale?"
        message={
          <>
            <p>Delete <strong>{invoiceNo}</strong> permanently?</p>
            <p className="mt-2 text-xs text-slate-500">
              Product stock will be returned and customer balances recalculated. Any payments already received stay
              recorded against the customer.
            </p>
          </>
        }
        confirmLabel="Delete sale"
        busy={deleting}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={handleDelete}
      />

      <Modal
        open={paymentOpen}
        title="Record customer payment"
        description={`Invoice ${invoiceNo}`}
        onClose={() => setPaymentOpen(false)}
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setPaymentOpen(false)}>Cancel</button>
            <button type="button" className="btn btn-primary" onClick={savePayment} disabled={busy || !amount}>
              {busy ? "Saving…" : "Save payment"}
            </button>
          </>
        }
      >
        {notice && notice.tone === "error" ? <div className="mb-3"><Alert tone="error">{notice.text}</Alert></div> : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="pay-amount">Amount (৳)</label>
            <input id="pay-amount" type="number" min="0.01" max={due} step="0.01" className="input" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <p className="muted mt-1">Invoice due: {formatMoney(due)}</p>
          </div>
          <div>
            <label className="label" htmlFor="pay-method">Payment method</label>
            <select id="pay-method" className="select" value={method} onChange={(e) => setMethod(e.target.value)}>
              {METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="pay-date">Payment date</label>
            <input id="pay-date" type="date" className="input" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="pay-note">Note</label>
            <input id="pay-note" className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional" />
          </div>
        </div>
      </Modal>
    </div>
  );
}
