"use client";

import { useState } from "react";
import { AuthShell } from "@/components/AuthShell";
import { Alert } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, jsonBody } from "@/lib/client";

export function LoginClient({ shopName, logo }: { shopName: string; logo: string | null }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState<"idle" | "checking" | "verified">("idle");
  const [error, setError] = useState<string | null>(null);
  const [cookieBlocked, setCookieBlocked] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setStage("checking");
    setError(null);
    setCookieBlocked(false);
    try {
      await api("/api/auth/login", jsonBody({ username, password }));
      // Verify the session cookie actually stuck in THIS browser before
      // redirecting — otherwise a blocked cookie looks like a silent loop.
      const me = await api<{ user: { username: string } | null }>("/api/auth/me");
      if (!me.user) {
        setCookieBlocked(true);
        setError(
          "Your username and password are correct, but this browser blocked the sign-in cookie. Open the app in its own browser tab (not inside a preview panel), allow cookies for this site, and sign in again.",
        );
        setBusy(false);
        setStage("idle");
        return;
      }
      setStage("verified");
      window.location.href = "/";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
      setBusy(false);
      setStage("idle");
    }
  }

  return (
    <AuthShell shopName={shopName} logo={logo} side="login">
      <div className="card p-6 sm:p-8">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[11px] font-semibold text-emerald-700 ring-1 ring-emerald-200">
          <Icon name="shield" className="h-3.5 w-3.5" /> Secure administrator sign in
        </span>
        <h2 className="font-display mt-3 text-2xl font-bold text-slate-900">Welcome back</h2>
        <p className="mt-1 text-sm text-slate-500">
          Sign in to open your dashboard, POS and reports.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {error ? <Alert tone="error">{error}</Alert> : null}
          <div>
            <label className="label" htmlFor="login-username">Username</label>
            <div className="relative">
              <Icon name="user" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="login-username"
                className="input pl-9"
                autoComplete="username"
                autoFocus
                placeholder="Your admin username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
          </div>
          <div>
            <label className="label" htmlFor="login-password">Password</label>
            <div className="relative">
              <Icon name="key" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="login-password"
                type={showPassword ? "text" : "password"}
                className="input pl-9 pr-10"
                autoComplete="current-password"
                placeholder="Your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                className="absolute right-2 top-2 rounded p-0.5 text-slate-400 hover:text-slate-600"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                <Icon name={showPassword ? "eye-off" : "eye"} className="h-4 w-4" />
              </button>
            </div>
          </div>
          <button type="submit" className="btn btn-primary w-full py-2.5 text-base" disabled={busy}>
            {stage === "verified" ? (
              <>
                <Icon name="check" className="h-4 w-4" /> Signed in — opening dashboard…
              </>
            ) : stage === "checking" ? (
              "Checking credentials…"
            ) : (
              "Sign in to my shop"
            )}
          </button>
        </form>

        {cookieBlocked ? (
          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
            <p className="font-semibold text-slate-700">Quick fix</p>
            <p className="mt-1">
              Copy this address into a new Chrome/Edge tab:{" "}
              <code className="rounded bg-white px-1 py-0.5 text-[11px] ring-1 ring-slate-200">
                {typeof window !== "undefined" ? window.location.origin : ""}/login
              </code>
            </p>
          </div>
        ) : null}

        <p className="mt-4 text-center text-xs text-slate-500">
          You stay signed in on this device for 30 days. Use <strong>Sign out</strong> on shared computers.
        </p>
      </div>
    </AuthShell>
  );
}
