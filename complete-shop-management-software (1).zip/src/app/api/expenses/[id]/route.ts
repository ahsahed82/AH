import { eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { expenses } from "@/db/schema";
import {
  ApiError,
  fail,
  idFromParam,
  ok,
  optionalText,
  parseMoney,
  parsePaymentMethod,
  readJson,
  requiredText,
} from "@/lib/api-helpers";
import { inputDateToDate, money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const expenseId = idFromParam({ id });
    const body = await readJson(request);
    const [existing] = await db.select().from(expenses).where(eq(expenses.id, expenseId)).limit(1);
    if (!existing) throw new ApiError("Expense not found.", 404);
    const [updated] = await db
      .update(expenses)
      .set({
        category: requiredText(body.category ?? existing.category, "Expense category", 80),
        amount: money(parseMoney(body.amount ?? existing.amount, "Amount", { min: 0.01 })),
        expenseDate: inputDateToDate(
          typeof body.expenseDate === "string" ? body.expenseDate : existing.expenseDate.toISOString().slice(0, 10),
        ),
        description: body.description === undefined ? existing.description : optionalText(body.description, 500),
        paymentMethod:
          body.paymentMethod === undefined ? existing.paymentMethod : parsePaymentMethod(body.paymentMethod),
      })
      .where(eq(expenses.id, expenseId))
      .returning();
    return ok({ expense: updated, message: "Expense updated." });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const expenseId = idFromParam({ id });
    const deleted = await db.delete(expenses).where(eq(expenses.id, expenseId)).returning({ id: expenses.id });
    if (deleted.length === 0) throw new ApiError("Expense not found.", 404);
    return ok({ message: "Expense deleted." });
  } catch (error) {
    return fail(error);
  }
}
