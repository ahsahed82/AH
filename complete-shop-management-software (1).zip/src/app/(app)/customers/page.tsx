import { getCustomers } from "@/lib/queries";
import { PartyClient } from "@/components/PartyClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Customers" };

export default async function CustomersPage() {
  const customers = await getCustomers();
  return (
    <PartyClient
      mode="customer"
      basePath="/customers"
      apiPath="/api/customers"
      rows={customers.map((customer) => ({
        id: customer.id,
        name: customer.name,
        mobile: customer.mobile,
        address: customer.address,
        openingBalance: customer.openingBalance,
        totalBusiness: customer.totalSales,
        totalPaid: customer.totalPaid,
        due: customer.due,
        count: customer.saleCount,
      }))}
    />
  );
}
