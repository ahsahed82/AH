import { getCategories, getProducts } from "@/lib/queries";
import { ProductsClient } from "./ProductsClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Products" };

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ stock?: string; category?: string; search?: string }>;
}) {
  const params = await searchParams;
  const [products, categories] = await Promise.all([getProducts(), getCategories()]);
  return (
    <ProductsClient
      products={products}
      categories={categories}
      initialStock={params.stock ?? "all"}
      initialCategory={params.category ?? "all"}
      initialSearch={params.search ?? ""}
    />
  );
}
