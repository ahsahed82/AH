import { eq, sql } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { customers, sales } from "@/db/schema";
import { ApiError, fail, idFromParam, ok, optionalText, parseMoney, readJson, requiredText } from "@/lib/api-helpers";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const customerId = idFromParam({ id });
    const body = await readJson(request);
    const [existing] = await db.select().from(customers).where(eq(customers.id, customerId)).limit(1);
    if (!existing) throw new ApiError("Customer not found.", 404);
    const [updated] = await db
      .update(customers)
      .set({
        name: requiredText(body.name ?? existing.name, "Customer name", 120),
        mobile: body.mobile === undefined ? existing.mobile : optionalText(body.mobile, 30),
        address: body.address === undefined ? existing.address : optionalText(body.address, 400),
        openingBalance: money(parseMoney(body.openingBalance ?? existing.openingBalance, "Opening balance")),
        updatedAt: new Date(),
      })
      .where(eq(customers.id, customerId))
      .returning();
    return ok({ customer: updated, message: "Customer updated." });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const customerId = idFromParam({ id });
    const [used] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sales)
      .where(eq(sales.customerId, customerId));
    if ((used?.count ?? 0) > 0) {
      throw new ApiError(
        "This customer has sales history and cannot be deleted. Deleting would break invoice and due history.",
        409,
      );
    }
    const deleted = await db.delete(customers).where(eq(customers.id, customerId)).returning({ id: customers.id });
    if (deleted.length === 0) throw new ApiError("Customer not found.", 404);
    return ok({ message: "Customer deleted." });
  } catch (error) {
    return fail(error);
  }
}
