import { getExpenses } from "@/lib/queries";
import { ExpensesClient } from "./ExpensesClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Expenses" };

export default async function ExpensesPage() {
  const expenses = await getExpenses();
  return <ExpensesClient expenses={expenses} />;
}
