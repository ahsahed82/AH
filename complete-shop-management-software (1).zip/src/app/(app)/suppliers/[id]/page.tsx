import Link from "next/link";
import { notFound } from "next/navigation";
import { Icon } from "@/components/icons";
import { PaymentForm } from "@/components/PaymentForm";
import { Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { getSupplierDetail } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata = { title: "Supplier details" };

export default async function SupplierDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supplierId = Number(id);
  if (!Number.isInteger(supplierId)) notFound();
  const data = await getSupplierDetail(supplierId);
  if (!data) notFound();
  const { supplier, purchases, payments, totals } = data;

  return (
    <div>
      <PageHeader
        title={supplier.name}
        subtitle={`${supplier.mobile ?? "No mobile"} · ${supplier.address ?? "No address"}`}
        actions={
          <>
            <Link href="/suppliers" className="btn btn-secondary"><Icon name="back" className="h-4 w-4" /> All suppliers</Link>
            <Link href="/purchases/new" className="btn btn-primary"><Icon name="plus" className="h-4 w-4" /> New purchase</Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Opening balance" value={formatMoney(supplier.openingBalance)} tone="slate" />
        <StatCard label="Total purchases" value={formatMoney(totals.totalPurchases)} hint={`${purchases.length} purchase(s)`} tone="blue" />
        <StatCard label="Total paid" value={formatMoney(totals.totalPaid)} tone="green" />
        <StatCard label="Current due" value={formatMoney(totals.due)} tone={totals.due > 0 ? "amber" : "green"} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-12">
        <div className="space-y-4 xl:col-span-8">
          <Card>
            <CardHeader title="Purchase history" />
            {purchases.length === 0 ? (
              <EmptyState title="No purchases yet" description="Purchases recorded from this supplier will appear here." />
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Purchase no</th>
                      <th>Date</th>
                      <th className="text-right">Total</th>
                      <th className="text-right">Paid</th>
                      <th className="text-right">Due</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {purchases.map((purchase) => (
                      <tr key={purchase.id}>
                        <td><Link href={`/purchases/${purchase.id}`} className="font-semibold text-emerald-800 hover:underline">{purchase.purchaseNo}</Link></td>
                        <td className="whitespace-nowrap text-xs">{formatDate(purchase.purchaseDate)}</td>
                        <td className="text-right">{formatMoney(purchase.total)}</td>
                        <td className="text-right">{formatMoney(purchase.paid)}</td>
                        <td className="text-right">{Number(purchase.due) > 0 ? <Badge tone="amber">{formatMoney(purchase.due)}</Badge> : <Badge tone="green">Paid</Badge>}</td>
                        <td className="text-right">
                          <Link href={`/print/purchase/${purchase.id}`} target="_blank" className="btn btn-ghost btn-sm"><Icon name="print" className="h-4 w-4" /></Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card>
            <CardHeader title="Payment history" subtitle="Payments made after the initial purchase payment" />
            {payments.length === 0 ? (
              <EmptyState title="No later payments" />
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Method</th>
                      <th className="text-right">Amount</th>
                      <th>Note</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((payment) => (
                      <tr key={payment.id}>
                        <td className="whitespace-nowrap text-xs">{formatDateTime(payment.paymentDate)}</td>
                        <td>{payment.paymentMethod}</td>
                        <td className="text-right font-semibold text-emerald-700">{formatMoney(payment.amount)}</td>
                        <td className="max-w-[220px] truncate text-xs">{payment.note ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        <div className="xl:col-span-4">
          <Card>
            <CardHeader title="Make payment" subtitle="Reduce this supplier's outstanding due" />
            <PaymentForm kind="supplier" partyId={supplier.id} partyName={supplier.name} due={Number(totals.due)} />
          </Card>
          <Card className="mt-4">
            <CardHeader title="Due calculation" />
            <div className="space-y-1 p-4 text-xs text-slate-600">
              <p className="flex justify-between"><span>Opening balance</span><span>{formatMoney(supplier.openingBalance)}</span></p>
              <p className="flex justify-between"><span>+ Purchases total</span><span>{formatMoney(totals.totalPurchases)}</span></p>
              <p className="flex justify-between"><span>− Paid at purchase</span><span>{formatMoney(totals.purchasePaid)}</span></p>
              <p className="flex justify-between"><span>− Later payments</span><span>{formatMoney(totals.laterPaid)}</span></p>
              <p className="mt-1 flex justify-between border-t border-slate-200 pt-1 text-sm font-bold text-slate-900"><span>= Current due</span><span>{formatMoney(totals.due)}</span></p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
