import { eq, or, sql } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, stockMovements } from "@/db/schema";
import { getProducts } from "@/lib/queries";
import {
  ApiError,
  fail,
  ok,
  optionalText,
  parseMoney,
  parseQuantity,
  readJson,
  requiredText,
} from "@/lib/api-helpers";
import { money, qty } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    const search = url.searchParams.get("search") ?? undefined;
    const categoryId = url.searchParams.get("categoryId");
    const stock = url.searchParams.get("stock") as "all" | "low" | "out" | "in" | null;
    const rows = await getProducts({
      search,
      categoryId: categoryId ? Number(categoryId) : undefined,
      stock: stock ?? "all",
    });
    return ok({ products: rows });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson(request);
    const name = requiredText(body.name, "Product name", 160);
    const sku = requiredText(body.sku, "SKU", 60);
    const barcode = optionalText(body.barcode, 60);
    const unit = requiredText(body.unit ?? "pcs", "Unit", 20);
    const purchasePrice = parseMoney(body.purchasePrice ?? 0, "Purchase price");
    const sellingPrice = parseMoney(body.sellingPrice ?? 0, "Selling price");
    const currentStock = parseQuantity(body.currentStock ?? 0, "Opening stock", { allowZero: true });
    const minStock = parseQuantity(body.minStock ?? 0, "Minimum stock", { allowZero: true });
    const categoryId = body.categoryId ? Number(body.categoryId) : null;
    if (categoryId !== null && !Number.isInteger(categoryId)) throw new ApiError("Invalid category.");
    const imageUrl = optionalText(body.imageUrl, 2_000_000);
    if (imageUrl && !imageUrl.startsWith("data:image/") && !/^https?:\/\//.test(imageUrl)) {
      throw new ApiError("Product image must be an uploaded image.");
    }

    const duplicate = await db
      .select({ id: products.id, sku: products.sku, barcode: products.barcode })
      .from(products)
      .where(barcode ? or(eq(products.sku, sku), eq(products.barcode, barcode)) : eq(products.sku, sku))
      .limit(1);
    if (duplicate.length > 0) {
      throw new ApiError(
        duplicate[0].sku === sku ? "This SKU is already used by another product." : "This barcode is already used by another product.",
        409,
      );
    }

    const created = await db.transaction(async (tx) => {
      const [product] = await tx
        .insert(products)
        .values({
          name,
          sku,
          barcode,
          categoryId,
          unit,
          purchasePrice: money(purchasePrice),
          sellingPrice: money(sellingPrice),
          currentStock: qty(currentStock),
          minStock: qty(minStock),
          imageUrl,
          description: optionalText(body.description, 2000),
        })
        .returning();
      if (currentStock > 0) {
        await tx.insert(stockMovements).values({
          productId: product.id,
          type: "opening",
          quantity: qty(currentStock),
          referenceType: "opening",
          note: "Opening stock",
        });
      }
      return product;
    });

    return ok({ product: created, message: `${created.name} added to products.` }, 201);
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE() {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  return fail(new ApiError("Bulk delete is not supported.", 405));
}

export async function HEAD() {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  await db.execute(sql`select 1`);
  return new Response(null, { status: 204 });
}
