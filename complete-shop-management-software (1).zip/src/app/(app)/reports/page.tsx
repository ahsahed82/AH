import Link from "next/link";
import { PrintButton } from "@/components/PrintButton";
import { Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { monthStartDhaka, todayDhaka, formatDate, formatMoney, formatQty } from "@/lib/format";
import { getReportData } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Reports" };

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const params = await searchParams;
  const from = params.from || monthStartDhaka();
  const to = params.to || todayDhaka();
  const [data, shop] = await Promise.all([getReportData({ from, to }), getSettings()]);

  const lowStock = data.inventoryReport.filter((row) => Number(row.currentStock) > 0 && Number(row.currentStock) <= Number(row.minStock));
  const outOfStock = data.inventoryReport.filter((row) => Number(row.currentStock) <= 0);

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle={`${formatDate(from)} to ${formatDate(to)} · all figures calculated from saved transactions`}
        actions={<PrintButton />}
      />

      <Card className="mb-4 no-print">
        <form action="/reports" method="get" className="flex flex-col gap-2 p-4 sm:flex-row sm:items-end">
          <div className="sm:w-44">
            <label className="label" htmlFor="report-from">From date</label>
            <input id="report-from" type="date" name="from" defaultValue={from} className="input" />
          </div>
          <div className="sm:w-44">
            <label className="label" htmlFor="report-to">To date</label>
            <input id="report-to" type="date" name="to" defaultValue={to} className="input" />
          </div>
          <button type="submit" className="btn btn-primary">Apply date filter</button>
          <div className="ml-auto flex gap-2">
            <Link href={`/reports?from=${monthStartDhaka()}&to=${todayDhaka()}`} className="btn btn-secondary btn-sm">This month</Link>
            <Link href={`/reports?from=${todayDhaka()}&to=${todayDhaka()}`} className="btn btn-secondary btn-sm">Today</Link>
            <Link href={`/reports?from=${new Date().toISOString().slice(0, 4)}-01-01&to=${todayDhaka()}`} className="btn btn-secondary btn-sm">This year</Link>
          </div>
        </form>
      </Card>

      <div className="hidden print:block mb-4">
        <h1 className="text-xl font-bold">{shop.shopName}</h1>
        <p className="text-xs">{shop.address} {shop.mobile ? `· ${shop.mobile}` : ""}</p>
        <p className="mt-1 text-sm font-semibold">Business report: {formatDate(from)} — {formatDate(to)}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        <StatCard label="Sales" value={formatMoney(data.sales.total)} hint={`${data.sales.count} invoice(s)`} tone="green" />
        <StatCard label="Purchases" value={formatMoney(data.purchases.total)} hint={`${data.purchases.count} purchase(s)`} tone="blue" />
        <StatCard label="Expenses" value={formatMoney(data.expenses.total)} hint={`${data.expenses.count} record(s)`} tone="amber" />
        <StatCard label="Cost of goods sold" value={formatMoney(data.profit.cogs)} tone="slate" />
        <StatCard label="Net profit" value={formatMoney(data.profit.net)} hint={`Gross ${formatMoney(data.profit.gross)}`} tone={data.profit.net >= 0 ? "green" : "red"} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Daily sales report" subtitle="Every day in the selected range with sales" />
          {data.dailySales.length === 0 ? (
            <EmptyState title="No sales in this period" />
          ) : (
            <div className="table-wrap max-h-[360px] overflow-y-auto">
              <table className="data-table">
                <thead>
                  <tr><th>Date</th><th className="text-right">Invoices</th><th className="text-right">Total</th><th className="text-right">Paid</th><th className="text-right">Due</th></tr>
                </thead>
                <tbody>
                  {data.dailySales.map((day) => (
                    <tr key={day.day}>
                      <td>{formatDate(`${day.day}T12:00:00+06:00`)}</td>
                      <td className="text-right">{day.count}</td>
                      <td className="text-right font-semibold">{formatMoney(day.total)}</td>
                      <td className="text-right">{formatMoney(day.paid)}</td>
                      <td className="text-right">{formatMoney(day.due)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 font-semibold">
                    <td className="px-3 py-2">Total</td>
                    <td className="px-3 py-2 text-right">{data.sales.count}</td>
                    <td className="px-3 py-2 text-right">{formatMoney(data.sales.total)}</td>
                    <td className="px-3 py-2 text-right">{formatMoney(data.sales.paid)}</td>
                    <td className="px-3 py-2 text-right">{formatMoney(data.sales.due)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="Profit report" subtitle="Sales − cost of goods − expenses" />
          <div className="space-y-2 p-4 text-sm">
            <div className="flex justify-between py-1"><span className="text-slate-600">Sales revenue</span><span className="font-semibold">{formatMoney(data.sales.total)}</span></div>
            <div className="flex justify-between py-1"><span className="text-slate-600">Discount given</span><span>− {formatMoney(data.sales.discount)}</span></div>
            <div className="flex justify-between py-1"><span className="text-slate-600">Cost of goods sold</span><span>− {formatMoney(data.profit.cogs)}</span></div>
            <div className="flex justify-between border-t border-slate-100 py-1"><span className="font-medium text-slate-800">Gross profit</span><span className="font-semibold">{formatMoney(data.profit.gross)}</span></div>
            <div className="flex justify-between py-1"><span className="text-slate-600">Operating expenses</span><span>− {formatMoney(data.expenses.total)}</span></div>
            <div className="flex justify-between border-t border-slate-200 pt-2 text-base"><span className="font-bold">Net profit</span><span className={`font-bold ${data.profit.net >= 0 ? "text-emerald-700" : "text-rose-600"}`}>{formatMoney(data.profit.net)}</span></div>
            <div className="mt-2 grid grid-cols-2 gap-2 border-t border-slate-100 pt-2 text-xs">
              <div className="rounded-lg bg-emerald-50 p-2"><p className="text-emerald-700">Payments received</p><p className="font-semibold text-emerald-900">{formatMoney(data.paymentsIn)}</p></div>
              <div className="rounded-lg bg-sky-50 p-2"><p className="text-sky-700">Payments to suppliers</p><p className="font-semibold text-sky-900">{formatMoney(data.paymentsOut)}</p></div>
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Purchase report" subtitle="Supplier purchases in the selected range" />
          <div className="grid grid-cols-2 gap-3 p-4 text-sm sm:grid-cols-4">
            <div><p className="muted">Purchases</p><p className="font-semibold">{formatMoney(data.purchases.total)}</p></div>
            <div><p className="muted">Paid</p><p className="font-semibold">{formatMoney(data.purchases.paid)}</p></div>
            <div><p className="muted">Due</p><p className="font-semibold">{formatMoney(data.purchases.due)}</p></div>
            <div><p className="muted">Records</p><p className="font-semibold">{data.purchases.count}</p></div>
          </div>
        </Card>

        <Card>
          <CardHeader title="Expense report" subtitle="Grouped by category" />
          {data.expenses.byCategory.length === 0 ? (
            <EmptyState title="No expenses in this period" />
          ) : (
            <div className="table-wrap">
              <table className="data-table min-w-full">
                <thead><tr><th>Category</th><th className="text-right">Records</th><th className="text-right">Amount</th></tr></thead>
                <tbody>
                  {data.expenses.byCategory.map((row) => (
                    <tr key={row.category}><td>{row.category}</td><td className="text-right">{row.count}</td><td className="text-right font-semibold">{formatMoney(row.total)}</td></tr>
                  ))}
                </tbody>
                <tfoot><tr className="bg-slate-50 font-semibold"><td className="px-3 py-2">Total</td><td className="px-3 py-2 text-right">{data.expenses.count}</td><td className="px-3 py-2 text-right">{formatMoney(data.expenses.total)}</td></tr></tfoot>
              </table>
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader title="Product report" subtitle="Products sold in the selected range" />
        {data.productReport.length === 0 ? (
          <EmptyState title="No product sales in this period" />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr><th>Product</th><th>SKU</th><th className="text-right">Qty sold</th><th className="text-right">Revenue</th><th className="text-right">Cost</th><th className="text-right">Profit</th></tr>
              </thead>
              <tbody>
                {data.productReport.map((row) => (
                  <tr key={`${row.productId ?? row.name}-${row.sku ?? ""}`}>
                    <td className="font-medium">{row.name}</td>
                    <td className="text-xs text-slate-500">{row.sku ?? "—"}</td>
                    <td className="text-right">{formatQty(row.qty)}</td>
                    <td className="text-right">{formatMoney(row.revenue)}</td>
                    <td className="text-right">{formatMoney(row.cost)}</td>
                    <td className="text-right font-semibold text-emerald-700">{formatMoney(Number(row.revenue) - Number(row.cost))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Inventory report"
            subtitle={`${data.inventoryAgg.count} active product(s) · ${formatQty(data.inventoryAgg.units)} units`}
            actions={<Badge tone="green">Cost {formatMoney(data.inventoryAgg.stockValue)}</Badge>}
          />
          <div className="px-4 py-2 text-xs text-slate-600">Retail value at selling price: <strong>{formatMoney(data.inventoryAgg.retailValue)}</strong></div>
          <div className="table-wrap max-h-[320px] overflow-y-auto">
            <table className="data-table">
              <thead><tr><th>Product</th><th className="text-right">Stock</th><th className="text-right">Cost value</th><th className="text-right">Retail value</th></tr></thead>
              <tbody>
                {data.inventoryReport.map((row) => (
                  <tr key={row.id}>
                    <td className="font-medium">{row.name}<span className="ml-1 text-[11px] text-slate-400">{row.sku}</span></td>
                    <td className="text-right">{formatQty(row.currentStock)} <span className="text-[10px] lowercase text-slate-400">{row.unit}</span></td>
                    <td className="text-right">{formatMoney(row.stockValue)}</td>
                    <td className="text-right">{formatMoney(row.retailValue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Low stock report" subtitle="At or below minimum stock" actions={<Badge tone="amber">{lowStock.length}</Badge>} />
            {lowStock.length === 0 ? <EmptyState title="No low stock products" /> : (
              <ul className="divide-y divide-slate-100">
                {lowStock.map((row) => (
                  <li key={row.id} className="flex justify-between px-4 py-2 text-sm">
                    <span className="truncate">{row.name}</span>
                    <span className="text-amber-700">{formatQty(row.currentStock)} / {formatQty(row.minStock)} {row.unit}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <CardHeader title="Out of stock report" actions={<Badge tone="red">{outOfStock.length}</Badge>} />
            {outOfStock.length === 0 ? <EmptyState title="All products have stock" /> : (
              <ul className="divide-y divide-slate-100">
                {outOfStock.map((row) => (
                  <li key={row.id} className="flex justify-between px-4 py-2 text-sm">
                    <span className="truncate">{row.name}</span>
                    <span className="text-rose-600">0 {row.unit}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Customer due report" subtitle="Receivable balances" />
          {data.customerDues.length === 0 ? <EmptyState title="No customers yet" /> : (
            <div className="table-wrap max-h-[320px] overflow-y-auto">
              <table className="data-table">
                <thead><tr><th>Customer</th><th>Mobile</th><th className="text-right">Due</th></tr></thead>
                <tbody>
                  {data.customerDues.map((row) => (
                    <tr key={row.id}>
                      <td><Link href={`/customers/${row.id}`} className="font-medium text-emerald-800 hover:underline">{row.name}</Link></td>
                      <td className="text-xs">{row.mobile ?? "—"}</td>
                      <td className="text-right font-semibold">{formatMoney(row.due)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="bg-slate-50 font-semibold"><td colSpan={2} className="px-3 py-2">Total receivable</td><td className="px-3 py-2 text-right">{formatMoney(data.customerDues.reduce((sum, row) => sum + Number(row.due), 0))}</td></tr></tfoot>
              </table>
            </div>
          )}
        </Card>
        <Card>
          <CardHeader title="Supplier due report" subtitle="Payable balances" />
          {data.supplierDues.length === 0 ? <EmptyState title="No suppliers yet" /> : (
            <div className="table-wrap max-h-[320px] overflow-y-auto">
              <table className="data-table">
                <thead><tr><th>Supplier</th><th>Mobile</th><th className="text-right">Due</th></tr></thead>
                <tbody>
                  {data.supplierDues.map((row) => (
                    <tr key={row.id}>
                      <td><Link href={`/suppliers/${row.id}`} className="font-medium text-emerald-800 hover:underline">{row.name}</Link></td>
                      <td className="text-xs">{row.mobile ?? "—"}</td>
                      <td className="text-right font-semibold">{formatMoney(row.due)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="bg-slate-50 font-semibold"><td colSpan={2} className="px-3 py-2">Total payable</td><td className="px-3 py-2 text-right">{formatMoney(data.supplierDues.reduce((sum, row) => sum + Number(row.due), 0))}</td></tr></tfoot>
              </table>
            </div>
          )}
        </Card>
      </div>

      <p className="mt-4 text-center text-[11px] text-slate-500">
        {shop.shopName} · Report generated {formatDate(new Date())} · All amounts in Bangladeshi Taka (BDT ৳)
      </p>
    </div>
  );
}
