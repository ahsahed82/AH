import type { ReactNode } from "react";
import { requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function PrintLayout({ children }: { children: ReactNode }) {
  await requireUser();
  return <div className="min-h-screen bg-slate-200/70 py-3 print:bg-white print:py-0">{children}</div>;
}
