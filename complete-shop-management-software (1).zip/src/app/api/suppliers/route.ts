import { db } from "@/db";
import { requireApiUser } from "@/lib/auth";
import { suppliers } from "@/db/schema";
import { getSuppliers } from "@/lib/queries";
import { fail, ok, optionalText, parseMoney, readJson, requiredText } from "@/lib/api-helpers";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    return ok({ suppliers: await getSuppliers(url.searchParams.get("search") ?? undefined) });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson(request);
    const name = requiredText(body.name, "Supplier name", 120);
    const [created] = await db
      .insert(suppliers)
      .values({
        name,
        mobile: optionalText(body.mobile, 30),
        address: optionalText(body.address, 400),
        openingBalance: money(parseMoney(body.openingBalance ?? 0, "Opening balance")),
      })
      .returning();
    return ok({ supplier: created, message: `${created.name} added.` }, 201);
  } catch (error) {
    return fail(error);
  }
}
