import { eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, stockMovements } from "@/db/schema";
import { getStockMovements } from "@/lib/queries";
import {
  ApiError,
  fail,
  ok,
  optionalText,
  parseId,
  parseQuantity,
  readJson,
} from "@/lib/api-helpers";
import { formatQty, qty, round3 } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    const productId = url.searchParams.get("productId");
    return ok({
      movements: await getStockMovements({
        productId: productId ? Number(productId) : undefined,
        type: url.searchParams.get("type") ?? undefined,
      }),
    });
  } catch (error) {
    return fail(error);
  }
}

/**
 * Manual stock movement.
 * mode = in  → add stock
 * mode = out → remove stock (blocked when it would make stock negative)
 * mode = set → correct the counted stock to an exact value
 */
export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson(request);
    const productId = parseId(body.productId, "Product");
    const mode = body.mode === "in" || body.mode === "out" || body.mode === "set" ? body.mode : "in";
    const quantity = parseQuantity(body.quantity, "Quantity", { allowZero: mode === "set" });
    const note = optionalText(body.note, 300) ?? (mode === "set" ? "Stock correction" : "Manual stock adjustment");

    const result = await db.transaction(async (tx) => {
      const [product] = await tx
        .select()
        .from(products)
        .where(eq(products.id, productId))
        .limit(1)
        .for("update");
      if (!product) throw new ApiError("Product not found.", 404);

      const current = Number(product.currentStock);
      const next = mode === "in" ? current + quantity : mode === "out" ? current - quantity : quantity;
      if (next < 0) {
        throw new ApiError(
          `Insufficient stock. ${product.name} currently has ${formatQty(current)} ${product.unit}.`,
        );
      }
      const delta = round3(next - current);
      if (delta === 0) throw new ApiError("The stock quantity would not change.");

      const [updated] = await tx
        .update(products)
        .set({ currentStock: qty(next), updatedAt: new Date() })
        .where(eq(products.id, productId))
        .returning({ currentStock: products.currentStock, name: products.name, unit: products.unit });

      await tx.insert(stockMovements).values({
        productId,
        type: "adjustment",
        quantity: qty(delta),
        referenceType: "adjustment",
        note: `${note} (${mode === "set" ? `set to ${formatQty(quantity)}` : mode === "in" ? "stock in" : "stock out"})`,
      });

      return {
        message: `${updated.name} stock updated to ${formatQty(updated.currentStock)} ${updated.unit}.`,
        currentStock: updated.currentStock,
      };
    });

    return ok(result);
  } catch (error) {
    return fail(error);
  }
}
