import { asc, eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { ApiError, fail, ok, optionalText, readJson, requiredText } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    return ok({ categories: await db.select().from(categories).orderBy(asc(categories.name)) });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson(request);
    const name = requiredText(body.name, "Category name", 80);
    const existing = await db.select({ id: categories.id }).from(categories).where(eq(categories.name, name)).limit(1);
    if (existing.length > 0) throw new ApiError("A category with this name already exists.", 409);
    const [created] = await db
      .insert(categories)
      .values({ name, description: optionalText(body.description, 300) })
      .returning();
    return ok({ category: created, message: "Category added." }, 201);
  } catch (error) {
    return fail(error);
  }
}
