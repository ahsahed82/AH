import { getPosProducts, getSupplierOptions } from "@/lib/queries";
import { todayDhaka } from "@/lib/format";
import { PurchaseForm } from "./PurchaseForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "New purchase" };

export default async function NewPurchasePage() {
  const [products, suppliers] = await Promise.all([getPosProducts(), getSupplierOptions()]);
  return <PurchaseForm products={products} suppliers={suppliers} defaultDate={todayDhaka()} />;
}
