"use client";

import { useEffect, useState, type ReactNode } from "react";
import { Icon, type IconName } from "@/components/icons";
import { formatDate } from "@/lib/format";

function DhakaClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  if (!now) return <span className="tabular-nums">--:--:--</span>;
  return (
    <span className="tabular-nums">
      {new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Dhaka",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      }).format(now)}
    </span>
  );
}

const FEATURES: { icon: IconName; title: string; text: string }[] = [
  { icon: "pos", title: "Point of Sale", text: "Fast billing with barcode search, dues and bKash/Nagad payments" },
  { icon: "inventory", title: "Live inventory", text: "Stock updates automatically with every sale and purchase" },
  { icon: "reports", title: "Reports & profit", text: "Daily sales, expenses, dues and net profit in BDT ৳" },
  { icon: "download", title: "One-click backup", text: "Download and restore your complete business data safely" },
];

export function AuthShell({
  shopName,
  logo,
  children,
  side,
}: {
  shopName: string;
  logo: string | null;
  children: ReactNode;
  side: "login" | "setup";
}) {
  return (
    <main className="auth-bg relative flex min-h-screen items-stretch">
      {/* Brand panel */}
      <section className="relative hidden w-[46%] flex-col justify-between overflow-hidden p-10 text-white lg:flex">
        <div className="auth-grid absolute inset-0" aria-hidden="true" />
        <div className="auth-glow absolute -left-24 top-1/3 h-96 w-96 rounded-full" aria-hidden="true" />
        <div className="relative">
          <div className="flex items-center gap-3">
            {logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logo} alt="" className="h-12 w-12 rounded-xl bg-white object-contain p-1 shadow-lg" />
            ) : (
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-emerald-400/20 text-lg font-bold text-emerald-100 ring-1 ring-emerald-300/40">
                {shopName.trim().slice(0, 2).toUpperCase() || "SR"}
              </span>
            )}
            <div>
              <p className="font-display text-xl font-bold leading-tight">{shopName}</p>
              <p className="text-xs text-emerald-200/80">Retail Shop Management · Bangladesh</p>
            </div>
          </div>

          <h1 className="font-display mt-12 max-w-md text-4xl font-extrabold leading-[1.1] tracking-tight">
            {side === "setup" ? (
              <>Your shop is live.<br />Claim your admin account.</>
            ) : (
              <>Run your entire shop<br />from one screen.</>
            )}
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-emerald-100/80">
            {side === "setup"
              ? "This secure setup runs only once. The username and password you choose now will protect all of your business data on this website."
              : "Sales, purchases, stock, customers, suppliers, expenses and reports — all saved permanently in your own database."}
          </p>

          <ul className="mt-8 space-y-3">
            {FEATURES.map((feature) => (
              <li key={feature.title} className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/5 p-3 backdrop-blur-sm transition hover:border-emerald-300/40 hover:bg-white/10">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-emerald-400/15 text-emerald-200 ring-1 ring-emerald-300/30">
                  <Icon name={feature.icon} className="h-4.5 w-4.5" />
                </span>
                <div>
                  <p className="text-sm font-semibold">{feature.title}</p>
                  <p className="text-xs text-emerald-100/70">{feature.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="relative flex items-center justify-between text-xs text-emerald-200/70">
          <span className="flex items-center gap-2">
            <Icon name="check" className="h-4 w-4 text-emerald-300" />
            BDT ৳ · Asia/Dhaka · {formatDate(new Date())}
          </span>
          <span className="rounded-full border border-white/15 bg-white/5 px-3 py-1 font-medium">
            <DhakaClock />
          </span>
        </div>
      </section>

      {/* Form panel */}
      <section className="flex flex-1 items-center justify-center p-4 sm:p-8">
        <div className="animate-rise w-full max-w-md">
          <div className="mb-6 flex items-center gap-3 lg:hidden">
            {logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logo} alt="" className="h-11 w-11 rounded-xl bg-white object-contain p-1 shadow" />
            ) : (
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-700 text-sm font-bold text-white">
                {shopName.trim().slice(0, 2).toUpperCase() || "SR"}
              </span>
            )}
            <div>
              <p className="font-display text-lg font-bold text-slate-900">{shopName}</p>
              <p className="text-xs text-slate-500">Retail Shop Management · Bangladesh</p>
            </div>
          </div>
          {children}
          <p className="mt-6 text-center text-[11px] text-slate-400">
            Protected single-admin access · Passwords are stored as secure hashes, never in plain text
          </p>
        </div>
      </section>
    </main>
  );
}
