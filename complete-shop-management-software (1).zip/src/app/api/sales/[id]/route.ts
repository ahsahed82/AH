import { eq } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, saleItems, sales, stockMovements } from "@/db/schema";
import { getSale } from "@/lib/queries";
import { ApiError, fail, idFromParam, ok } from "@/lib/api-helpers";
import { qty } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const sale = await getSale(idFromParam({ id }));
    if (!sale) throw new ApiError("Sale not found.", 404);
    return ok({ sale });
  } catch (error) {
    return fail(error);
  }
}

/** Delete a sale and reverse its stock movement and customer due effect. */
export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const saleId = idFromParam({ id });
    const invoiceNo = await db.transaction(async (tx) => {
      const [sale] = await tx.select().from(sales).where(eq(sales.id, saleId)).limit(1).for("update");
      if (!sale) throw new ApiError("Sale not found.", 404);
      const items = await tx.select().from(saleItems).where(eq(saleItems.saleId, saleId));

      for (const item of items) {
        if (item.productId) {
          const [product] = await tx
            .select({ id: products.id, currentStock: products.currentStock })
            .from(products)
            .where(eq(products.id, item.productId))
            .limit(1)
            .for("update");
          if (product) {
            await tx
              .update(products)
              .set({
                currentStock: qty(Number(product.currentStock) + Number(item.quantity)),
                updatedAt: new Date(),
              })
              .where(eq(products.id, product.id));
            await tx.insert(stockMovements).values({
              productId: product.id,
              type: "reversal",
              quantity: qty(Number(item.quantity)),
              referenceType: "sale_delete",
              referenceId: sale.id,
              referenceNo: sale.invoiceNo,
              note: "Sale deleted — stock returned",
            });
          }
        }
      }

      await tx.delete(sales).where(eq(sales.id, saleId));
      return sale.invoiceNo;
    });

    return ok({
      message: `${invoiceNo} deleted. Product stock has been returned to inventory.`,
    });
  } catch (error) {
    return fail(error);
  }
}
