import { eq, inArray } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, purchaseItems, purchases, stockMovements, suppliers } from "@/db/schema";
import { getPurchasesList } from "@/lib/queries";
import {
  ApiError,
  fail,
  ok,
  optionalText,
  parseId,
  parseMoney,
  parsePaymentMethod,
  parseQuantity,
  readJson,
} from "@/lib/api-helpers";
import { getSettings } from "@/lib/settings";
import { inputDateToDate, money, qty, round2 } from "@/lib/format";

export const dynamic = "force-dynamic";

type RawItem = { productId?: unknown; quantity?: unknown; unitPrice?: unknown };

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    const rows = await getPurchasesList({
      search: url.searchParams.get("search") ?? undefined,
      from: url.searchParams.get("from") ?? undefined,
      to: url.searchParams.get("to") ?? undefined,
    });
    return ok({ purchases: rows });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson<Record<string, unknown>>(request);
    const rawItems = Array.isArray(body.items) ? (body.items as RawItem[]) : [];
    if (rawItems.length === 0) throw new ApiError("Add at least one product to the purchase.");

    const parsedItems = rawItems.map((item, index) => ({
      productId: parseId(item.productId, `Product on line ${index + 1}`),
      quantity: parseQuantity(item.quantity, `Quantity on line ${index + 1}`),
      unitPrice: parseMoney(item.unitPrice, `Purchase price on line ${index + 1}`),
    }));
    const productIds = [...new Set(parsedItems.map((i) => i.productId))];
    const supplierId = body.supplierId ? Number(body.supplierId) : null;
    if (supplierId !== null && !Number.isInteger(supplierId)) throw new ApiError("Select a valid supplier.");
    const discount = parseMoney(body.discount ?? 0, "Discount");
    const paidInput = parseMoney(body.paidAmount ?? body.paid ?? 0, "Paid amount");
    const paymentMethod = parsePaymentMethod(body.paymentMethod);
    const note = optionalText(body.note, 500);
    const purchaseDate = inputDateToDate(typeof body.purchaseDate === "string" ? body.purchaseDate : null);
    const settingsRow = await getSettings();
    const prefix = settingsRow.purchasePrefix || "PUR";

    const created = await db.transaction(async (tx) => {
      const productRows = await tx.select().from(products).where(inArray(products.id, productIds));
      if (productRows.length !== productIds.length) throw new ApiError("One of the selected products no longer exists.");
      if (supplierId) {
        const [supplier] = await tx.select({ id: suppliers.id }).from(suppliers).where(eq(suppliers.id, supplierId)).limit(1);
        if (!supplier) throw new ApiError("Selected supplier was not found.");
      }

      const subtotal = round2(parsedItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0));
      if (discount > subtotal) throw new ApiError("Discount cannot be greater than the subtotal.");
      const total = round2(subtotal - discount);
      const paid = round2(Math.min(paidInput, total));
      const due = round2(total - paid);
      if (!supplierId && due > 0) {
        throw new ApiError(
          "A cash purchase without a supplier cannot have a due amount. Select a supplier or pay the full amount.",
        );
      }

      const [purchase] = await tx
        .insert(purchases)
        .values({
          purchaseNo: `TMP-${crypto.randomUUID()}`,
          supplierId,
          purchaseDate,
          subtotal: money(subtotal),
          discount: money(discount),
          total: money(total),
          paid: money(paid),
          due: money(due),
          paymentMethod,
          note,
        })
        .returning();

      const stamp = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Dhaka",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      })
        .format(purchaseDate)
        .replaceAll("-", "");
      const purchaseNo = `${prefix}-${stamp}-${String(purchase.id).padStart(4, "0")}`;
      await tx.update(purchases).set({ purchaseNo }).where(eq(purchases.id, purchase.id));

      for (const item of parsedItems) {
        const product = productRows.find((p) => p.id === item.productId);
        if (!product) throw new ApiError("Product not found.");
        await tx.insert(purchaseItems).values({
          purchaseId: purchase.id,
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          quantity: qty(item.quantity),
          unitPrice: money(item.unitPrice),
          total: money(round2(item.quantity * item.unitPrice)),
        });
        await tx
          .update(products)
          .set({
            currentStock: qty(Number(product.currentStock) + item.quantity),
            updatedAt: new Date(),
          })
          .where(eq(products.id, product.id));
        product.currentStock = qty(Number(product.currentStock) + item.quantity);
        await tx.insert(stockMovements).values({
          productId: product.id,
          type: "purchase",
          quantity: qty(item.quantity),
          referenceType: "purchase",
          referenceId: purchase.id,
          referenceNo: purchaseNo,
          note: "Stock received via purchase",
        });
      }

      return { id: purchase.id, purchaseNo, total, paid, due };
    });

    return ok({ ...created, message: `Purchase ${created.purchaseNo} saved successfully.` }, 201);
  } catch (error) {
    return fail(error);
  }
}
