import { adminExists, getSessionUser } from "@/lib/auth";
import { fail, ok } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    return ok({ user, setupRequired: !(await adminExists()) });
  } catch (error) {
    return fail(error);
  }
}
