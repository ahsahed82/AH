import type { Settings } from "@/db/schema";
import { formatDate, formatQty } from "@/lib/format";

export type ReceiptSale = {
  invoiceNo: string;
  saleDate: Date | string;
  subtotal: string;
  discount: string;
  total: string;
  paid: string;
  due: string;
  paymentMethod: string;
};

export type ReceiptItem = {
  id: number;
  productName: string;
  quantity: string;
  unitPrice: string;
  total: string;
};

const t = (value: number) => `৳ ${value.toFixed(2)}`;

export function Receipt({
  shop,
  sale,
  items,
  customer,
}: {
  shop: Settings;
  sale: ReceiptSale;
  items: ReceiptItem[];
  customer: { name: string; mobile: string | null } | null;
}) {
  return (
    <div className="receipt-sheet print-sheet px-1 py-2 print:px-0">
      <div className="text-center">
        {shop.showLogoOnPrint && shop.logo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={shop.logo} alt="" className="mx-auto mb-1 h-12 w-12 object-contain" />
        ) : null}
        <p className="text-[15px] font-extrabold uppercase leading-tight">{shop.shopName}</p>
        {shop.address ? <p className="text-[10px]">{shop.address}</p> : null}
        {shop.mobile ? <p className="text-[10px]">Mobile: {shop.mobile}</p> : null}
      </div>
      <div className="dash" />
      <table>
        <tbody>
          <tr>
            <td>Invoice</td>
            <td className="text-right font-semibold">{sale.invoiceNo}</td>
          </tr>
          <tr>
            <td>Date</td>
            <td className="text-right">{formatDate(sale.saleDate)}</td>
          </tr>
          <tr>
            <td>Customer</td>
            <td className="text-right">{customer?.name ?? "Walk-in"}</td>
          </tr>
          {customer?.mobile ? (
            <tr>
              <td>Mobile</td>
              <td className="text-right">{customer.mobile}</td>
            </tr>
          ) : null}
          <tr>
            <td>Payment</td>
            <td className="text-right">{sale.paymentMethod}</td>
          </tr>
        </tbody>
      </table>
      <div className="dash" />
      <table>
        <thead>
          <tr className="border-b border-slate-400">
            <th className="text-left">Item</th>
            <th className="text-right">Qty</th>
            <th className="text-right">Rate</th>
            <th className="text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} className="align-top">
              <td className="pr-1">{item.productName}</td>
              <td className="text-right">{formatQty(item.quantity)}</td>
              <td className="text-right">{t(Number(item.unitPrice))}</td>
              <td className="text-right">{t(Number(item.total))}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="dash" />
      <table>
        <tbody>
          <tr>
            <td>Subtotal</td>
            <td className="text-right">{t(Number(sale.subtotal))}</td>
          </tr>
          <tr>
            <td>Discount</td>
            <td className="text-right">− {t(Number(sale.discount))}</td>
          </tr>
          <tr className="border-t border-slate-400">
            <td className="font-bold">Grand total</td>
            <td className="text-right text-[13px] font-extrabold">{t(Number(sale.total))}</td>
          </tr>
          <tr>
            <td>Paid</td>
            <td className="text-right">{t(Number(sale.paid))}</td>
          </tr>
          <tr>
            <td>Due</td>
            <td className="text-right font-bold">{t(Number(sale.due))}</td>
          </tr>
        </tbody>
      </table>
      <div className="dash" />
      <p className="text-center text-[10px] leading-snug">
        {shop.receiptFooter || "Thank you! Please visit again."}
      </p>
      <p className="mt-1 text-center text-[9px] text-slate-500">
        Amounts in Bangladeshi Taka (BDT) · All prices include applicable taxes
      </p>
    </div>
  );
}
