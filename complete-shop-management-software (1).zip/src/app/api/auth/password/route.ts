import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers, authSessions } from "@/db/schema";
import {
  createSession,
  hashPassword,
  requireApiUser,
  verifyPassword,
} from "@/lib/auth";
import { fail, ok, readJson } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/** Change the admin password. All other sessions are signed out. */
export async function POST(request: Request) {
  try {
    const auth = await requireApiUser();
    if (!auth.ok) return auth.response;

    const body = await readJson<Record<string, unknown>>(request);
    const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
    const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
    if (newPassword.length < 8) throw new Error("New password must be at least 8 characters long.");
    if (newPassword.length > 200) throw new Error("New password is too long.");
    if (newPassword === currentPassword) throw new Error("New password must be different from the current one.");

    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.id, auth.user.id)).limit(1);
    if (!user || !verifyPassword(currentPassword, user.passwordHash)) {
      return Response.json({ error: "Current password is incorrect." }, { status: 401 });
    }

    await db
      .update(adminUsers)
      .set({ passwordHash: hashPassword(newPassword) })
      .where(eq(adminUsers.id, user.id));
    // Invalidate every existing session, then sign this browser in again.
    await db.delete(authSessions).where(eq(authSessions.userId, user.id));
    await createSession(user.id);

    return ok({ message: "Password changed. Other devices have been signed out." });
  } catch (error) {
    return fail(error);
  }
}
