import { getProducts, getStockMovements } from "@/lib/queries";
import { InventoryClient } from "./InventoryClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Inventory" };

export default async function InventoryPage({
  searchParams,
}: {
  searchParams: Promise<{ stock?: string }>;
}) {
  const params = await searchParams;
  const [products, movements] = await Promise.all([getProducts(), getStockMovements({ limit: 200 })]);
  return (
    <InventoryClient
      products={products}
      movements={movements}
      initialStock={params.stock ?? "all"}
    />
  );
}
