"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { Alert, ConfirmDialog, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, deleteRequest, jsonBody, putBody } from "@/lib/client";
import { formatMoney } from "@/lib/format";

export type PartyRow = {
  id: number;
  name: string;
  mobile: string | null;
  address: string | null;
  openingBalance: string;
  totalBusiness: string;
  totalPaid: string;
  due: string;
  count: number;
};

export function PartyClient({
  mode,
  rows,
  basePath,
  apiPath,
}: {
  mode: "customer" | "supplier";
  rows: PartyRow[];
  basePath: string;
  apiPath: string;
}) {
  const router = useRouter();
  const isCustomer = mode === "customer";
  const label = isCustomer ? "Customer" : "Supplier";
  const businessLabel = isCustomer ? "Total sales" : "Total purchases";

  const [search, setSearch] = useState("");
  const [dueOnly, setDueOnly] = useState(false);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", mobile: "", address: "", openingBalance: "" });
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PartyRow | null>(null);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return rows.filter((row) => {
      if (dueOnly && Number(row.due) <= 0) return false;
      if (!term) return true;
      return `${row.name} ${row.mobile ?? ""} ${row.address ?? ""}`.toLowerCase().includes(term);
    });
  }, [rows, search, dueOnly]);

  const totals = filtered.reduce(
    (acc, row) => ({
      business: acc.business + Number(row.totalBusiness),
      paid: acc.paid + Number(row.totalPaid),
      due: acc.due + Number(row.due),
    }),
    { business: 0, paid: 0, due: 0 },
  );

  function openAdd() {
    setEditingId(null);
    setForm({ name: "", mobile: "", address: "", openingBalance: "" });
    setOpen(true);
    setNotice(null);
  }

  function openEdit(row: PartyRow) {
    setEditingId(row.id);
    setForm({
      name: row.name,
      mobile: row.mobile ?? "",
      address: row.address ?? "",
      openingBalance: row.openingBalance,
    });
    setOpen(true);
    setNotice(null);
  }

  async function save() {
    setBusy(true);
    setNotice(null);
    try {
      const payload = {
        name: form.name,
        mobile: form.mobile || null,
        address: form.address || null,
        openingBalance: form.openingBalance || 0,
      };
      const result = await api<{ message: string }>(
        editingId ? `${apiPath}/${editingId}` : apiPath,
        editingId ? putBody(payload) : jsonBody(payload),
      );
      setNotice({ tone: "success", text: result.message });
      setOpen(false);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not save." });
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      const result = await api<{ message: string }>(`${apiPath}/${deleteTarget.id}`, deleteRequest());
      setNotice({ tone: "success", text: result.message });
      setDeleteTarget(null);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not delete." });
      setDeleteTarget(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title={isCustomer ? "Customers" : "Suppliers"}
        subtitle={
          isCustomer
            ? "Customer balances are calculated from opening balance, sales paid and later payments."
            : "Supplier balances are calculated from opening balance, purchases paid and later payments."
        }
        actions={
          <button type="button" className="btn btn-primary" onClick={openAdd}>
            <Icon name="plus" className="h-4 w-4" /> Add {label}
          </button>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label={`${label}s`} value={String(rows.length)} tone="blue" />
        <StatCard label={businessLabel} value={formatMoney(totals.business)} tone="slate" />
        <StatCard label="Total paid" value={formatMoney(totals.paid)} tone="green" />
        <StatCard label={isCustomer ? "Receivable due" : "Payable due"} value={formatMoney(totals.due)} tone="amber" />
      </div>

      <Card className="mt-4">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              className="input pl-9"
              placeholder={`Search ${label.toLowerCase()} name, mobile or address…`}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
            <input type="checkbox" checked={dueOnly} onChange={(e) => setDueOnly(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
            With due only
          </label>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title={rows.length === 0 ? `No ${label.toLowerCase()}s yet` : `No ${label.toLowerCase()} matches`}
            description={`Add a ${label.toLowerCase()} to record sales, purchases, payments and dues.`}
            action={<button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>Add {label}</button>}
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Address</th>
                  <th className="text-right">{businessLabel}</th>
                  <th className="text-right">Paid</th>
                  <th className="text-right">Due</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id}>
                    <td>
                      <Link href={`${basePath}/${row.id}`} className="font-semibold text-emerald-800 hover:underline">
                        {row.name}
                      </Link>
                      <p className="text-[11px] text-slate-500">{row.count} transaction(s)</p>
                    </td>
                    <td>{row.mobile ?? "—"}</td>
                    <td className="max-w-[220px] truncate">{row.address ?? "—"}</td>
                    <td className="text-right">{formatMoney(row.totalBusiness)}</td>
                    <td className="text-right">{formatMoney(row.totalPaid)}</td>
                    <td className="text-right">
                      {Number(row.due) > 0 ? <Badge tone="amber">{formatMoney(row.due)}</Badge> : <Badge tone="green">Clear</Badge>}
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-0.5">
                        <Link href={`${basePath}/${row.id}`} className="btn btn-ghost btn-sm" title="View history">
                          <Icon name="eye" className="h-4 w-4" />
                        </Link>
                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => openEdit(row)} title="Edit">
                          <Icon name="edit" className="h-4 w-4" />
                        </button>
                        <button type="button" className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50" onClick={() => setDeleteTarget(row)} title="Delete">
                          <Icon name="trash" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={open}
        title={`${editingId ? "Edit" : "Add"} ${label.toLowerCase()}`}
        onClose={() => setOpen(false)}
        size="md"
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
            <button type="button" className="btn btn-primary" onClick={save} disabled={busy}>{busy ? "Saving…" : "Save"}</button>
          </>
        }
      >
        {notice && notice.tone === "error" ? <div className="mb-3"><Alert tone="error">{notice.text}</Alert></div> : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="label" htmlFor="party-name">Name *</label>
            <input id="party-name" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="label" htmlFor="party-mobile">Mobile number</label>
            <input id="party-mobile" className="input" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="01XXXXXXXXX" />
          </div>
          <div>
            <label className="label" htmlFor="party-opening">Opening balance (৳)</label>
            <input id="party-opening" type="number" step="0.01" min="0" className="input" value={form.openingBalance} onChange={(e) => setForm({ ...form, openingBalance: e.target.value })} />
            <p className="muted mt-1">{isCustomer ? "Previous due from this customer" : "Previous due to this supplier"}</p>
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="party-address">Address</label>
            <textarea id="party-address" className="textarea" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title={`Delete ${label.toLowerCase()}?`}
        message={
          <>
            <p><strong>{deleteTarget?.name}</strong> will be permanently deleted.</p>
            <p className="mt-2 text-xs text-slate-500">
              {label}s with transaction history cannot be deleted, so your {isCustomer ? "sales" : "purchase"} and due
              reports always remain accurate.
            </p>
          </>
        }
        confirmLabel={`Delete ${label.toLowerCase()}`}
        busy={busy}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
