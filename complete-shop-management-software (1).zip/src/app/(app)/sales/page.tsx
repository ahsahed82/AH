import { getSalesList } from "@/lib/queries";
import { SalesClient } from "./SalesClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sales" };

export default async function SalesPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; search?: string; due?: string }>;
}) {
  const params = await searchParams;
  const sales = await getSalesList();
  return (
    <SalesClient
      sales={sales}
      initialFrom={params.from ?? ""}
      initialTo={params.to ?? ""}
      initialSearch={params.search ?? ""}
      initialDueOnly={params.due === "1"}
    />
  );
}
