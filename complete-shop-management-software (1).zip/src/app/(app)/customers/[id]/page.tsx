import Link from "next/link";
import { notFound } from "next/navigation";
import { Icon } from "@/components/icons";
import { PaymentForm } from "@/components/PaymentForm";
import { Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { getCustomerDetail } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata = { title: "Customer details" };

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const customerId = Number(id);
  if (!Number.isInteger(customerId)) notFound();
  const data = await getCustomerDetail(customerId);
  if (!data) notFound();
  const { customer, sales, payments, totals } = data;

  return (
    <div>
      <PageHeader
        title={customer.name}
        subtitle={`${customer.mobile ?? "No mobile"} · ${customer.address ?? "No address"}`}
        actions={
          <>
            <Link href="/customers" className="btn btn-secondary"><Icon name="back" className="h-4 w-4" /> All customers</Link>
            <Link href="/pos" className="btn btn-primary"><Icon name="plus" className="h-4 w-4" /> New sale</Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Opening balance" value={formatMoney(customer.openingBalance)} tone="slate" />
        <StatCard label="Total purchases" value={formatMoney(totals.totalSales)} hint={`${sales.length} invoice(s)`} tone="blue" />
        <StatCard label="Total paid" value={formatMoney(totals.totalPaid)} tone="green" />
        <StatCard label="Current due" value={formatMoney(totals.due)} tone={totals.due > 0 ? "amber" : "green"} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-12">
        <div className="space-y-4 xl:col-span-8">
          <Card>
            <CardHeader title="Purchase history" subtitle="All invoices for this customer" />
            {sales.length === 0 ? (
              <EmptyState title="No purchases yet" description="Sales made from POS with this customer will appear here." />
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Invoice</th>
                      <th>Date</th>
                      <th className="text-right">Total</th>
                      <th className="text-right">Paid</th>
                      <th className="text-right">Due</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {sales.map((sale) => (
                      <tr key={sale.id}>
                        <td><Link href={`/sales/${sale.id}`} className="font-semibold text-emerald-800 hover:underline">{sale.invoiceNo}</Link></td>
                        <td className="whitespace-nowrap text-xs">{formatDate(sale.saleDate)}</td>
                        <td className="text-right">{formatMoney(sale.total)}</td>
                        <td className="text-right">{formatMoney(sale.paid)}</td>
                        <td className="text-right">{Number(sale.due) > 0 ? <Badge tone="amber">{formatMoney(sale.due)}</Badge> : <Badge tone="green">Paid</Badge>}</td>
                        <td className="text-right">
                          <Link href={`/print/receipt/${sale.id}`} target="_blank" className="btn btn-ghost btn-sm"><Icon name="print" className="h-4 w-4" /></Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card>
            <CardHeader title="Payment history" subtitle="Payments received after the initial invoice payment" />
            {payments.length === 0 ? (
              <EmptyState title="No later payments" />
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Method</th>
                      <th className="text-right">Amount</th>
                      <th>Note</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((payment) => (
                      <tr key={payment.id}>
                        <td className="whitespace-nowrap text-xs">{formatDateTime(payment.paymentDate)}</td>
                        <td>{payment.paymentMethod}</td>
                        <td className="text-right font-semibold text-emerald-700">{formatMoney(payment.amount)}</td>
                        <td className="max-w-[220px] truncate text-xs">{payment.note ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        <div className="xl:col-span-4">
          <Card>
            <CardHeader title="Receive payment" subtitle="Reduce this customer's outstanding due" />
            <PaymentForm kind="customer" partyId={customer.id} partyName={customer.name} due={Number(totals.due)} />
          </Card>
          <Card className="mt-4">
            <CardHeader title="Due calculation" />
            <div className="space-y-1 p-4 text-xs text-slate-600">
              <p className="flex justify-between"><span>Opening balance</span><span>{formatMoney(customer.openingBalance)}</span></p>
              <p className="flex justify-between"><span>+ Sales total</span><span>{formatMoney(totals.totalSales)}</span></p>
              <p className="flex justify-between"><span>− Paid at sale</span><span>{formatMoney(totals.salePaid)}</span></p>
              <p className="flex justify-between"><span>− Later payments</span><span>{formatMoney(totals.laterPaid)}</span></p>
              <p className="mt-1 flex justify-between border-t border-slate-200 pt-1 text-sm font-bold text-slate-900"><span>= Current due</span><span>{formatMoney(totals.due)}</span></p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
