import type { Settings } from "@/db/schema";
import { formatAmount, formatDate, formatDateTime, formatMoney, formatQty } from "@/lib/format";

export function PurchaseDocument({
  shop,
  purchase,
  items,
  supplier,
}: {
  shop: Settings;
  purchase: {
    purchaseNo: string;
    purchaseDate: Date | string;
    subtotal: string;
    discount: string;
    total: string;
    paid: string;
    due: string;
    paymentMethod: string;
    note: string | null;
  };
  items: { id: number; productName: string; sku: string | null; quantity: string; unitPrice: string; total: string }[];
  supplier: { name: string; mobile: string | null; address: string | null } | null;
}) {
  return (
    <div className="print-sheet mx-auto w-full max-w-[210mm] bg-white p-6 text-slate-900 shadow-sm print:p-0 sm:p-8">
      <div className="flex flex-col gap-4 border-b-2 border-sky-700 pb-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-3">
          {shop.showLogoOnPrint && shop.logo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={shop.logo} alt="" className="h-16 w-16 object-contain" />
          ) : null}
          <div>
            <h1 className="text-xl font-extrabold text-sky-900 sm:text-2xl">{shop.shopName}</h1>
            {shop.address ? <p className="max-w-xs text-xs text-slate-600">{shop.address}</p> : null}
            <p className="text-xs text-slate-600">{shop.mobile ? `Mobile: ${shop.mobile}` : ""}{shop.email ? ` · ${shop.email}` : ""}</p>
          </div>
        </div>
        <div className="sm:text-right">
          <p className="inline-block rounded bg-sky-700 px-3 py-1 text-sm font-bold uppercase tracking-widest text-white">Purchase</p>
          <table className="mt-2 ml-auto text-xs">
            <tbody>
              <tr><td className="pr-3 text-slate-500">Purchase no</td><td className="font-bold">{purchase.purchaseNo}</td></tr>
              <tr><td className="pr-3 text-slate-500">Date</td><td className="font-semibold">{formatDate(purchase.purchaseDate)}</td></tr>
              <tr><td className="pr-3 text-slate-500">Method</td><td className="font-semibold">{purchase.paymentMethod}</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-4 rounded-lg border border-slate-200 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Supplier</p>
        <p className="text-sm font-bold">{supplier?.name ?? "Cash purchase (no supplier)"}</p>
        {supplier?.mobile ? <p className="text-xs text-slate-600">Mobile: {supplier.mobile}</p> : null}
        {supplier?.address ? <p className="text-xs text-slate-600">{supplier.address}</p> : null}
      </div>

      <div className="mt-4 overflow-hidden rounded-lg border border-slate-200">
        <table className="w-full border-collapse text-xs sm:text-sm">
          <thead>
            <tr className="bg-slate-100 text-left">
              <th className="px-2 py-2 font-semibold">SL</th>
              <th className="px-2 py-2 font-semibold">Product</th>
              <th className="px-2 py-2 text-right font-semibold">Qty</th>
              <th className="px-2 py-2 text-right font-semibold">Purchase price</th>
              <th className="px-2 py-2 text-right font-semibold">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className="print-avoid-break border-t border-slate-100">
                <td className="px-2 py-1.5 text-slate-500">{index + 1}</td>
                <td className="px-2 py-1.5">
                  {item.productName}
                  {item.sku ? <span className="ml-1 text-[10px] text-slate-400">({item.sku})</span> : null}
                </td>
                <td className="px-2 py-1.5 text-right">{formatQty(item.quantity)}</td>
                <td className="px-2 py-1.5 text-right">{formatAmount(item.unitPrice)}</td>
                <td className="px-2 py-1.5 text-right font-semibold">{formatAmount(item.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:justify-between">
        <div className="max-w-sm text-xs text-slate-600">
          {purchase.note ? <p><strong>Note:</strong> {purchase.note}</p> : null}
          <p className="mt-2 text-[11px] text-slate-500">Printed {formatDateTime(new Date())} (Asia/Dhaka)</p>
        </div>
        <table className="min-w-[240px] text-sm">
          <tbody>
            <tr><td className="py-0.5 pr-4 text-slate-600">Subtotal</td><td className="py-0.5 text-right font-semibold">{formatMoney(purchase.subtotal)}</td></tr>
            <tr><td className="py-0.5 pr-4 text-slate-600">Discount</td><td className="py-0.5 text-right font-semibold text-rose-600">− {formatMoney(purchase.discount)}</td></tr>
            <tr className="border-t border-slate-300"><td className="py-1 pr-4 font-bold">Total</td><td className="py-1 text-right font-bold">{formatMoney(purchase.total)}</td></tr>
            <tr><td className="py-0.5 pr-4 text-slate-600">Paid</td><td className="py-0.5 text-right">{formatMoney(purchase.paid)}</td></tr>
            <tr className="border-t border-slate-300"><td className="py-1 pr-4 font-bold">Due</td><td className="py-1 text-right font-bold text-rose-600">{formatMoney(purchase.due)}</td></tr>
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex justify-between text-[11px] text-slate-500">
        <span>Received by: ____________________</span>
        <span>Authorised signature: ____________________</span>
      </div>
    </div>
  );
}
