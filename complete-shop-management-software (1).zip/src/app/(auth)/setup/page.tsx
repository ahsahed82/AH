import { redirect } from "next/navigation";
import { adminExists, getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { SetupClient } from "./SetupClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Create administrator" };

export default async function SetupPage() {
  if (await adminExists()) {
    const user = await getSessionUser();
    redirect(user ? "/" : "/login");
  }
  const shop = await getSettings();
  return <SetupClient shopName={shop.shopName} logo={shop.logo} />;
}
