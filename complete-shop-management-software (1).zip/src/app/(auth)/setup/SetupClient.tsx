"use client";

import { useMemo, useState } from "react";
import { AuthShell } from "@/components/AuthShell";
import { Alert } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, jsonBody } from "@/lib/client";

function strengthOf(password: string): { score: number; label: string; tone: string } {
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
  if (/\d/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  if (score <= 1) return { score, label: "Weak", tone: "bg-rose-500" };
  if (score <= 3) return { score, label: "Good", tone: "bg-amber-500" };
  return { score, label: "Strong", tone: "bg-emerald-500" };
}

export function SetupClient({ shopName, logo }: { shopName: string; logo: string | null }) {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const strength = useMemo(() => strengthOf(password), [password]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError("Passwords do not match. Please retype the confirmation.");
      return;
    }
    setBusy(true);
    try {
      await api("/api/auth/setup", jsonBody({ name: name || null, username, password }));
      // Confirm the session cookie is actually stored in this browser.
      const me = await api<{ user: { username: string } | null }>("/api/auth/me");
      if (!me.user) {
        setError(
          "Account created, but this browser blocked the sign-in cookie. Open the app in its own browser tab (not inside a preview panel), then sign in with the username and password you just chose.",
        );
        setBusy(false);
        return;
      }
      window.location.href = "/";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Setup failed.");
      setBusy(false);
    }
  }

  return (
    <AuthShell shopName={shopName} logo={logo} side="setup">
      <div className="card p-6 sm:p-8">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-[11px] font-semibold text-amber-700 ring-1 ring-amber-200">
          <Icon name="shield" className="h-3.5 w-3.5" /> First-time setup · runs only once
        </span>
        <h2 className="font-display mt-3 text-2xl font-bold text-slate-900">Create your admin account</h2>
        <p className="mt-1 text-sm text-slate-500">
          Choose a username and a strong password. Keep them safe — they protect all your business data.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {error ? <Alert tone="error">{error}</Alert> : null}
          <div>
            <label className="label" htmlFor="setup-name">Your name (shown in the app)</label>
            <input
              id="setup-name"
              className="input"
              placeholder="e.g. Rahim Uddin"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
            />
          </div>
          <div>
            <label className="label" htmlFor="setup-username">Username *</label>
            <div className="relative">
              <Icon name="user" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="setup-username"
                className="input pl-9"
                placeholder="e.g. rahim.admin"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase())}
                required
              />
            </div>
            <p className="muted mt-1">3–30 characters: letters, numbers, dot, dash or underscore.</p>
          </div>
          <div>
            <label className="label" htmlFor="setup-password">Password * (minimum 8 characters)</label>
            <div className="relative">
              <Icon name="key" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="setup-password"
                type={showPassword ? "text" : "password"}
                className="input pl-9 pr-10"
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
              />
              <button
                type="button"
                className="absolute right-2 top-2 rounded p-0.5 text-slate-400 hover:text-slate-600"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                <Icon name={showPassword ? "eye-off" : "eye"} className="h-4 w-4" />
              </button>
            </div>
            {password ? (
              <div className="mt-2 flex items-center gap-2">
                <div className="flex h-1.5 flex-1 gap-1">
                  {[1, 2, 3, 4, 5].map((step) => (
                    <span
                      key={step}
                      className={`flex-1 rounded-full ${step <= strength.score ? strength.tone : "bg-slate-200"}`}
                    />
                  ))}
                </div>
                <span className="text-[11px] font-semibold text-slate-600">{strength.label}</span>
              </div>
            ) : null}
          </div>
          <div>
            <label className="label" htmlFor="setup-confirm">Confirm password *</label>
            <input
              id="setup-confirm"
              type={showPassword ? "text" : "password"}
              className="input"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
            {confirm && confirm !== password ? (
              <p className="mt-1 text-[11px] font-medium text-rose-600">Passwords do not match yet.</p>
            ) : null}
          </div>
          <button type="submit" className="btn btn-primary w-full py-2.5 text-base" disabled={busy}>
            {busy ? "Creating account…" : "Create account & open my shop"}
          </button>
        </form>
      </div>
    </AuthShell>
  );
}
