import { getCustomerOptions, getPosProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { todayDhaka } from "@/lib/format";
import { PosClient } from "./PosClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "New Sale (POS)" };

export default async function PosPage() {
  const [products, customers, shop] = await Promise.all([
    getPosProducts(),
    getCustomerOptions(),
    getSettings(),
  ]);
  return (
    <PosClient
      products={products}
      customers={customers}
      defaultDate={todayDhaka()}
      shopName={shop.shopName}
    />
  );
}
