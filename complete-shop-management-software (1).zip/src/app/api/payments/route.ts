import { db } from "@/db";
import { requireApiUser } from "@/lib/auth";
import { customerPayments, supplierPayments } from "@/db/schema";
import { getCustomerDue, getSupplierDue } from "@/lib/queries";
import {
  ApiError,
  fail,
  ok,
  optionalText,
  parseMoney,
  parsePaymentMethod,
  readJson,
} from "@/lib/api-helpers";
import { formatMoney, inputDateToDate, money, round2 } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson<Record<string, unknown>>(request);
    const kind = body.kind === "supplier" ? "supplier" : "customer";
    const amount = parseMoney(body.amount, "Payment amount", { min: 0.01 });
    const paymentMethod = parsePaymentMethod(body.paymentMethod);
    const note = optionalText(body.note, 300);
    const paymentDate = inputDateToDate(typeof body.paymentDate === "string" ? body.paymentDate : null);

    if (kind === "customer") {
      const customerId = Number(body.customerId);
      if (!Number.isInteger(customerId)) throw new ApiError("Select a customer.");
      const balance = await getCustomerDue(customerId);
      if (!balance) throw new ApiError("Customer not found.", 404);
      if (balance.due <= 0.009) throw new ApiError(`${balance.name} has no outstanding due.`);
      if (amount > balance.due + 0.009) {
        throw new ApiError(
          `Payment is more than the outstanding due of ${formatMoney(balance.due)}. Please enter a smaller amount.`,
        );
      }
      const [created] = await db
        .insert(customerPayments)
        .values({
          customerId,
          saleId: body.saleId ? Number(body.saleId) : null,
          amount: money(amount),
          paymentMethod,
          paymentDate,
          note,
        })
        .returning();
      return ok(
        {
          payment: created,
          newDue: round2(balance.due - amount),
          message: `Customer payment of ${formatMoney(amount)} recorded. Remaining due ${formatMoney(balance.due - amount)}.`,
        },
        201,
      );
    }

    const supplierId = Number(body.supplierId);
    if (!Number.isInteger(supplierId)) throw new ApiError("Select a supplier.");
    const balance = await getSupplierDue(supplierId);
    if (!balance) throw new ApiError("Supplier not found.", 404);
    if (balance.due <= 0.009) throw new ApiError(`${balance.name} has no outstanding due.`);
    if (amount > balance.due + 0.009) {
      throw new ApiError(
        `Payment is more than the outstanding due of ${formatMoney(balance.due)}. Please enter a smaller amount.`,
      );
    }
    const [created] = await db
      .insert(supplierPayments)
      .values({
        supplierId,
        purchaseId: body.purchaseId ? Number(body.purchaseId) : null,
        amount: money(amount),
        paymentMethod,
        paymentDate,
        note,
      })
      .returning();
    return ok(
      {
        payment: created,
        newDue: round2(balance.due - amount),
        message: `Supplier payment of ${formatMoney(amount)} recorded. Remaining due ${formatMoney(balance.due - amount)}.`,
      },
      201,
    );
  } catch (error) {
    return fail(error);
  }
}
