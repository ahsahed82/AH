import { fail } from "@/lib/api-helpers";
import { requireApiUser } from "@/lib/auth";
import { buildBackup } from "@/lib/backup";
import { todayDhaka } from "@/lib/format";

export const dynamic = "force-dynamic";

/** Streams a real JSON backup of every business table as a file download. */
export async function GET() {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const payload = await buildBackup();
    const date = todayDhaka();
    const filename = `Shop_Backup_${date}.json`;
    const body = JSON.stringify(payload, null, 2);

    return new Response(body, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Content-Length": String(new TextEncoder().encode(body).byteLength),
        "Cache-Control": "no-store",
        "X-Backup-Filename": filename,
      },
    });
  } catch (error) {
    return fail(error);
  }
}
