"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { Settings } from "@/db/schema";
import { Alert, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { Badge, Card, CardHeader, PageHeader } from "@/components/ui";
import { api, fileToDataUrl, putBody } from "@/lib/client";


type BackupMeta = {
  app: string;
  version: number;
  exportedAt: string;
  shopName: string;
  currency: string;
  timezone: string;
  counts: Record<string, number>;
};

type BackupFile = { meta: BackupMeta; data: Record<string, unknown[]> };

const TABS = [
  { id: "business", label: "Business profile" },
  { id: "invoice", label: "Invoice & receipt" },
  { id: "security", label: "Security & login" },
  { id: "backup", label: "Backup & restore" },
] as const;

function SecurityPanel() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function changePassword(event: React.FormEvent) {
    event.preventDefault();
    setNotice(null);
    if (newPassword !== confirmPassword) {
      setNotice({ tone: "error", text: "New password and confirmation do not match." });
      return;
    }
    setBusy(true);
    try {
      const result = await api<{ message: string }>("/api/auth/password", {
        method: "POST",
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setNotice({ tone: "success", text: result.message });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Password change failed." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="Change admin password" subtitle="Other devices will be signed out automatically" />
        <form onSubmit={changePassword} className="grid gap-3 p-4">
          {notice ? <Alert tone={notice.tone}>{notice.text}</Alert> : null}
          <div>
            <label className="label" htmlFor="sec-current">Current password</label>
            <input id="sec-current" type={show ? "text" : "password"} className="input" autoComplete="current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="sec-new">New password (minimum 8 characters)</label>
            <input id="sec-new" type={show ? "text" : "password"} className="input" autoComplete="new-password" minLength={8} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="sec-confirm">Confirm new password</label>
            <input id="sec-confirm" type={show ? "text" : "password"} className="input" autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          </div>
          <label className="flex items-center gap-2 text-xs text-slate-600">
            <input type="checkbox" className="h-4 w-4 rounded border-slate-300" checked={show} onChange={(e) => setShow(e.target.checked)} />
            Show passwords
          </label>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            <Icon name="key" className="h-4 w-4" /> {busy ? "Updating…" : "Update password"}
          </button>
        </form>
      </Card>
      <Card>
        <CardHeader title="How your account is protected" />
        <ul className="space-y-3 p-4 text-sm text-slate-600">
          <li className="flex gap-2"><Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> Passwords are stored only as secure scrypt hashes in the database — never as readable text.</li>
          <li className="flex gap-2"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> Every page and every data API requires your signed-in session; visitors without a login see nothing.</li>
          <li className="flex gap-2"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> Sign-in sessions use secure HTTP-only cookies and last 30 days per device.</li>
          <li className="flex gap-2"><Icon name="warning" className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" /> After 5 wrong password attempts, sign-in is locked for 30 seconds.</li>
          <li className="flex gap-2"><Icon name="download" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> Backups include your admin account (hashed). After restoring, sign in with the credentials from that backup.</li>
        </ul>
      </Card>
    </div>
  );
}

export function SettingsClient({ settings }: { settings: Settings }) {
  const router = useRouter();
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("business");
  const [form, setForm] = useState({
    shopName: settings.shopName,
    address: settings.address,
    mobile: settings.mobile,
    email: settings.email,
    country: settings.country,
    logo: settings.logo ?? "",
    invoicePrefix: settings.invoicePrefix,
    purchasePrefix: settings.purchasePrefix,
    invoiceNote: settings.invoiceNote,
    invoiceTerms: settings.invoiceTerms,
    receiptFooter: settings.receiptFooter,
    showLogoOnPrint: settings.showLogoOnPrint,
  });
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const [backupBusy, setBackupBusy] = useState(false);
  const [backupNotice, setBackupNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [restoreFile, setRestoreFile] = useState<BackupFile | null>(null);
  const [restoreName, setRestoreName] = useState("");
  const [restoreConfirmText, setRestoreConfirmText] = useState("");
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [restoreNotice, setRestoreNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [restoreOpen, setRestoreOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function saveSettings() {
    setSaving(true);
    setNotice(null);
    try {
      const result = await api<{ message: string }>("/api/settings", putBody({ ...form, logo: form.logo || null }));
      setNotice({ tone: "success", text: result.message });
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Settings could not be saved." });
    } finally {
      setSaving(false);
    }
  }

  async function handleLogo(file: File | null) {
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 1_800_000);
      setForm((prev) => ({ ...prev, logo: dataUrl }));
      setNotice(null);
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Logo could not be read." });
    }
  }

  async function createBackup() {
    setBackupBusy(true);
    setBackupNotice(null);
    try {
      const response = await fetch("/api/backup", { cache: "no-store" });
      if (!response.ok) {
        const body = await response.json().catch(() => ({ error: "Backup failed." }));
        throw new Error(body.error ?? "Backup failed.");
      }
      const blob = await response.blob();
      if (blob.size < 100) throw new Error("Backup file was empty. Please try again.");
      const disposition = response.headers.get("Content-Disposition") ?? "";
      const match = /filename="([^"]+)"/.exec(disposition);
      const filename = match?.[1] ?? `Shop_Backup_${new Date().toISOString().slice(0, 10)}.json`;

      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);

      setBackupNotice({
        tone: "success",
        text: `Download started: ${filename} (${(blob.size / 1024).toFixed(1)} KB). Check your browser downloads folder.`,
      });
    } catch (error) {
      setBackupNotice({ tone: "error", text: error instanceof Error ? error.message : "Backup could not be created." });
    } finally {
      setBackupBusy(false);
    }
  }

  async function selectRestoreFile(file: File | null) {
    setRestoreFile(null);
    setRestoreNotice(null);
    setRestoreConfirmText("");
    if (!file) return;
    setRestoreName(file.name);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as BackupFile;
      if (!parsed?.meta || parsed.meta.app !== "shop-management-bd" || !parsed.data) {
        throw new Error("This is not a valid shop management backup file.");
      }
      if (Number(parsed.meta.version) > 1) {
        throw new Error("This backup was created by a newer version of the app and cannot be restored here.");
      }
      setRestoreFile(parsed);
      setRestoreOpen(true);
    } catch (error) {
      setRestoreNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not read the backup file." });
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function runRestore() {
    if (!restoreFile) return;
    setRestoreBusy(true);
    setRestoreNotice(null);
    try {
      const result = await api<{ message: string; restored: Record<string, number> }>("/api/restore", {
        method: "POST",
        body: JSON.stringify({ confirm: true, backup: restoreFile }),
      });
      setRestoreNotice({ tone: "success", text: result.message });
      setRestoreOpen(false);
      setRestoreFile(null);
      setRestoreConfirmText("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      router.refresh();
    } catch (error) {
      setRestoreNotice({
        tone: "error",
        text: error instanceof Error ? error.message : "Restore failed. Nothing was changed.",
      });
      setRestoreOpen(false);
    } finally {
      setRestoreBusy(false);
    }
  }

  const backupCounts = restoreFile?.meta.counts ?? {};
  const totalRecords = Object.values(backupCounts).reduce((sum, count) => sum + count, 0);

  return (
    <div>
      <PageHeader
        title="Settings"
        subtitle="One saved shop profile drives the header, sidebar, invoices, receipts and reports."
        actions={
          tab !== "backup" ? (
            <button type="button" className="btn btn-primary" onClick={saveSettings} disabled={saving}>
              <Icon name="save" className="h-4 w-4" /> {saving ? "Saving…" : "Save settings"}
            </button>
          ) : null
        }
      />

      <div className="mb-4 flex flex-wrap gap-2">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition ${
              tab === item.id ? "bg-emerald-700 text-white" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      {tab === "business" ? (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader title="Business profile" subtitle="Shown across the application and on printed documents" />
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="label" htmlFor="shop-name">Shop name *</label>
                <input id="shop-name" className="input" value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="shop-mobile">Mobile number</label>
                <input id="shop-mobile" className="input" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="01XXXXXXXXX" />
              </div>
              <div>
                <label className="label" htmlFor="shop-email">Email address</label>
                <input id="shop-email" type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="shop-address">Shop address</label>
                <textarea id="shop-address" className="textarea" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="shop-country">Country</label>
                <input id="shop-country" className="input" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="shop-currency">Currency</label>
                <input id="shop-currency" className="input" value="BDT — Bangladeshi Taka (৳)" disabled />
                <p className="muted mt-1">Locked to BDT so every module stays consistent.</p>
              </div>
              <div>
                <label className="label" htmlFor="shop-timezone">Time zone</label>
                <input id="shop-timezone" className="input" value="Asia/Dhaka (GMT+6)" disabled />
              </div>
              <div>
                <label className="label" htmlFor="shop-dateformat">Date format</label>
                <input id="shop-dateformat" className="input" value="DD-MM-YYYY" disabled />
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="shop-logo">Shop logo (shown in header, sidebar, invoices and receipts)</label>
                <div className="flex flex-wrap items-center gap-3">
                  <input id="shop-logo" type="file" accept="image/*" className="input sm:max-w-xs" onChange={(e) => handleLogo(e.target.files?.[0] ?? null)} />
                  {form.logo ? (
                    <>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={form.logo} alt="Logo preview" className="h-12 w-12 rounded-lg border border-slate-200 bg-white object-contain p-1" />
                      <button type="button" className="btn btn-ghost btn-sm text-rose-600" onClick={() => setForm({ ...form, logo: "" })}>Remove logo</button>
                    </>
                  ) : null}
                </div>
                <p className="muted mt-1">Logo is stored in the database and included in your JSON backup.</p>
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader title="Saved profile preview" />
            <div className="p-4">
              <div className="rounded-xl bg-gradient-to-br from-[#07332c] to-[#07433a] p-4 text-white">
                <div className="flex items-center gap-2">
                  {form.logo ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={form.logo} alt="" className="h-10 w-10 rounded bg-white object-contain p-0.5" />
                  ) : (
                    <span className="grid h-10 w-10 place-items-center rounded bg-emerald-400/20 text-sm font-bold">{form.shopName.slice(0, 2).toUpperCase()}</span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate font-bold">{form.shopName || "Shop name"}</p>
                    <p className="truncate text-[11px] text-emerald-200/80">Retail Management</p>
                  </div>
                </div>
                <p className="mt-3 text-xs text-emerald-100/80">{form.address || "Shop address appears here"}</p>
                <p className="text-xs text-emerald-100/80">{form.mobile || "Mobile number"}</p>
              </div>
              <div className="mt-3 space-y-1 text-xs text-slate-600">
                <p className="flex justify-between"><span>Currency</span><span className="font-semibold">BDT ৳</span></p>
                <p className="flex justify-between"><span>Time zone</span><span className="font-semibold">Asia/Dhaka</span></p>
                <p className="flex justify-between"><span>Business date</span><span className="font-semibold">DD-MM-YYYY</span></p>
              </div>
              <p className="mt-3 text-[11px] text-slate-500">Click Save settings after editing. Changes apply to every page immediately.</p>
            </div>
          </Card>
        </div>
      ) : null}

      {tab === "invoice" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Document numbering" subtitle="Used for new invoices and purchase numbers" />
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="invoice-prefix">Invoice prefix</label>
                <input id="invoice-prefix" className="input" value={form.invoicePrefix} onChange={(e) => setForm({ ...form, invoicePrefix: e.target.value.toUpperCase() })} />
                <p className="muted mt-1">Example: {form.invoicePrefix || "INV"}-20260101-0001</p>
              </div>
              <div>
                <label className="label" htmlFor="purchase-prefix">Purchase prefix</label>
                <input id="purchase-prefix" className="input" value={form.purchasePrefix} onChange={(e) => setForm({ ...form, purchasePrefix: e.target.value.toUpperCase() })} />
                <p className="muted mt-1">Example: {form.purchasePrefix || "PUR"}-20260101-0001</p>
              </div>
              <label className="flex items-center gap-2 text-sm text-slate-700 sm:col-span-2">
                <input type="checkbox" checked={form.showLogoOnPrint} onChange={(e) => setForm({ ...form, showLogoOnPrint: e.target.checked })} className="h-4 w-4 rounded border-slate-300" />
                Show shop logo on printed invoices and receipts
              </label>
            </div>
          </Card>

          <Card>
            <CardHeader title="Invoice & receipt text" subtitle="Printed at the bottom of documents" />
            <div className="grid gap-3 p-4">
              <div>
                <label className="label" htmlFor="invoice-note">Invoice footer message</label>
                <input id="invoice-note" className="input" value={form.invoiceNote} onChange={(e) => setForm({ ...form, invoiceNote: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="invoice-terms">Terms & conditions</label>
                <textarea id="invoice-terms" className="textarea" value={form.invoiceTerms} onChange={(e) => setForm({ ...form, invoiceTerms: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="receipt-footer">Receipt footer</label>
                <input id="receipt-footer" className="input" value={form.receiptFooter} onChange={(e) => setForm({ ...form, receiptFooter: e.target.value })} />
              </div>
              <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-600">
                Invoices print on A4 from the sale page, receipts print at 80mm. Test both from any saved sale.
              </div>
            </div>
          </Card>
        </div>
      ) : null}

      {tab === "security" ? <SecurityPanel /> : null}

      {tab === "backup" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Create backup" subtitle="Downloads every business table as a real JSON file" />
            <div className="space-y-3 p-4">
              {backupNotice ? <Alert tone={backupNotice.tone}>{backupNotice.text}</Alert> : null}
              <p className="text-sm text-slate-600">
                Included: settings (shop name, logo, invoice text), categories, products (with opening stock and
                images), stock movements, sales & sale items, purchases & purchase items, customers, suppliers,
                customer payments, supplier payments and expenses.
              </p>
              <ul className="grid grid-cols-2 gap-1 text-xs text-slate-600">
                {[
                  "Products & categories",
                  "Inventory & movements",
                  "Sales & invoice items",
                  "Purchases & items",
                  "Customers & payments",
                  "Suppliers & payments",
                  "Expenses",
                  "Shop settings & logo",
                  "Admin account (hashed)",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-1.5">
                    <Icon name="check" className="h-3.5 w-3.5 text-emerald-600" /> {item}
                  </li>
                ))}
              </ul>
              <button type="button" className="btn btn-primary w-full" onClick={createBackup} disabled={backupBusy}>
                <Icon name="download" className="h-4 w-4" /> {backupBusy ? "Preparing download…" : "Create backup & download file"}
              </button>
              <p className="text-[11px] text-slate-500">
                File name format: <code>Shop_Backup_DD-MM-YYYY.json</code>. Success is shown only after your browser
                starts the download. Store the file somewhere safe — it is your only copy.
              </p>
            </div>
          </Card>

          <Card>
            <CardHeader title="Restore backup" subtitle="Replaces all current data with the backup contents" />
            <div className="space-y-3 p-4">
              {restoreNotice ? <Alert tone={restoreNotice.tone}>{restoreNotice.text}</Alert> : null}
              <div>
                <label className="label" htmlFor="restore-file">Select a backup file (.json)</label>
                <input
                  id="restore-file"
                  ref={fileInputRef}
                  type="file"
                  accept="application/json,.json"
                  className="input"
                  onChange={(e) => selectRestoreFile(e.target.files?.[0] ?? null)}
                />
                {restoreName ? <p className="muted mt-1">Selected: {restoreName}</p> : null}
              </div>
              <Alert tone="warning">
                Restoring deletes all current products, sales, purchases, customers, suppliers, payments and expenses,
                then imports the backup. Always download a fresh backup first. After restoring, sign in again with the
                admin username and password stored in that backup.
              </Alert>
              <button type="button" className="btn btn-secondary w-full" onClick={() => { setRestoreFile(null); setRestoreName(""); if (fileInputRef.current) fileInputRef.current.value = ""; }} disabled={restoreBusy}>
                Clear selection
              </button>
              <p className="text-[11px] text-slate-500">
                Validation happens before any data is changed. Restore runs inside a single database transaction — if
                anything fails, existing data is kept intact.
              </p>
            </div>
          </Card>
        </div>
      ) : null}

      <Modal
        open={restoreOpen && Boolean(restoreFile)}
        title="Confirm restore"
        description="This action replaces all business data."
        onClose={() => setRestoreOpen(false)}
        size="md"
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setRestoreOpen(false)} disabled={restoreBusy}>Cancel</button>
            <button
              type="button"
              className="btn btn-danger"
              onClick={runRestore}
              disabled={restoreBusy || restoreConfirmText !== "RESTORE"}
            >
              {restoreBusy ? "Restoring…" : "Restore backup now"}
            </button>
          </>
        }
      >
        <div className="space-y-3 text-sm text-slate-700">
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
            <p className="font-semibold">Warning: current data will be replaced.</p>
            <p className="mt-1">Products, stock, sales, purchases, customers, suppliers, payments and expenses stored now will be deleted and replaced by this backup.</p>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 text-xs">
            <p className="flex justify-between"><span>File</span><span className="font-semibold">{restoreName}</span></p>
            <p className="flex justify-between"><span>Backup shop</span><span className="font-semibold">{restoreFile?.meta.shopName}</span></p>
            <p className="flex justify-between"><span>Exported</span><span className="font-semibold">{restoreFile?.meta.exportedAt ? new Date(restoreFile.meta.exportedAt).toLocaleString() : "—"}</span></p>
            <p className="flex justify-between"><span>Records</span><span className="font-semibold">{totalRecords}</span></p>
            <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 border-t border-slate-100 pt-2">
              {Object.entries(backupCounts).map(([key, count]) => (
                <p key={key} className="flex justify-between"><span className="capitalize text-slate-500">{key}</span><span className="font-semibold">{count}</span></p>
              ))}
            </div>
          </div>
          <div>
            <label className="label" htmlFor="restore-confirm">Type RESTORE to confirm</label>
            <input id="restore-confirm" className="input" value={restoreConfirmText} onChange={(e) => setRestoreConfirmText(e.target.value.toUpperCase())} placeholder="RESTORE" />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="green">Transaction protected</Badge>
            <span className="text-[11px] text-slate-500">Existing data is only deleted if the whole import succeeds.</span>
          </div>
          {backupNotice ? <p className="text-[11px] text-slate-500">Latest downloaded backup: {backupNotice.text}</p> : null}
          <p className="text-[11px] text-slate-500">All restored amounts keep their BDT (৳) values.</p>
        </div>
      </Modal>
    </div>
  );
}
