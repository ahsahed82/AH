import { eq, or, sql } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { products, purchaseItems, saleItems } from "@/db/schema";
import {
  ApiError,
  fail,
  idFromParam,
  ok,
  optionalText,
  parseMoney,
  parseQuantity,
  readJson,
  requiredText,
} from "@/lib/api-helpers";
import { money, qty } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const productId = idFromParam({ id });
    const body = await readJson(request);
    const [existing] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
    if (!existing) throw new ApiError("Product not found.", 404);

    const name = requiredText(body.name ?? existing.name, "Product name", 160);
    const sku = requiredText(body.sku ?? existing.sku, "SKU", 60);
    const barcode = optionalText(body.barcode, 60);
    const duplicate = await db
      .select({ id: products.id })
      .from(products)
      .where(
        barcode
          ? or(eq(products.sku, sku), eq(products.barcode, barcode))
          : eq(products.sku, sku),
      );
    if (duplicate.some((row) => row.id !== productId)) {
      throw new ApiError("Another product already uses this SKU or barcode.", 409);
    }

    const imageUrl = body.imageUrl === undefined ? existing.imageUrl : optionalText(body.imageUrl, 2_000_000);
    if (imageUrl && !imageUrl.startsWith("data:image/") && !/^https?:\/\//.test(imageUrl)) {
      throw new ApiError("Product image must be an uploaded image.");
    }

    const [updated] = await db
      .update(products)
      .set({
        name,
        sku,
        barcode,
        categoryId: body.categoryId ? Number(body.categoryId) : null,
        unit: requiredText(body.unit ?? existing.unit, "Unit", 20),
        purchasePrice: money(parseMoney(body.purchasePrice ?? existing.purchasePrice, "Purchase price")),
        sellingPrice: money(parseMoney(body.sellingPrice ?? existing.sellingPrice, "Selling price")),
        minStock: qty(parseQuantity(body.minStock ?? existing.minStock, "Minimum stock", { allowZero: true })),
        imageUrl,
        description: body.description === undefined ? existing.description : optionalText(body.description, 2000),
        isActive: body.isActive === undefined ? existing.isActive : body.isActive !== false,
        updatedAt: new Date(),
      })
      .where(eq(products.id, productId))
      .returning();

    return ok({ product: updated, message: "Product updated." });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const { id } = await params;
    const productId = idFromParam({ id });
    const [saleUse] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(saleItems)
      .where(eq(saleItems.productId, productId));
    const [purchaseUse] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(purchaseItems)
      .where(eq(purchaseItems.productId, productId));
    if ((saleUse?.count ?? 0) > 0 || (purchaseUse?.count ?? 0) > 0) {
      throw new ApiError(
        "This product has sales or purchase history and cannot be deleted. Mark it inactive instead to keep reports accurate.",
        409,
      );
    }
    const deleted = await db.delete(products).where(eq(products.id, productId)).returning({ id: products.id });
    if (deleted.length === 0) throw new ApiError("Product not found.", 404);
    return ok({ message: "Product deleted." });
  } catch (error) {
    return fail(error);
  }
}
