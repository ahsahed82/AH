import Link from "next/link";
import { notFound } from "next/navigation";
import { Invoice } from "@/components/Invoice";
import { Icon } from "@/components/icons";
import { Badge, Card, CardHeader, PageHeader } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { getSale } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { SaleActions } from "./SaleActions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sale details" };

export default async function SaleDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const saleId = Number(id);
  if (!Number.isInteger(saleId)) notFound();
  const [data, shop] = await Promise.all([getSale(saleId), getSettings()]);
  if (!data) notFound();

  return (
    <div>
      <PageHeader
        title={`Invoice ${data.sale.invoiceNo}`}
        subtitle={`${formatDateTime(data.sale.saleDate)} · ${data.customerName ?? "Walk-in customer"}`}
        actions={
          <>
            <Link href="/sales" className="btn btn-secondary">
              <Icon name="back" className="h-4 w-4" /> All sales
            </Link>
            <Link href={`/print/receipt/${data.sale.id}`} target="_blank" className="btn btn-secondary">
              <Icon name="print" className="h-4 w-4" /> Receipt (80mm)
            </Link>
            <Link href={`/print/sale/${data.sale.id}`} target="_blank" className="btn btn-primary">
              <Icon name="print" className="h-4 w-4" /> Print invoice (A4)
            </Link>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="xl:col-span-8">
          <div className="card overflow-hidden">
            <Invoice
              shop={shop}
              sale={data.sale}
              items={data.items}
              customer={
                data.customerName
                  ? { name: data.customerName, mobile: data.customerMobile, address: data.customerAddress }
                  : null
              }
            />
          </div>
        </div>

        <div className="space-y-4 xl:col-span-4">
          <Card>
            <CardHeader title="Summary" />
            <div className="space-y-2 p-4 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Invoice</span><span className="font-semibold">{data.sale.invoiceNo}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Date</span><span>{formatDate(data.sale.saleDate)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Payment method</span><span>{data.sale.paymentMethod}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Grand total</span><span className="font-semibold">{formatMoney(data.sale.total)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Paid at sale</span><span>{formatMoney(data.sale.paid)}</span></div>
              <div className="flex justify-between border-t border-slate-100 pt-2">
                <span className="text-slate-500">Due at sale</span>
                {Number(data.sale.due) > 0 ? <Badge tone="amber">{formatMoney(data.sale.due)}</Badge> : <Badge tone="green">Paid</Badge>}
              </div>
              {data.customerName ? (
                <div className="border-t border-slate-100 pt-2">
                  <p className="text-slate-500">Customer</p>
                  <Link href={`/customers/${data.sale.customerId}`} className="font-semibold text-emerald-800 hover:underline">
                    {data.customerName}
                  </Link>
                  {data.customerMobile ? <p className="text-xs text-slate-500">{data.customerMobile}</p> : null}
                </div>
              ) : null}
              {data.sale.note ? <p className="rounded bg-slate-50 p-2 text-xs text-slate-600">{data.sale.note}</p> : null}
            </div>
          </Card>

          <Card>
            <CardHeader title="Payments received" subtitle="Recorded against this invoice" />
            {data.payments.length === 0 ? (
              <p className="px-4 py-4 text-sm text-slate-500">No later payments recorded for this invoice.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {data.payments.map((payment) => (
                  <li key={payment.id} className="flex items-center justify-between px-4 py-2 text-sm">
                    <div>
                      <p className="font-medium">{formatMoney(payment.amount)}</p>
                      <p className="text-[11px] text-slate-500">{formatDateTime(payment.paymentDate)} · {payment.paymentMethod}</p>
                    </div>
                    <Badge tone="green">Received</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Actions" subtitle="These actions update stock and balances" />
            <div className="p-4">
              <SaleActions
                saleId={data.sale.id}
                invoiceNo={data.sale.invoiceNo}
                total={Number(data.sale.total)}
                due={Number(data.sale.due)}
                customerId={data.sale.customerId}
                customerName={data.customerName}
              />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
