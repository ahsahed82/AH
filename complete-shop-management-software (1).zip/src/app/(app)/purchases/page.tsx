import { getPurchasesList } from "@/lib/queries";
import { PurchasesClient } from "./PurchasesClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Purchases" };

export default async function PurchasesPage() {
  const purchases = await getPurchasesList();
  return <PurchasesClient purchases={purchases} />;
}
