import { destroySession } from "@/lib/auth";
import { fail, ok } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().includes("application/json")) {
      return Response.json({ error: "Unsupported request format." }, { status: 415 });
    }
    await destroySession();
    return ok({ message: "Signed out successfully." });
  } catch (error) {
    return fail(error);
  }
}
