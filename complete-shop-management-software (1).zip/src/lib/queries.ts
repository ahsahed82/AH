import { and, asc, desc, eq, ilike, or, sql, type AnyColumn, type SQL } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  customerPayments,
  customers,
  expenses,
  products,
  purchaseItems,
  purchases,
  saleItems,
  sales,
  stockMovements,
  supplierPayments,
  suppliers,
} from "@/db/schema";

/* --------------------------------- helpers --------------------------------- */
export function dhakaDate(column: AnyColumn | SQL): SQL {
  return sql`(${column} at time zone 'Asia/Dhaka')::date`;
}

export function dateRange(column: AnyColumn, from?: string | null, to?: string | null): SQL[] {
  const conditions: SQL[] = [];
  if (from) conditions.push(sql`${dhakaDate(column)} >= ${from}::date`);
  if (to) conditions.push(sql`${dhakaDate(column)} <= ${to}::date`);
  return conditions;
}

function combine(conditions: (SQL | undefined)[]): SQL | undefined {
  const usable = conditions.filter((c): c is SQL => Boolean(c));
  if (usable.length === 0) return undefined;
  if (usable.length === 1) return usable[0];
  return and(...usable);
}

/* --------------------------------- dashboard -------------------------------- */
export type DashboardData = Awaited<ReturnType<typeof getDashboard>>;

export async function getDashboard() {
  const [salesAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${sales.total}), 0)`,
      count: sql<number>`count(*)::int`,
      todayTotal: sql<string>`coalesce(sum(case when ${dhakaDate(sales.saleDate)} = (now() at time zone 'Asia/Dhaka')::date then ${sales.total} else 0 end), 0)`,
      todayCount: sql<number>`count(case when ${dhakaDate(sales.saleDate)} = (now() at time zone 'Asia/Dhaka')::date then 1 end)::int`,
      monthTotal: sql<string>`coalesce(sum(case when ${dhakaDate(sales.saleDate)} >= date_trunc('month', (now() at time zone 'Asia/Dhaka')::date) then ${sales.total} else 0 end), 0)`,
      due: sql<string>`coalesce(sum(${sales.due}), 0)`,
    })
    .from(sales);

  const [purchaseAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${purchases.total}), 0)`,
      count: sql<number>`count(*)::int`,
      todayTotal: sql<string>`coalesce(sum(case when ${dhakaDate(purchases.purchaseDate)} = (now() at time zone 'Asia/Dhaka')::date then ${purchases.total} else 0 end), 0)`,
      due: sql<string>`coalesce(sum(${purchases.due}), 0)`,
    })
    .from(purchases);

  const [expenseAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${expenses.amount}), 0)`,
      monthTotal: sql<string>`coalesce(sum(case when ${dhakaDate(expenses.expenseDate)} >= date_trunc('month', (now() at time zone 'Asia/Dhaka')::date) then ${expenses.amount} else 0 end), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(expenses);

  const [cogsAgg] = await db
    .select({
      cogs: sql<string>`coalesce(sum(${saleItems.quantity} * ${saleItems.costPrice}), 0)`,
    })
    .from(saleItems);

  const [customerPayAgg] = await db
    .select({ total: sql<string>`coalesce(sum(${customerPayments.amount}), 0)` })
    .from(customerPayments);
  const [supplierPayAgg] = await db
    .select({ total: sql<string>`coalesce(sum(${supplierPayments.amount}), 0)` })
    .from(supplierPayments);
  const [openingCustomerAgg] = await db
    .select({ total: sql<string>`coalesce(sum(${customers.openingBalance}), 0)` })
    .from(customers);
  const [openingSupplierAgg] = await db
    .select({ total: sql<string>`coalesce(sum(${suppliers.openingBalance}), 0)` })
    .from(suppliers);

  const [productAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      active: sql<number>`count(case when ${products.isActive} then 1 end)::int`,
      stockValue: sql<string>`coalesce(sum(${products.currentStock} * ${products.purchasePrice}), 0)`,
      stockUnits: sql<string>`coalesce(sum(${products.currentStock}), 0)`,
      lowStock: sql<number>`count(case when ${products.currentStock} > 0 and ${products.currentStock} <= ${products.minStock} then 1 end)::int`,
      outOfStock: sql<number>`count(case when ${products.currentStock} <= 0 then 1 end)::int`,
    })
    .from(products);

  const [customerCount] = await db.select({ count: sql<number>`count(*)::int` }).from(customers);
  const [supplierCount] = await db.select({ count: sql<number>`count(*)::int` }).from(suppliers);

  const recentSales = await db
    .select({
      id: sales.id,
      invoiceNo: sales.invoiceNo,
      saleDate: sales.saleDate,
      total: sales.total,
      paid: sales.paid,
      due: sales.due,
      paymentMethod: sales.paymentMethod,
      customerName: customers.name,
    })
    .from(sales)
    .leftJoin(customers, eq(sales.customerId, customers.id))
    .orderBy(desc(sales.saleDate), desc(sales.id))
    .limit(6);

  const lowStockProducts = await db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      unit: products.unit,
      currentStock: products.currentStock,
      minStock: products.minStock,
    })
    .from(products)
    .where(and(sql`${products.currentStock} <= ${products.minStock}`, eq(products.isActive, true)))
    .orderBy(asc(products.currentStock))
    .limit(6);

  const monthlyRows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${sales.saleDate} at time zone 'Asia/Dhaka'), 'YYYY-MM')`,
      total: sql<string>`coalesce(sum(${sales.total}), 0)`,
    })
    .from(sales)
    .groupBy(sql`1`)
    .orderBy(sql`1`);
  const monthlyPurchases = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${purchases.purchaseDate} at time zone 'Asia/Dhaka'), 'YYYY-MM')`,
      total: sql<string>`coalesce(sum(${purchases.total}), 0)`,
    })
    .from(purchases)
    .groupBy(sql`1`)
    .orderBy(sql`1`);

  const dailyRows = await db
    .select({
      day: sql<string>`to_char(${sales.saleDate} at time zone 'Asia/Dhaka', 'YYYY-MM-DD')`,
      total: sql<string>`coalesce(sum(${sales.total}), 0)`,
    })
    .from(sales)
    .where(sql`${sales.saleDate} at time zone 'Asia/Dhaka' >= (now() at time zone 'Asia/Dhaka')::date - interval '6 days'`)
    .groupBy(sql`1`)
    .orderBy(sql`1`);

  const topProducts = await db
    .select({
      name: saleItems.productName,
      qty: sql<string>`sum(${saleItems.quantity})`,
      revenue: sql<string>`sum(${saleItems.total})`,
    })
    .from(saleItems)
    .groupBy(saleItems.productName)
    .orderBy(desc(sql`sum(${saleItems.total})`))
    .limit(5);

  const salesTotal = Number(salesAgg?.total ?? 0);
  const cogs = Number(cogsAgg?.cogs ?? 0);
  const expenseTotal = Number(expenseAgg?.total ?? 0);
  const customerDue =
    Number(openingCustomerAgg?.total ?? 0) +
    Number(salesAgg?.due ?? 0) -
    Number(customerPayAgg?.total ?? 0);
  const supplierDue =
    Number(openingSupplierAgg?.total ?? 0) +
    Number(purchaseAgg?.due ?? 0) -
    Number(supplierPayAgg?.total ?? 0);

  // Build the last 6 months series (Dhaka calendar months).
  const months: { key: string; label: string; sales: number; purchases: number }[] = [];
  const cursor = new Date();
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(Date.UTC(cursor.getUTCFullYear(), cursor.getUTCMonth() - i, 1));
    const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
    months.push({
      key,
      label: new Intl.DateTimeFormat("en-GB", { month: "short", timeZone: "UTC" }).format(d),
      sales: Number(monthlyRows.find((r) => r.month === key)?.total ?? 0),
      purchases: Number(monthlyPurchases.find((r) => r.month === key)?.total ?? 0),
    });
  }

  const days: { key: string; label: string; sales: number }[] = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - i);
    const key = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Dhaka",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(d);
    days.push({
      key,
      label: new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", timeZone: "Asia/Dhaka" }).format(d),
      sales: Number(dailyRows.find((r) => r.day === key)?.total ?? 0),
    });
  }

  return {
    salesTotal,
    salesCount: salesAgg?.count ?? 0,
    todaySales: Number(salesAgg?.todayTotal ?? 0),
    todaySalesCount: salesAgg?.todayCount ?? 0,
    monthSales: Number(salesAgg?.monthTotal ?? 0),
    totalPurchases: Number(purchaseAgg?.total ?? 0),
    purchaseCount: purchaseAgg?.count ?? 0,
    totalExpenses: expenseTotal,
    expenseCount: expenseAgg?.count ?? 0,
    monthExpenses: Number(expenseAgg?.monthTotal ?? 0),
    cogs,
    grossProfit: salesTotal - cogs,
    netProfit: salesTotal - cogs - expenseTotal,
    totalProducts: productAgg?.count ?? 0,
    activeProducts: productAgg?.active ?? 0,
    stockValue: Number(productAgg?.stockValue ?? 0),
    stockUnits: Number(productAgg?.stockUnits ?? 0),
    lowStockCount: productAgg?.lowStock ?? 0,
    outOfStockCount: productAgg?.outOfStock ?? 0,
    customerCount: customerCount?.count ?? 0,
    supplierCount: supplierCount?.count ?? 0,
    customerPaid: Number(customerPayAgg?.total ?? 0),
    supplierPaid: Number(supplierPayAgg?.total ?? 0),
    customerDue,
    supplierDue,
    recentSales,
    lowStockProducts,
    months,
    days,
    topProducts: topProducts.map((p) => ({
      name: p.name,
      qty: Number(p.qty),
      revenue: Number(p.revenue),
    })),
  };
}

/* --------------------------------- products -------------------------------- */
export type ProductRow = {
  id: number;
  name: string;
  sku: string;
  barcode: string | null;
  categoryId: number | null;
  categoryName: string | null;
  unit: string;
  purchasePrice: string;
  sellingPrice: string;
  currentStock: string;
  minStock: string;
  imageUrl: string | null;
  description: string | null;
  isActive: boolean;
};

export async function getProducts(options?: {
  search?: string;
  categoryId?: number;
  stock?: "all" | "low" | "out" | "in";
}): Promise<ProductRow[]> {
  const conditions: SQL[] = [];
  if (options?.search) {
    const term = `%${options.search}%`;
    const search = or(
      ilike(products.name, term),
      ilike(products.sku, term),
      ilike(products.barcode, term),
    );
    if (search) conditions.push(search);
  }
  if (options?.categoryId) conditions.push(eq(products.categoryId, options.categoryId));
  if (options?.stock === "low") conditions.push(sql`${products.currentStock} > 0 and ${products.currentStock} <= ${products.minStock}`);
  if (options?.stock === "out") conditions.push(sql`${products.currentStock} <= 0`);
  if (options?.stock === "in") conditions.push(sql`${products.currentStock} > ${products.minStock}`);

  return db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      barcode: products.barcode,
      categoryId: products.categoryId,
      categoryName: categories.name,
      unit: products.unit,
      purchasePrice: products.purchasePrice,
      sellingPrice: products.sellingPrice,
      currentStock: products.currentStock,
      minStock: products.minStock,
      imageUrl: products.imageUrl,
      description: products.description,
      isActive: products.isActive,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(combine(conditions))
    .orderBy(asc(products.name));
}

export async function getCategories() {
  return db.select().from(categories).orderBy(asc(categories.name));
}

/* --------------------------------- customers ------------------------------- */
const customerSalesTotal = sql<string>`coalesce((select sum(s.total) from sales s where s.customer_id = ${customers.id}), 0)`;
const customerInitialPaid = sql<string>`coalesce((select sum(s.paid) from sales s where s.customer_id = ${customers.id}), 0)`;
const customerLaterPaid = sql<string>`coalesce((select sum(p.amount) from customer_payments p where p.customer_id = ${customers.id}), 0)`;
const customerSaleCount = sql<number>`(select count(*) from sales s where s.customer_id = ${customers.id})::int`;

export type CustomerRow = {
  id: number;
  name: string;
  mobile: string | null;
  address: string | null;
  openingBalance: string;
  totalSales: string;
  totalPaid: string;
  due: string;
  saleCount: number;
};

export async function getCustomers(search?: string): Promise<CustomerRow[]> {
  const conditions: SQL[] = [];
  if (search) {
    const term = `%${search}%`;
    const clause = or(ilike(customers.name, term), ilike(customers.mobile, term), ilike(customers.address, term));
    if (clause) conditions.push(clause);
  }
  return db
    .select({
      id: customers.id,
      name: customers.name,
      mobile: customers.mobile,
      address: customers.address,
      openingBalance: customers.openingBalance,
      totalSales: customerSalesTotal,
      totalPaid: sql<string>`${customerInitialPaid} + ${customerLaterPaid}`,
      due: sql<string>`${customers.openingBalance} + ${customerSalesTotal} - ${customerInitialPaid} - ${customerLaterPaid}`,
      saleCount: customerSaleCount,
    })
    .from(customers)
    .where(combine(conditions))
    .orderBy(asc(customers.name));
}

export async function getCustomerDetail(id: number) {
  const [customer] = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  if (!customer) return null;
  const saleRows = await db
    .select()
    .from(sales)
    .where(eq(sales.customerId, id))
    .orderBy(desc(sales.saleDate), desc(sales.id));
  const paymentRows = await db
    .select()
    .from(customerPayments)
    .where(eq(customerPayments.customerId, id))
    .orderBy(desc(customerPayments.paymentDate), desc(customerPayments.id));
  const totalSales = saleRows.reduce((sum, r) => sum + Number(r.total), 0);
  const salePaid = saleRows.reduce((sum, r) => sum + Number(r.paid), 0);
  const laterPaid = paymentRows.reduce((sum, r) => sum + Number(r.amount), 0);
  const due = Number(customer.openingBalance) + totalSales - salePaid - laterPaid;
  return {
    customer,
    sales: saleRows,
    payments: paymentRows,
    totals: { totalSales, totalPaid: salePaid + laterPaid, due, salePaid, laterPaid },
  };
}

/* --------------------------------- suppliers ------------------------------- */
const supplierPurchaseTotal = sql<string>`coalesce((select sum(p.total) from purchases p where p.supplier_id = ${suppliers.id}), 0)`;
const supplierInitialPaid = sql<string>`coalesce((select sum(p.paid) from purchases p where p.supplier_id = ${suppliers.id}), 0)`;
const supplierLaterPaid = sql<string>`coalesce((select sum(p.amount) from supplier_payments p where p.supplier_id = ${suppliers.id}), 0)`;
const supplierPurchaseCount = sql<number>`(select count(*) from purchases p where p.supplier_id = ${suppliers.id})::int`;

export type SupplierRow = {
  id: number;
  name: string;
  mobile: string | null;
  address: string | null;
  openingBalance: string;
  totalPurchases: string;
  totalPaid: string;
  due: string;
  purchaseCount: number;
};

export async function getSuppliers(search?: string): Promise<SupplierRow[]> {
  const conditions: SQL[] = [];
  if (search) {
    const term = `%${search}%`;
    const clause = or(ilike(suppliers.name, term), ilike(suppliers.mobile, term), ilike(suppliers.address, term));
    if (clause) conditions.push(clause);
  }
  return db
    .select({
      id: suppliers.id,
      name: suppliers.name,
      mobile: suppliers.mobile,
      address: suppliers.address,
      openingBalance: suppliers.openingBalance,
      totalPurchases: supplierPurchaseTotal,
      totalPaid: sql<string>`${supplierInitialPaid} + ${supplierLaterPaid}`,
      due: sql<string>`${suppliers.openingBalance} + ${supplierPurchaseTotal} - ${supplierInitialPaid} - ${supplierLaterPaid}`,
      purchaseCount: supplierPurchaseCount,
    })
    .from(suppliers)
    .where(combine(conditions))
    .orderBy(asc(suppliers.name));
}

export async function getSupplierDetail(id: number) {
  const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
  if (!supplier) return null;
  const purchaseRows = await db
    .select()
    .from(purchases)
    .where(eq(purchases.supplierId, id))
    .orderBy(desc(purchases.purchaseDate), desc(purchases.id));
  const paymentRows = await db
    .select()
    .from(supplierPayments)
    .where(eq(supplierPayments.supplierId, id))
    .orderBy(desc(supplierPayments.paymentDate), desc(supplierPayments.id));
  const totalPurchases = purchaseRows.reduce((sum, r) => sum + Number(r.total), 0);
  const purchasePaid = purchaseRows.reduce((sum, r) => sum + Number(r.paid), 0);
  const laterPaid = paymentRows.reduce((sum, r) => sum + Number(r.amount), 0);
  const due = Number(supplier.openingBalance) + totalPurchases - purchasePaid - laterPaid;
  return {
    supplier,
    purchases: purchaseRows,
    payments: paymentRows,
    totals: { totalPurchases, totalPaid: purchasePaid + laterPaid, due, purchasePaid, laterPaid },
  };
}

/* ----------------------------------- sales --------------------------------- */
export type SalesListFilters = {
  search?: string;
  from?: string;
  to?: string;
  method?: string;
  dueOnly?: boolean;
};

export async function getSalesList(filters?: SalesListFilters) {
  const conditions: SQL[] = [];
  if (filters?.search) {
    const term = `%${filters.search}%`;
    const clause = or(ilike(sales.invoiceNo, term), ilike(customers.name, term), ilike(customers.mobile, term));
    if (clause) conditions.push(clause);
  }
  conditions.push(...dateRange(sales.saleDate, filters?.from, filters?.to));
  if (filters?.method) conditions.push(eq(sales.paymentMethod, filters.method));
  if (filters?.dueOnly) conditions.push(sql`${sales.due} > 0`);

  return db
    .select({
      id: sales.id,
      invoiceNo: sales.invoiceNo,
      saleDate: sales.saleDate,
      customerId: sales.customerId,
      customerName: customers.name,
      customerMobile: customers.mobile,
      subtotal: sales.subtotal,
      discount: sales.discount,
      total: sales.total,
      paid: sales.paid,
      due: sales.due,
      paymentMethod: sales.paymentMethod,
      itemCount: sql<number>`(select count(*) from sale_items si where si.sale_id = ${sales.id})::int`,
    })
    .from(sales)
    .leftJoin(customers, eq(sales.customerId, customers.id))
    .where(combine(conditions))
    .orderBy(desc(sales.saleDate), desc(sales.id));
}

export async function getSale(id: number) {
  const [sale] = await db
    .select({
      sale: sales,
      customerName: customers.name,
      customerMobile: customers.mobile,
      customerAddress: customers.address,
    })
    .from(sales)
    .leftJoin(customers, eq(sales.customerId, customers.id))
    .where(eq(sales.id, id))
    .limit(1);
  if (!sale) return null;
  const items = await db.select().from(saleItems).where(eq(saleItems.saleId, id)).orderBy(asc(saleItems.id));
  const payments = await db
    .select()
    .from(customerPayments)
    .where(eq(customerPayments.saleId, id))
    .orderBy(asc(customerPayments.paymentDate));
  return { ...sale, items, payments };
}

/* --------------------------------- purchases ------------------------------- */
export type PurchaseListFilters = {
  search?: string;
  from?: string;
  to?: string;
  dueOnly?: boolean;
};

export async function getPurchasesList(filters?: PurchaseListFilters) {
  const conditions: SQL[] = [];
  if (filters?.search) {
    const term = `%${filters.search}%`;
    const clause = or(ilike(purchases.purchaseNo, term), ilike(suppliers.name, term), ilike(suppliers.mobile, term));
    if (clause) conditions.push(clause);
  }
  conditions.push(...dateRange(purchases.purchaseDate, filters?.from, filters?.to));
  if (filters?.dueOnly) conditions.push(sql`${purchases.due} > 0`);

  return db
    .select({
      id: purchases.id,
      purchaseNo: purchases.purchaseNo,
      purchaseDate: purchases.purchaseDate,
      supplierId: purchases.supplierId,
      supplierName: suppliers.name,
      supplierMobile: suppliers.mobile,
      subtotal: purchases.subtotal,
      discount: purchases.discount,
      total: purchases.total,
      paid: purchases.paid,
      due: purchases.due,
      paymentMethod: purchases.paymentMethod,
      itemCount: sql<number>`(select count(*) from purchase_items pi where pi.purchase_id = ${purchases.id})::int`,
    })
    .from(purchases)
    .leftJoin(suppliers, eq(purchases.supplierId, suppliers.id))
    .where(combine(conditions))
    .orderBy(desc(purchases.purchaseDate), desc(purchases.id));
}

export async function getPurchase(id: number) {
  const [row] = await db
    .select({
      purchase: purchases,
      supplierName: suppliers.name,
      supplierMobile: suppliers.mobile,
      supplierAddress: suppliers.address,
    })
    .from(purchases)
    .leftJoin(suppliers, eq(purchases.supplierId, suppliers.id))
    .where(eq(purchases.id, id))
    .limit(1);
  if (!row) return null;
  const items = await db
    .select()
    .from(purchaseItems)
    .where(eq(purchaseItems.purchaseId, id))
    .orderBy(asc(purchaseItems.id));
  const payments = await db
    .select()
    .from(supplierPayments)
    .where(eq(supplierPayments.purchaseId, id))
    .orderBy(asc(supplierPayments.paymentDate));
  return { ...row, items, payments };
}

/* --------------------------------- expenses -------------------------------- */
export async function getExpenses(filters?: { search?: string; from?: string; to?: string; category?: string }) {
  const conditions: SQL[] = [];
  if (filters?.search) {
    const term = `%${filters.search}%`;
    const clause = or(ilike(expenses.description, term), ilike(expenses.category, term));
    if (clause) conditions.push(clause);
  }
  conditions.push(...dateRange(expenses.expenseDate, filters?.from, filters?.to));
  if (filters?.category) conditions.push(eq(expenses.category, filters.category));
  return db
    .select()
    .from(expenses)
    .where(combine(conditions))
    .orderBy(desc(expenses.expenseDate), desc(expenses.id));
}

/* -------------------------------- inventory -------------------------------- */
export async function getStockMovements(filters?: { productId?: number; type?: string; limit?: number }) {
  const conditions: SQL[] = [];
  if (filters?.productId) conditions.push(eq(stockMovements.productId, filters.productId));
  if (filters?.type) conditions.push(eq(stockMovements.type, filters.type));
  return db
    .select({
      id: stockMovements.id,
      productId: stockMovements.productId,
      productName: products.name,
      sku: products.sku,
      unit: products.unit,
      type: stockMovements.type,
      quantity: stockMovements.quantity,
      referenceNo: stockMovements.referenceNo,
      note: stockMovements.note,
      createdAt: stockMovements.createdAt,
    })
    .from(stockMovements)
    .leftJoin(products, eq(stockMovements.productId, products.id))
    .where(combine(conditions))
    .orderBy(desc(stockMovements.createdAt), desc(stockMovements.id))
    .limit(filters?.limit ?? 200);
}

/* --------------------------------- reports --------------------------------- */
export async function getReportData(filters: { from: string; to: string }) {
  const { from, to } = filters;
  const salesConditions = dateRange(sales.saleDate, from, to);
  const purchaseConditions = dateRange(purchases.purchaseDate, from, to);
  const expenseConditions = dateRange(expenses.expenseDate, from, to);

  const [salesAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${sales.total}), 0)`,
      subtotal: sql<string>`coalesce(sum(${sales.subtotal}), 0)`,
      discount: sql<string>`coalesce(sum(${sales.discount}), 0)`,
      paid: sql<string>`coalesce(sum(${sales.paid}), 0)`,
      due: sql<string>`coalesce(sum(${sales.due}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(sales)
    .where(and(...salesConditions));

  const [cogsAgg] = await db
    .select({ cogs: sql<string>`coalesce(sum(${saleItems.quantity} * ${saleItems.costPrice}), 0)` })
    .from(saleItems)
    .innerJoin(sales, eq(saleItems.saleId, sales.id))
    .where(and(...salesConditions));

  const [purchaseAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${purchases.total}), 0)`,
      paid: sql<string>`coalesce(sum(${purchases.paid}), 0)`,
      due: sql<string>`coalesce(sum(${purchases.due}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(purchases)
    .where(and(...purchaseConditions));

  const [expenseAgg] = await db
    .select({
      total: sql<string>`coalesce(sum(${expenses.amount}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(expenses)
    .where(and(...expenseConditions));

  const dailySales = await db
    .select({
      day: sql<string>`to_char(${sales.saleDate} at time zone 'Asia/Dhaka', 'YYYY-MM-DD')`,
      total: sql<string>`coalesce(sum(${sales.total}), 0)`,
      paid: sql<string>`coalesce(sum(${sales.paid}), 0)`,
      due: sql<string>`coalesce(sum(${sales.due}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(sales)
    .where(and(...salesConditions))
    .groupBy(sql`1`)
    .orderBy(desc(sql`1`));

  const expensesByCategory = await db
    .select({
      category: expenses.category,
      total: sql<string>`coalesce(sum(${expenses.amount}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(expenses)
    .where(and(...expenseConditions))
    .groupBy(expenses.category)
    .orderBy(desc(sql`sum(${expenses.amount})`));

  const productReport = await db
    .select({
      productId: saleItems.productId,
      name: saleItems.productName,
      sku: saleItems.sku,
      qty: sql<string>`sum(${saleItems.quantity})`,
      revenue: sql<string>`sum(${saleItems.total})`,
      cost: sql<string>`sum(${saleItems.quantity} * ${saleItems.costPrice})`,
    })
    .from(saleItems)
    .innerJoin(sales, eq(saleItems.saleId, sales.id))
    .where(and(...salesConditions))
    .groupBy(saleItems.productId, saleItems.productName, saleItems.sku)
    .orderBy(desc(sql`sum(${saleItems.total})`));

  const inventoryReport = await db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      unit: products.unit,
      currentStock: products.currentStock,
      minStock: products.minStock,
      purchasePrice: products.purchasePrice,
      sellingPrice: products.sellingPrice,
      stockValue: sql<string>`${products.currentStock} * ${products.purchasePrice}`,
      retailValue: sql<string>`${products.currentStock} * ${products.sellingPrice}`,
    })
    .from(products)
    .where(eq(products.isActive, true))
    .orderBy(asc(products.currentStock));

  const [inventoryAgg] = await db
    .select({
      stockValue: sql<string>`coalesce(sum(${products.currentStock} * ${products.purchasePrice}), 0)`,
      retailValue: sql<string>`coalesce(sum(${products.currentStock} * ${products.sellingPrice}), 0)`,
      units: sql<string>`coalesce(sum(${products.currentStock}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(products);

  const customerDues = await db
    .select({
      id: customers.id,
      name: customers.name,
      mobile: customers.mobile,
      due: sql<string>`${customers.openingBalance} + ${customerSalesTotal} - ${customerInitialPaid} - ${customerLaterPaid}`,
    })
    .from(customers)
    .orderBy(desc(sql`${customers.openingBalance} + ${customerSalesTotal} - ${customerInitialPaid} - ${customerLaterPaid}`));

  const supplierDues = await db
    .select({
      id: suppliers.id,
      name: suppliers.name,
      mobile: suppliers.mobile,
      due: sql<string>`${suppliers.openingBalance} + ${supplierPurchaseTotal} - ${supplierInitialPaid} - ${supplierLaterPaid}`,
    })
    .from(suppliers)
    .orderBy(desc(sql`${suppliers.openingBalance} + ${supplierPurchaseTotal} - ${supplierInitialPaid} - ${supplierLaterPaid}`));

  const customerPaymentAgg = await db
    .select({ total: sql<string>`coalesce(sum(${customerPayments.amount}), 0)` })
    .from(customerPayments)
    .where(and(...dateRange(customerPayments.paymentDate, from, to)));
  const supplierPaymentAgg = await db
    .select({ total: sql<string>`coalesce(sum(${supplierPayments.amount}), 0)` })
    .from(supplierPayments)
    .where(and(...dateRange(supplierPayments.paymentDate, from, to)));

  const salesTotal = Number(salesAgg?.total ?? 0);
  const cogs = Number(cogsAgg?.cogs ?? 0);
  const expenseTotal = Number(expenseAgg?.total ?? 0);

  return {
    range: { from, to },
    sales: {
      total: salesTotal,
      subtotal: Number(salesAgg?.subtotal ?? 0),
      discount: Number(salesAgg?.discount ?? 0),
      paid: Number(salesAgg?.paid ?? 0),
      due: Number(salesAgg?.due ?? 0),
      count: salesAgg?.count ?? 0,
    },
    purchases: {
      total: Number(purchaseAgg?.total ?? 0),
      paid: Number(purchaseAgg?.paid ?? 0),
      due: Number(purchaseAgg?.due ?? 0),
      count: purchaseAgg?.count ?? 0,
    },
    expenses: {
      total: expenseTotal,
      count: expenseAgg?.count ?? 0,
      byCategory: expensesByCategory,
    },
    profit: {
      cogs,
      gross: salesTotal - cogs,
      net: salesTotal - cogs - expenseTotal,
    },
    paymentsIn: Number(customerPaymentAgg[0]?.total ?? 0),
    paymentsOut: Number(supplierPaymentAgg[0]?.total ?? 0),
    dailySales,
    productReport,
    inventoryReport,
    inventoryAgg: {
      stockValue: Number(inventoryAgg?.stockValue ?? 0),
      retailValue: Number(inventoryAgg?.retailValue ?? 0),
      units: Number(inventoryAgg?.units ?? 0),
      count: inventoryAgg?.count ?? 0,
    },
    customerDues,
    supplierDues,
  };
}

/* ------------------------------- option lists ------------------------------ */
export async function getPosProducts() {
  return db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      barcode: products.barcode,
      unit: products.unit,
      sellingPrice: products.sellingPrice,
      purchasePrice: products.purchasePrice,
      currentStock: products.currentStock,
    })
    .from(products)
    .where(eq(products.isActive, true))
    .orderBy(asc(products.name));
}

export async function getCustomerOptions() {
  return db
    .select({
      id: customers.id,
      name: customers.name,
      mobile: customers.mobile,
      due: sql<string>`${customers.openingBalance} + ${customerSalesTotal} - ${customerInitialPaid} - ${customerLaterPaid}`,
    })
    .from(customers)
    .orderBy(asc(customers.name));
}

export async function getSupplierOptions() {
  return db
    .select({
      id: suppliers.id,
      name: suppliers.name,
      mobile: suppliers.mobile,
      due: sql<string>`${suppliers.openingBalance} + ${supplierPurchaseTotal} - ${supplierInitialPaid} - ${supplierLaterPaid}`,
    })
    .from(suppliers)
    .orderBy(asc(suppliers.name));
}

/* --------------------------- single balance lookups ------------------------- */
export async function getCustomerDue(id: number): Promise<{ name: string; due: number } | null> {
  const [row] = await db
    .select({
      name: customers.name,
      due: sql<string>`${customers.openingBalance} + ${customerSalesTotal} - ${customerInitialPaid} - ${customerLaterPaid}`,
    })
    .from(customers)
    .where(eq(customers.id, id))
    .limit(1);
  return row ? { name: row.name, due: Number(row.due) } : null;
}

export async function getSupplierDue(id: number): Promise<{ name: string; due: number } | null> {
  const [row] = await db
    .select({
      name: suppliers.name,
      due: sql<string>`${suppliers.openingBalance} + ${supplierPurchaseTotal} - ${supplierInitialPaid} - ${supplierLaterPaid}`,
    })
    .from(suppliers)
    .where(eq(suppliers.id, id))
    .limit(1);
  return row ? { name: row.name, due: Number(row.due) } : null;
}
