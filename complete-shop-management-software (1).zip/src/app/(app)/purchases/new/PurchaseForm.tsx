"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Alert } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { Card, PageHeader } from "@/components/ui";
import { api, jsonBody } from "@/lib/client";
import { formatMoney, formatQty } from "@/lib/format";

type Product = {
  id: number;
  name: string;
  sku: string;
  unit: string;
  sellingPrice: string;
  purchasePrice: string;
  currentStock: string;
};
type Supplier = { id: number; name: string; mobile: string | null; due: string };
type Line = { productId: number; name: string; unit: string; cost: number; quantity: number };

const METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer", "Credit"];

export function PurchaseForm({
  products,
  suppliers,
  defaultDate,
}: {
  products: Product[];
  suppliers: Supplier[];
  defaultDate: string;
}) {
  const router = useRouter();
  const [supplierId, setSupplierId] = useState("");
  const [purchaseDate, setPurchaseDate] = useState(defaultDate);
  const [productId, setProductId] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [discount, setDiscount] = useState("");
  const [paidAmount, setPaidAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const subtotal = useMemo(
    () => Math.round(lines.reduce((sum, line) => sum + line.quantity * line.cost, 0) * 100) / 100,
    [lines],
  );
  const discountValue = Math.min(Math.max(Number(discount) || 0, 0), subtotal);
  const total = Math.round((subtotal - discountValue) * 100) / 100;
  const paid = Math.min(Math.max(Number(paidAmount) || 0, 0), total);
  const due = Math.round((total - paid) * 100) / 100;

  function addProduct() {
    const product = products.find((p) => String(p.id) === productId);
    if (!product) return;
    setLines((prev) => {
      const existing = prev.find((line) => line.productId === product.id);
      if (existing) {
        return prev.map((line) =>
          line.productId === product.id ? { ...line, quantity: line.quantity + 1 } : line,
        );
      }
      return [...prev, { productId: product.id, name: product.name, unit: product.unit, cost: Number(product.purchasePrice), quantity: 1 }];
    });
    setProductId("");
  }

  async function save() {
    if (lines.length === 0) {
      setNotice({ tone: "error", text: "Add at least one product." });
      return;
    }
    setBusy(true);
    setNotice(null);
    try {
      const result = await api<{ id: number; purchaseNo: string; message: string }>("/api/purchases", jsonBody({
        supplierId: supplierId ? Number(supplierId) : null,
        purchaseDate,
        items: lines.map((line) => ({ productId: line.productId, quantity: line.quantity, unitPrice: line.cost })),
        discount: discountValue,
        paidAmount: paid,
        paymentMethod,
        note: note || null,
      }));
      router.push(`/purchases/${result.id}`);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Purchase could not be saved." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="New Purchase"
        subtitle="Record goods received from a supplier. Stock increases when saved."
        actions={
          <Link href="/purchases" className="btn btn-secondary">
            <Icon name="back" className="h-4 w-4" /> All purchases
          </Link>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      {suppliers.length === 0 ? (
        <div className="mb-4">
          <Alert tone="warning">
            No suppliers yet. You can still record a cash purchase, or{" "}
            <Link href="/suppliers" className="font-semibold underline">add a supplier first</Link>.
          </Alert>
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="space-y-4 xl:col-span-8">
          <Card>
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="purchase-supplier">Supplier</label>
                <select id="purchase-supplier" className="select" value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
                  <option value="">Cash purchase / no supplier</option>
                  {suppliers.map((supplier) => (
                    <option key={supplier.id} value={supplier.id}>
                      {supplier.name}{supplier.mobile ? ` · ${supplier.mobile}` : ""} (due ৳{Number(supplier.due).toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="purchase-date">Purchase date</label>
                <input id="purchase-date" type="date" className="input" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} />
              </div>
            </div>
          </Card>

          <Card>
            <div className="border-b border-slate-100 p-4">
              <label className="label" htmlFor="purchase-product">Add product to purchase</label>
              <div className="flex gap-2">
                <select id="purchase-product" className="select" value={productId} onChange={(e) => setProductId(e.target.value)}>
                  <option value="">Select product</option>
                  {products.map((product) => (
                    <option key={product.id} value={product.id}>
                      {product.name} · stock {formatQty(product.currentStock)} {product.unit}
                    </option>
                  ))}
                </select>
                <button type="button" className="btn btn-secondary shrink-0" onClick={addProduct} disabled={!productId}>
                  <Icon name="plus" className="h-4 w-4" /> Add
                </button>
              </div>
              <p className="muted mt-1">
                Need a new item? <Link href="/products" className="text-emerald-700 underline">Create the product first</Link>.
              </p>
            </div>

            {lines.length === 0 ? (
              <div className="empty-state">
                <p className="text-sm font-semibold text-slate-600">No items added</p>
                <p className="text-xs">Select a product and press Add.</p>
              </div>
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Product</th>
                      <th className="w-24">Qty</th>
                      <th className="w-32">Cost (৳)</th>
                      <th className="text-right">Line total</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {lines.map((line) => (
                      <tr key={line.productId}>
                        <td className="font-medium">{line.name}<span className="ml-1 text-[11px] text-slate-400 lowercase">{line.unit}</span></td>
                        <td>
                          <input
                            type="number"
                            min="0.001"
                            step="0.001"
                            className="input py-1"
                            value={line.quantity}
                            onChange={(e) => {
                              const value = Number(e.target.value);
                              setLines((prev) => prev.map((l) => l.productId === line.productId ? { ...l, quantity: Number.isFinite(value) && value > 0 ? value : 0.001 } : l));
                            }}
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            className="input py-1"
                            value={line.cost}
                            onChange={(e) => {
                              const value = Number(e.target.value);
                              setLines((prev) => prev.map((l) => l.productId === line.productId ? { ...l, cost: Number.isFinite(value) && value >= 0 ? value : 0 } : l));
                            }}
                          />
                        </td>
                        <td className="text-right font-semibold">{formatMoney(line.quantity * line.cost)}</td>
                        <td className="text-right">
                          <button type="button" className="btn btn-ghost btn-sm text-rose-600" onClick={() => setLines((prev) => prev.filter((l) => l.productId !== line.productId))}>
                            <Icon name="close" className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        <div className="xl:col-span-4">
          <Card className="xl:sticky xl:top-20">
            <div className="space-y-3 p-4">
              <h2 className="section-title">Purchase totals</h2>
              <div>
                <label className="label" htmlFor="purchase-discount">Discount (৳)</label>
                <input id="purchase-discount" type="number" min="0" max={subtotal} step="0.01" className="input" value={discount} onChange={(e) => setDiscount(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="purchase-paid">Paid amount (৳)</label>
                <input id="purchase-paid" type="number" min="0" max={total} step="0.01" className="input" value={paidAmount} onChange={(e) => setPaidAmount(e.target.value)} />
                <div className="mt-1 flex gap-2">
                  <button type="button" className="text-[11px] font-semibold text-emerald-700 underline" onClick={() => setPaidAmount(String(total))}>Full</button>
                  <button type="button" className="text-[11px] font-semibold text-emerald-700 underline" onClick={() => setPaidAmount("0")}>None</button>
                </div>
              </div>
              <div>
                <label className="label" htmlFor="purchase-method">Payment method</label>
                <select id="purchase-method" className="select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  {METHODS.map((method) => <option key={method} value={method}>{method}</option>)}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="purchase-note">Note</label>
                <input id="purchase-note" className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional" />
              </div>

              <div className="rounded-xl bg-slate-50 p-3 text-sm">
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Subtotal</span><span className="font-semibold">{formatMoney(subtotal)}</span></div>
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Discount</span><span className="font-semibold text-rose-600">− {formatMoney(discountValue)}</span></div>
                <div className="mt-1 flex justify-between border-t border-slate-200 pt-2 text-base"><span className="font-semibold">Total</span><span className="font-bold">{formatMoney(total)}</span></div>
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Paid</span><span>{formatMoney(paid)}</span></div>
                <div className="flex justify-between py-0.5"><span className="text-slate-600">Due</span><span className={due > 0 ? "font-semibold text-rose-600" : "font-semibold text-emerald-700"}>{formatMoney(due)}</span></div>
              </div>

              <button type="button" className="btn btn-primary w-full py-2.5" onClick={save} disabled={busy || lines.length === 0}>
                {busy ? "Saving purchase…" : "Save purchase"}
              </button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
