import { ApiError, fail, ok, readJson } from "@/lib/api-helpers";
import { requireApiUser } from "@/lib/auth";
import { restoreBackup, validateBackup } from "@/lib/backup";

export const dynamic = "force-dynamic";

/**
 * Restores a previously downloaded backup. The request must explicitly include
 * confirm: true — the UI collects a typed confirmation before calling this.
 */
export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson<{ confirm?: unknown; backup?: unknown }>(request);
    if (body.confirm !== true) {
      throw new ApiError("Restore requires explicit confirmation.", 400);
    }
    if (!body.backup) throw new ApiError("No backup file content received.");

    const payload = validateBackup(body.backup);
    const restored = await restoreBackup(payload);

    return ok({
      message:
        "Backup restored successfully. All business records were replaced with the backup contents.",
      restored,
      meta: payload.meta,
    });
  } catch (error) {
    return fail(error);
  }
}
