"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { Icon, type IconName } from "./icons";
import { todayLongLabel } from "@/lib/format";

const NAV: { href: string; label: string; icon: IconName; exact?: boolean }[] = [
  { href: "/", label: "Dashboard", icon: "dashboard", exact: true },
  { href: "/pos", label: "New Sale (POS)", icon: "pos" },
  { href: "/sales", label: "Sales", icon: "sales" },
  { href: "/purchases", label: "Purchases", icon: "purchases" },
  { href: "/products", label: "Products", icon: "products" },
  { href: "/inventory", label: "Inventory", icon: "inventory" },
  { href: "/customers", label: "Customers", icon: "customers" },
  { href: "/suppliers", label: "Suppliers", icon: "suppliers" },
  { href: "/expenses", label: "Expenses", icon: "expenses" },
  { href: "/reports", label: "Reports", icon: "reports" },
  { href: "/settings", label: "Settings", icon: "settings" },
];

export type ShopIdentity = {
  shopName: string;
  logo: string | null;
  address: string;
  mobile: string;
  email: string;
};

function isActive(pathname: string, href: string, exact?: boolean) {
  if (exact) return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}

function Brand({ shop, compact = false }: { shop: ShopIdentity; compact?: boolean }) {
  return (
    <div className="flex min-w-0 items-center gap-2.5">
      {shop.logo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={shop.logo}
          alt={`${shop.shopName} logo`}
          className="h-9 w-9 shrink-0 rounded-lg bg-white object-contain p-0.5"
        />
      ) : (
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-emerald-400/20 text-sm font-bold text-emerald-100 ring-1 ring-emerald-300/30">
          {shop.shopName.trim().slice(0, 2).toUpperCase() || "SR"}
        </span>
      )}
      <div className="min-w-0">
        <p className="truncate text-sm font-bold leading-tight text-white">{shop.shopName}</p>
        {!compact ? <p className="truncate text-[11px] text-emerald-200/80">Retail Management</p> : null}
      </div>
    </div>
  );
}

function LogoutButton({ compact = false }: { compact?: boolean }) {
  const [busy, setBusy] = useState(false);
  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
    } finally {
      window.location.href = "/login";
    }
  }
  return (
    <button
      type="button"
      onClick={logout}
      disabled={busy}
      className={
        compact
          ? "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs font-semibold text-emerald-100/80 transition hover:bg-white/10 hover:text-white"
          : "btn btn-secondary btn-sm"
      }
      title="Sign out of this device"
    >
      <Icon name="logout" className="h-4 w-4" />
      {busy ? "Signing out…" : "Sign out"}
    </button>
  );
}

export function AppFrame({
  shop,
  username,
  children,
}: {
  shop: ShopIdentity;
  username: string;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const nav = (
    <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-4">
      {NAV.map((item) => {
        const active = isActive(pathname, item.href, item.exact);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`nav-link ${active ? "nav-link-active" : ""}`}
            aria-current={active ? "page" : undefined}
          >
            <Icon name={item.icon} className="h-[18px] w-[18px] shrink-0" />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen lg:flex">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col bg-gradient-to-b from-[#07332c] via-[#07433a] to-[#052b26] lg:flex print:hidden">
        <div className="flex h-16 items-center border-b border-white/10 px-4">
          <Link href="/" className="min-w-0">
            <Brand shop={shop} />
          </Link>
        </div>
        {nav}
        <div className="border-t border-white/10 px-4 py-3">
          <div className="mb-2 flex items-center gap-2">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-emerald-400/20 text-emerald-100 ring-1 ring-emerald-300/30">
              <Icon name="user" className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-xs font-semibold text-white">{username}</p>
              <p className="text-[10px] text-emerald-200/70">Administrator</p>
            </div>
          </div>
          <LogoutButton compact />
          <p className="mt-2 text-[10px] leading-relaxed text-emerald-200/60">
            Bangladesh · BDT ৳ · Asia/Dhaka
          </p>
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative flex h-full w-72 max-w-[85%] flex-col bg-gradient-to-b from-[#07332c] via-[#07433a] to-[#052b26] shadow-2xl">
            <div className="flex h-16 items-center justify-between border-b border-white/10 px-4">
              <Brand shop={shop} compact />
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="rounded-lg p-1.5 text-emerald-100 hover:bg-white/10"
                aria-label="Close menu"
              >
                <Icon name="close" className="h-5 w-5" />
              </button>
            </div>
            {nav}
            <div className="border-t border-white/10 px-4 py-3">
              <p className="mb-1 truncate text-xs font-semibold text-white">{username} · Administrator</p>
              <LogoutButton compact />
            </div>
          </aside>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="app-header sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-slate-200 bg-white/95 px-3 backdrop-blur sm:px-5 print:hidden">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 lg:hidden"
            aria-label="Open menu"
          >
            <Icon name="menu" className="h-5 w-5" />
          </button>

          <div className="lg:hidden">
            <Brand shop={shop} compact />
          </div>

          <div className="hidden min-w-0 lg:block">
            <p className="truncate text-sm font-semibold text-slate-900">{shop.shopName}</p>
            <p className="truncate text-[11px] text-slate-500">
              {shop.address || "Add your shop address in Settings"}
            </p>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <span className="hidden rounded-full bg-slate-100 px-3 py-1 text-[11px] font-medium text-slate-600 md:inline">
              {todayLongLabel()}
            </span>
            {shop.mobile ? (
              <span className="hidden rounded-full bg-emerald-50 px-3 py-1 text-[11px] font-semibold text-emerald-700 sm:inline">
                {shop.mobile}
              </span>
            ) : null}
            <Link href="/pos" className="btn btn-primary btn-sm sm:px-3.5 sm:py-2 sm:text-sm">
              <Icon name="plus" className="h-4 w-4" />
              <span className="hidden sm:inline">New Sale</span>
              <span className="sm:hidden">Sale</span>
            </Link>
            <span className="hidden lg:inline-flex">
              <LogoutButton />
            </span>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-3 py-4 sm:px-5 sm:py-6 print:p-0">{children}</main>

        <footer className="border-t border-slate-200 px-4 py-3 text-center text-[11px] text-slate-400 print:hidden">
          {shop.shopName} · BDT (৳) · All amounts in Bangladeshi Taka
        </footer>
      </div>
    </div>
  );
}
