export const CURRENCY_CODE = "BDT";
export const CURRENCY_SYMBOL = "৳";
export const TIME_ZONE = "Asia/Dhaka";
export const DATE_FORMAT = "DD-MM-YYYY";

/** Convert a drizzle numeric (string) or any raw value into a number. */
export function num(value: string | number | null | undefined): number {
  if (value === null || value === undefined || value === "") return 0;
  const parsed = typeof value === "number" ? value : Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function round3(value: number): number {
  return Math.round((value + Number.EPSILON) * 1000) / 1000;
}

/** Money value stored to numeric(14,2) columns. */
export function money(value: number): string {
  return (round2(Number.isFinite(value) ? value : 0)).toFixed(2);
}

/** Quantity value stored to numeric(14,3) columns. */
export function qty(value: number): string {
  return (round3(Number.isFinite(value) ? value : 0)).toFixed(3);
}

const numberFormatter = new Intl.NumberFormat("en-BD", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const quantityFormatter = new Intl.NumberFormat("en-BD", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 3,
});

/** ৳ 1,250.00 */
export function formatMoney(value: string | number | null | undefined): string {
  return `${CURRENCY_SYMBOL} ${numberFormatter.format(round2(num(value)))}`;
}

/** Amount without symbol, e.g. for print columns. */
export function formatAmount(value: string | number | null | undefined): string {
  return numberFormatter.format(round2(num(value)));
}

export function formatQty(value: string | number | null | undefined): string {
  return quantityFormatter.format(round3(num(value)));
}

function toDate(value: Date | string | null | undefined): Date | null {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  timeZone: TIME_ZONE,
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

const timeFormatter = new Intl.DateTimeFormat("en-GB", {
  timeZone: TIME_ZONE,
  hour: "2-digit",
  minute: "2-digit",
  hour12: true,
});

/** DD-MM-YYYY in Asia/Dhaka */
export function formatDate(value: Date | string | null | undefined): string {
  const date = toDate(value);
  return date ? dateFormatter.format(date) : "—";
}

/** DD-MM-YYYY, hh:mm AM/PM in Asia/Dhaka */
export function formatDateTime(value: Date | string | null | undefined): string {
  const date = toDate(value);
  if (!date) return "—";
  return `${dateFormatter.format(date)}, ${timeFormatter.format(date)}`;
}

export function formatTime(value: Date | string | null | undefined): string {
  const date = toDate(value);
  return date ? timeFormatter.format(date) : "—";
}

/** Today's business date in Dhaka as YYYY-MM-DD (for <input type="date">). */
export function todayDhaka(): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  return parts; // en-CA yields YYYY-MM-DD
}

export function shiftDhakaDays(days: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + days);
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

/** Build a Dhaka-midday Date from an HTML date input value (YYYY-MM-DD). */
export function inputDateToDate(value: string | null | undefined): Date {
  if (!value) return new Date();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return new Date();
  return new Date(`${value}T12:00:00+06:00`);
}

/** Current month start in Dhaka as YYYY-MM-DD. */
export function monthStartDhaka(): string {
  const today = todayDhaka();
  return `${today.slice(0, 7)}-01`;
}

export function todayLongLabel(): string {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: TIME_ZONE,
    weekday: "long",
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date());
}

export function slugToTitle(value: string): string {
  return value
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}
