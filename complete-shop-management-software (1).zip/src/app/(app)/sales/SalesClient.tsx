"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { Alert, ConfirmDialog } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, deleteRequest } from "@/lib/client";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";

type SaleRow = {
  id: number;
  invoiceNo: string;
  saleDate: Date | string;
  customerId: number | null;
  customerName: string | null;
  customerMobile: string | null;
  subtotal: string;
  discount: string;
  total: string;
  paid: string;
  due: string;
  paymentMethod: string;
  itemCount: number;
};

export function SalesClient({
  sales,
  initialFrom,
  initialTo,
  initialSearch,
  initialDueOnly,
}: {
  sales: SaleRow[];
  initialFrom: string;
  initialTo: string;
  initialSearch: string;
  initialDueOnly: boolean;
}) {
  const router = useRouter();
  const [search, setSearch] = useState(initialSearch);
  const [from, setFrom] = useState(initialFrom);
  const [to, setTo] = useState(initialTo);
  const [method, setMethod] = useState("all");
  const [dueOnly, setDueOnly] = useState(initialDueOnly);
  const [deleteTarget, setDeleteTarget] = useState<SaleRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return sales.filter((sale) => {
      if (method !== "all" && sale.paymentMethod !== method) return false;
      if (dueOnly && Number(sale.due) <= 0) return false;
      if (term) {
        const haystack = `${sale.invoiceNo} ${sale.customerName ?? "walk-in"} ${sale.customerMobile ?? ""}`.toLowerCase();
        if (!haystack.includes(term)) return false;
      }
      if (from || to) {
        const day = new Intl.DateTimeFormat("en-CA", {
          timeZone: "Asia/Dhaka",
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        }).format(new Date(sale.saleDate));
        if (from && day < from) return false;
        if (to && day > to) return false;
      }
      return true;
    });
  }, [sales, search, from, to, method, dueOnly]);

  const totals = filtered.reduce(
    (acc, sale) => ({
      total: acc.total + Number(sale.total),
      paid: acc.paid + Number(sale.paid),
      due: acc.due + Number(sale.due),
      discount: acc.discount + Number(sale.discount),
    }),
    { total: 0, paid: 0, due: 0, discount: 0 },
  );

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const result = await api<{ message: string }>(`/api/sales/${deleteTarget.id}`, deleteRequest());
      setNotice({ tone: "success", text: result.message });
      setDeleteTarget(null);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Sale could not be deleted." });
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  }

  function clearFilters() {
    setSearch("");
    setFrom("");
    setTo("");
    setMethod("all");
    setDueOnly(false);
  }

  return (
    <div>
      <PageHeader
        title="Sales History"
        subtitle="Search, filter and reprint invoices or receipts"
        actions={
          <Link href="/pos" className="btn btn-primary">
            <Icon name="plus" className="h-4 w-4" /> New Sale
          </Link>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Filtered sales" value={formatMoney(totals.total)} hint={`${filtered.length} invoice(s)`} tone="green" />
        <StatCard label="Paid" value={formatMoney(totals.paid)} tone="blue" />
        <StatCard label="Due" value={formatMoney(totals.due)} tone="amber" />
        <StatCard label="Discount given" value={formatMoney(totals.discount)} tone="violet" />
      </div>

      <Card className="mt-4">
        <div className="grid gap-2 border-b border-slate-100 p-4 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              className="input pl-9"
              placeholder="Search invoice / customer / mobile"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div>
            <input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" />
          </div>
          <div>
            <input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" />
          </div>
          <select className="select" value={method} onChange={(e) => setMethod(e.target.value)} aria-label="Payment method">
            <option value="all">All methods</option>
            {["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer", "Credit"].map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <input type="checkbox" checked={dueOnly} onChange={(e) => setDueOnly(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
              Due only
            </label>
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>Clear</button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title={sales.length === 0 ? "No sales recorded yet" : "No sales match your filters"}
            description={sales.length === 0 ? "Create your first sale from the POS screen." : "Adjust the date range or search term."}
            action={<Link href="/pos" className="btn btn-primary btn-sm">Open POS</Link>}
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Invoice</th>
                  <th>Date</th>
                  <th>Customer</th>
                  <th className="text-right">Items</th>
                  <th className="text-right">Total</th>
                  <th className="text-right">Paid</th>
                  <th className="text-right">Due</th>
                  <th>Method</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((sale) => (
                  <tr key={sale.id}>
                    <td>
                      <Link href={`/sales/${sale.id}`} className="font-semibold text-emerald-800 hover:underline">
                        {sale.invoiceNo}
                      </Link>
                    </td>
                    <td className="whitespace-nowrap text-xs">{formatDate(sale.saleDate)}<br /><span className="text-[10px] text-slate-400">{formatDateTime(sale.saleDate).split(", ")[1]}</span></td>
                    <td>
                      <p className="truncate">{sale.customerName ?? "Walk-in"}</p>
                      {sale.customerMobile ? <p className="text-[11px] text-slate-500">{sale.customerMobile}</p> : null}
                    </td>
                    <td className="text-right">{sale.itemCount}</td>
                    <td className="text-right font-semibold">{formatMoney(sale.total)}</td>
                    <td className="text-right">{formatMoney(sale.paid)}</td>
                    <td className="text-right">
                      {Number(sale.due) > 0 ? <Badge tone="amber">{formatMoney(sale.due)}</Badge> : <Badge tone="green">Paid</Badge>}
                    </td>
                    <td className="text-xs">{sale.paymentMethod}</td>
                    <td>
                      <div className="flex items-center justify-end gap-0.5">
                        <Link href={`/sales/${sale.id}`} className="btn btn-ghost btn-sm" title="View invoice">
                          <Icon name="eye" className="h-4 w-4" />
                        </Link>
                        <Link href={`/print/sale/${sale.id}`} target="_blank" className="btn btn-ghost btn-sm" title="Print invoice">
                          <Icon name="print" className="h-4 w-4" />
                        </Link>
                        <Link href={`/print/receipt/${sale.id}`} target="_blank" className="btn btn-ghost btn-sm" title="Print receipt">
                          <span className="text-[10px] font-bold">80mm</span>
                        </Link>
                        <button
                          type="button"
                          className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                          onClick={() => setDeleteTarget(sale)}
                          title="Delete sale"
                        >
                          <Icon name="trash" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete this sale?"
        message={
          <>
            <p>
              Invoice <strong>{deleteTarget?.invoiceNo}</strong> for <strong>{formatMoney(deleteTarget?.total ?? 0)}</strong> will
              be removed permanently.
            </p>
            <p className="mt-2 text-xs text-slate-500">
              All products in this invoice will be returned to stock and the customer due will be recalculated. This
              cannot be undone.
            </p>
          </>
        }
        confirmLabel="Delete sale"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
