import { notFound } from "next/navigation";
import { Invoice } from "@/components/Invoice";
import { PrintToolbar } from "@/components/PrintToolbar";
import { getSale } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Print invoice" };

export default async function PrintInvoicePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const saleId = Number(id);
  if (!Number.isInteger(saleId)) notFound();
  const [data, shop] = await Promise.all([getSale(saleId), getSettings()]);
  if (!data) notFound();

  return (
    <div>
      <PrintToolbar title={`Invoice ${data.sale.invoiceNo} — A4`} />
      <Invoice
        shop={shop}
        sale={data.sale}
        items={data.items}
        customer={
          data.customerName
            ? { name: data.customerName, mobile: data.customerMobile, address: data.customerAddress }
            : null
        }
      />
    </div>
  );
}
