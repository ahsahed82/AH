import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import {
  checkLoginThrottle,
  clearLoginFailures,
  createSession,
  recordLoginFailure,
  verifyPassword,
} from "@/lib/auth";
import { fail, ok, readJson } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "local";
  try {
    checkLoginThrottle(ip);
    const body = await readJson<Record<string, unknown>>(request);
    const username = typeof body.username === "string" ? body.username.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!username || !password) throw new Error("Enter your username and password.");

    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      recordLoginFailure(ip);
      return Response.json({ error: "Incorrect username or password." }, { status: 401 });
    }

    clearLoginFailures(ip);
    await createSession(user.id);
    return ok({
      user: { id: user.id, username: user.username, name: user.name },
      message: `Welcome back, ${user.name}!`,
    });
  } catch (error) {
    return fail(error);
  }
}
