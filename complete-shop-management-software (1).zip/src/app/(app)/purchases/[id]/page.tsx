import Link from "next/link";
import { notFound } from "next/navigation";
import { Icon } from "@/components/icons";
import { PurchaseDocument } from "@/components/PurchaseDocument";
import { Badge, Card, CardHeader, PageHeader } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { getPurchase } from "@/lib/queries";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Purchase details" };

export default async function PurchaseDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const purchaseId = Number(id);
  if (!Number.isInteger(purchaseId)) notFound();
  const [data, shop] = await Promise.all([getPurchase(purchaseId), getSettings()]);
  if (!data) notFound();

  return (
    <div>
      <PageHeader
        title={`Purchase ${data.purchase.purchaseNo}`}
        subtitle={`${formatDateTime(data.purchase.purchaseDate)} · ${data.supplierName ?? "Cash purchase"}`}
        actions={
          <>
            <Link href="/purchases" className="btn btn-secondary"><Icon name="back" className="h-4 w-4" /> All purchases</Link>
            <Link href={`/print/purchase/${data.purchase.id}`} target="_blank" className="btn btn-primary">
              <Icon name="print" className="h-4 w-4" /> Print purchase
            </Link>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="xl:col-span-8">
          <div className="card overflow-hidden">
            <PurchaseDocument
              shop={shop}
              purchase={data.purchase}
              items={data.items}
              supplier={data.supplierName ? { name: data.supplierName, mobile: data.supplierMobile, address: data.supplierAddress } : null}
            />
          </div>
        </div>
        <div className="space-y-4 xl:col-span-4">
          <Card>
            <CardHeader title="Summary" />
            <div className="space-y-2 p-4 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Purchase no</span><span className="font-semibold">{data.purchase.purchaseNo}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Date</span><span>{formatDate(data.purchase.purchaseDate)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Total</span><span className="font-semibold">{formatMoney(data.purchase.total)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Paid</span><span>{formatMoney(data.purchase.paid)}</span></div>
              <div className="flex justify-between border-t border-slate-100 pt-2">
                <span className="text-slate-500">Due</span>
                {Number(data.purchase.due) > 0 ? <Badge tone="amber">{formatMoney(data.purchase.due)}</Badge> : <Badge tone="green">Paid</Badge>}
              </div>
              {data.supplierName ? (
                <div className="border-t border-slate-100 pt-2">
                  <p className="text-slate-500">Supplier</p>
                  <Link href={`/suppliers/${data.purchase.supplierId}`} className="font-semibold text-emerald-800 hover:underline">{data.supplierName}</Link>
                  {data.supplierMobile ? <p className="text-xs text-slate-500">{data.supplierMobile}</p> : null}
                </div>
              ) : null}
            </div>
          </Card>
          <Card>
            <CardHeader title="Supplier payments" subtitle="Recorded against this purchase" />
            {data.payments.length === 0 ? (
              <p className="px-4 py-4 text-sm text-slate-500">No later payments recorded for this purchase.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {data.payments.map((payment) => (
                  <li key={payment.id} className="flex items-center justify-between px-4 py-2 text-sm">
                    <div>
                      <p className="font-medium">{formatMoney(payment.amount)}</p>
                      <p className="text-[11px] text-slate-500">{formatDateTime(payment.paymentDate)} · {payment.paymentMethod}</p>
                    </div>
                    <Badge tone="green">Paid</Badge>
                  </li>
                ))}
              </ul>
            )}
            {data.supplierName ? (
              <div className="border-t border-slate-100 p-4">
                <Link href={`/suppliers/${data.purchase.supplierId}`} className="btn btn-secondary btn-sm w-full">
                  <Icon name="cash" className="h-4 w-4" /> Record supplier payment
                </Link>
              </div>
            ) : null}
          </Card>
        </div>
      </div>
    </div>
  );
}
