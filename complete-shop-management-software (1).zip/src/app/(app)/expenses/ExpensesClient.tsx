"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, ConfirmDialog, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { api, deleteRequest, jsonBody, putBody } from "@/lib/client";
import { formatDate, formatMoney, todayDhaka } from "@/lib/format";

type Expense = {
  id: number;
  category: string;
  expenseDate: Date | string;
  amount: string;
  description: string | null;
  paymentMethod: string;
};

const METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer"];

export function ExpensesClient({ expenses }: { expenses: Expense[] }) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    category: "",
    amount: "",
    expenseDate: todayDhaka(),
    description: "",
    paymentMethod: "Cash",
  });
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Expense | null>(null);

  const categories = useMemo(
    () => [...new Set(expenses.map((expense) => expense.category))].sort(),
    [expenses],
  );

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return expenses.filter((expense) => {
      if (categoryFilter !== "all" && expense.category !== categoryFilter) return false;
      if (term && !`${expense.category} ${expense.description ?? ""} ${expense.paymentMethod}`.toLowerCase().includes(term)) return false;
      if (from || to) {
        const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(expense.expenseDate));
        if (from && day < from) return false;
        if (to && day > to) return false;
      }
      return true;
    });
  }, [expenses, search, from, to, categoryFilter]);

  const total = filtered.reduce((sum, expense) => sum + Number(expense.amount), 0);
  const thisMonth = filtered.filter((expense) => {
    const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(expense.expenseDate));
    return day.slice(0, 7) === todayDhaka().slice(0, 7);
  }).reduce((sum, expense) => sum + Number(expense.amount), 0);

  function openAdd() {
    setEditingId(null);
    setForm({ category: "", amount: "", expenseDate: todayDhaka(), description: "", paymentMethod: "Cash" });
    setOpen(true);
    setNotice(null);
  }

  function openEdit(expense: Expense) {
    setEditingId(expense.id);
    setForm({
      category: expense.category,
      amount: expense.amount,
      expenseDate: new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(expense.expenseDate)),
      description: expense.description ?? "",
      paymentMethod: expense.paymentMethod,
    });
    setOpen(true);
    setNotice(null);
  }

  async function save() {
    setBusy(true);
    setNotice(null);
    try {
      const payload = { ...form, description: form.description || null };
      const result = await api<{ message: string }>(
        editingId ? `/api/expenses/${editingId}` : "/api/expenses",
        editingId ? putBody(payload) : jsonBody(payload),
      );
      setNotice({ tone: "success", text: result.message });
      setOpen(false);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not save expense." });
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      const result = await api<{ message: string }>(`/api/expenses/${deleteTarget.id}`, deleteRequest());
      setNotice({ tone: "success", text: result.message });
      setDeleteTarget(null);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not delete expense." });
      setDeleteTarget(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Expenses"
        subtitle="Every expense is subtracted from profit exactly once"
        actions={
          <button type="button" className="btn btn-primary" onClick={openAdd}>
            <Icon name="plus" className="h-4 w-4" /> Add Expense
          </button>
        }
      />

      {notice ? <div className="mb-4"><Alert tone={notice.tone}>{notice.text}</Alert></div> : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Filtered expenses" value={formatMoney(total)} hint={`${filtered.length} record(s)`} tone="amber" />
        <StatCard label="This month" value={formatMoney(thisMonth)} tone="red" />
        <StatCard label="Categories used" value={String(categories.length)} tone="slate" />
        <StatCard label="All-time expenses" value={formatMoney(expenses.reduce((sum, e) => sum + Number(e.amount), 0))} tone="violet" />
      </div>

      <Card className="mt-4">
        <div className="grid gap-2 border-b border-slate-100 p-4 sm:grid-cols-2 lg:grid-cols-5">
          <div className="relative lg:col-span-2">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input className="input pl-9" placeholder="Search category, description or method" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
          <input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
          <select className="select" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
            <option value="all">All categories</option>
            {categories.map((category) => <option key={category} value={category}>{category}</option>)}
          </select>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title={expenses.length === 0 ? "No expenses recorded" : "No expenses match your filters"}
            description="Record rent, utility bills, transport, salary and other shop expenses here."
            action={<button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>Add expense</button>}
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Category</th>
                  <th>Description</th>
                  <th>Method</th>
                  <th className="text-right">Amount</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((expense) => (
                  <tr key={expense.id}>
                    <td className="whitespace-nowrap text-xs">{formatDate(expense.expenseDate)}</td>
                    <td className="font-medium">{expense.category}</td>
                    <td className="max-w-[260px] truncate text-xs">{expense.description ?? "—"}</td>
                    <td className="text-xs">{expense.paymentMethod}</td>
                    <td className="text-right font-semibold">{formatMoney(expense.amount)}</td>
                    <td>
                      <div className="flex justify-end gap-0.5">
                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => openEdit(expense)}><Icon name="edit" className="h-4 w-4" /></button>
                        <button type="button" className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50" onClick={() => setDeleteTarget(expense)}><Icon name="trash" className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={open}
        title={editingId ? "Edit expense" : "Add expense"}
        onClose={() => setOpen(false)}
        size="md"
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
            <button type="button" className="btn btn-primary" onClick={save} disabled={busy}>{busy ? "Saving…" : "Save expense"}</button>
          </>
        }
      >
        {notice && notice.tone === "error" ? <div className="mb-3"><Alert tone="error">{notice.text}</Alert></div> : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="expense-category">Category *</label>
            <input id="expense-category" className="input" list="expense-categories" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Rent, Utilities, Transport…" />
            <datalist id="expense-categories">
              {["Rent", "Utilities", "Salary", "Transport", "Marketing", "Maintenance", "Office Supplies", ...categories].filter((v, i, a) => a.indexOf(v) === i).map((category) => (
                <option key={category} value={category} />
              ))}
            </datalist>
          </div>
          <div>
            <label className="label" htmlFor="expense-amount">Amount (৳) *</label>
            <input id="expense-amount" type="number" min="0.01" step="0.01" className="input" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          </div>
          <div>
            <label className="label" htmlFor="expense-date">Expense date</label>
            <input id="expense-date" type="date" className="input" value={form.expenseDate} onChange={(e) => setForm({ ...form, expenseDate: e.target.value })} />
          </div>
          <div>
            <label className="label" htmlFor="expense-method">Payment method</label>
            <select id="expense-method" className="select" value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })}>
              {METHODS.map((method) => <option key={method} value={method}>{method}</option>)}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="expense-description">Description</label>
            <textarea id="expense-description" className="textarea" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete expense?"
        message={<p>This expense of <strong>{formatMoney(deleteTarget?.amount ?? 0)}</strong> will be permanently removed and profit recalculated.</p>}
        confirmLabel="Delete expense"
        busy={busy}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
