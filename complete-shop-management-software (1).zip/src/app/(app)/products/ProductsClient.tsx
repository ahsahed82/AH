"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { Category } from "@/db/schema";
import type { ProductRow } from "@/lib/queries";
import { Badge, Card, EmptyState, PageHeader } from "@/components/ui";
import { Alert, ConfirmDialog, Modal } from "@/components/Modal";
import { Icon } from "@/components/icons";
import { api, deleteRequest, fileToDataUrl, jsonBody, putBody } from "@/lib/client";
import { formatMoney, formatQty } from "@/lib/format";

const UNITS = ["pcs", "kg", "gm", "litre", "ml", "pack", "box", "dozen", "bag", "bottle", "meter"];

type FormState = {
  id?: number;
  name: string;
  sku: string;
  barcode: string;
  categoryId: string;
  unit: string;
  purchasePrice: string;
  sellingPrice: string;
  currentStock: string;
  minStock: string;
  imageUrl: string;
  description: string;
  isActive: boolean;
};

const emptyForm: FormState = {
  name: "",
  sku: "",
  barcode: "",
  categoryId: "",
  unit: "pcs",
  purchasePrice: "",
  sellingPrice: "",
  currentStock: "0",
  minStock: "0",
  imageUrl: "",
  description: "",
  isActive: true,
};

function stockStatus(product: ProductRow) {
  const current = Number(product.currentStock);
  const min = Number(product.minStock);
  if (current <= 0) return <Badge tone="red">Out of stock</Badge>;
  if (current <= min) return <Badge tone="amber">Low stock</Badge>;
  return <Badge tone="green">In stock</Badge>;
}

export function ProductsClient({
  products,
  categories,
  initialStock,
  initialCategory,
  initialSearch,
}: {
  products: ProductRow[];
  categories: Category[];
  initialStock: string;
  initialCategory: string;
  initialSearch: string;
}) {
  const router = useRouter();
  const [search, setSearch] = useState(initialSearch);
  const [stockFilter, setStockFilter] = useState(initialStock);
  const [categoryFilter, setCategoryFilter] = useState(initialCategory);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ProductRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [categoryDescription, setCategoryDescription] = useState("");
  const [categoryEditing, setCategoryEditing] = useState<Category | null>(null);
  const [categoryBusy, setCategoryBusy] = useState(false);
  const [categoryError, setCategoryError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return products.filter((product) => {
      if (categoryFilter !== "all" && String(product.categoryId ?? "") !== categoryFilter) return false;
      const current = Number(product.currentStock);
      const min = Number(product.minStock);
      if (stockFilter === "low" && !(current > 0 && current <= min)) return false;
      if (stockFilter === "out" && current > 0) return false;
      if (stockFilter === "in" && current <= min) return false;
      if (!term) return true;
      return [product.name, product.sku, product.barcode ?? "", product.categoryName ?? ""]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [products, search, stockFilter, categoryFilter]);

  function openAdd() {
    setForm({ ...emptyForm, categoryId: categories[0] ? String(categories[0].id) : "" });
    setFormOpen(true);
    setNotice(null);
  }

  function openEdit(product: ProductRow) {
    setForm({
      id: product.id,
      name: product.name,
      sku: product.sku,
      barcode: product.barcode ?? "",
      categoryId: product.categoryId ? String(product.categoryId) : "",
      unit: product.unit,
      purchasePrice: product.purchasePrice,
      sellingPrice: product.sellingPrice,
      currentStock: product.currentStock,
      minStock: product.minStock,
      imageUrl: product.imageUrl ?? "",
      description: product.description ?? "",
      isActive: product.isActive,
    });
    setFormOpen(true);
    setNotice(null);
  }

  async function handleImage(file: File | null) {
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file);
      setForm((prev) => ({ ...prev, imageUrl: dataUrl }));
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Image could not be read." });
    }
  }

  async function saveProduct() {
    setSaving(true);
    setNotice(null);
    try {
      const payload = {
        name: form.name,
        sku: form.sku,
        barcode: form.barcode || null,
        categoryId: form.categoryId ? Number(form.categoryId) : null,
        unit: form.unit,
        purchasePrice: form.purchasePrice || 0,
        sellingPrice: form.sellingPrice || 0,
        minStock: form.minStock || 0,
        imageUrl: form.imageUrl || null,
        description: form.description || null,
        isActive: form.isActive,
        ...(form.id ? {} : { currentStock: form.currentStock || 0 }),
      };
      const result = await api<{ message: string }>(
        form.id ? `/api/products/${form.id}` : "/api/products",
        form.id ? putBody(payload) : jsonBody(payload),
      );
      setNotice({ tone: "success", text: result.message });
      setFormOpen(false);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not save product." });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const result = await api<{ message: string }>(`/api/products/${deleteTarget.id}`, deleteRequest());
      setNotice({ tone: "success", text: result.message });
      setDeleteTarget(null);
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Could not delete product." });
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  }

  async function saveCategory() {
    setCategoryBusy(true);
    setCategoryError(null);
    try {
      await api(
        categoryEditing ? `/api/categories/${categoryEditing.id}` : "/api/categories",
        categoryEditing
          ? putBody({ name: categoryName, description: categoryDescription })
          : jsonBody({ name: categoryName, description: categoryDescription }),
      );
      setCategoryName("");
      setCategoryDescription("");
      setCategoryEditing(null);
      router.refresh();
    } catch (error) {
      setCategoryError(error instanceof Error ? error.message : "Could not save category.");
    } finally {
      setCategoryBusy(false);
    }
  }

  async function removeCategory(category: Category) {
    setCategoryBusy(true);
    setCategoryError(null);
    try {
      await api(`/api/categories/${category.id}`, deleteRequest());
      router.refresh();
    } catch (error) {
      setCategoryError(error instanceof Error ? error.message : "Could not delete category.");
    } finally {
      setCategoryBusy(false);
    }
  }

  const lowCount = products.filter((p) => Number(p.currentStock) > 0 && Number(p.currentStock) <= Number(p.minStock)).length;
  const outCount = products.filter((p) => Number(p.currentStock) <= 0).length;

  return (
    <div>
      <PageHeader
        title="Products & Categories"
        subtitle={`${products.length} product(s) · ${lowCount} low stock · ${outCount} out of stock`}
        actions={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setCategoryOpen(true)}>
              <Icon name="inventory" className="h-4 w-4" /> Categories
            </button>
            <button type="button" className="btn btn-primary" onClick={openAdd}>
              <Icon name="plus" className="h-4 w-4" /> Add Product
            </button>
          </>
        }
      />

      {notice ? (
        <div className="mb-4">
          <Alert tone={notice.tone}>{notice.text}</Alert>
        </div>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Icon name="search" className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              className="input pl-9"
              placeholder="Search product name, SKU or barcode…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <select className="select sm:w-44" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
            <option value="all">All categories</option>
            {categories.map((category) => (
              <option key={category.id} value={String(category.id)}>
                {category.name}
              </option>
            ))}
          </select>
          <select className="select sm:w-40" value={stockFilter} onChange={(e) => setStockFilter(e.target.value)}>
            <option value="all">All stock</option>
            <option value="in">In stock</option>
            <option value="low">Low stock</option>
            <option value="out">Out of stock</option>
          </select>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title={products.length === 0 ? "No products yet" : "No products match your filters"}
            description={
              products.length === 0
                ? "Add your first product to start selling. SKU must be unique; barcode is optional."
                : "Try clearing the search or selecting another category."
            }
            action={
              <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>
                Add Product
              </button>
            }
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Unit</th>
                  <th className="text-right">Purchase</th>
                  <th className="text-right">Selling</th>
                  <th className="text-right">Stock</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((product) => (
                  <tr key={product.id}>
                    <td>
                      <div className="flex items-center gap-2">
                        {product.imageUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={product.imageUrl} alt="" className="h-8 w-8 rounded object-cover" />
                        ) : (
                          <span className="grid h-8 w-8 place-items-center rounded bg-slate-100 text-[10px] font-bold text-slate-500">
                            {product.name.slice(0, 2).toUpperCase()}
                          </span>
                        )}
                        <div className="min-w-0">
                          <p className="truncate font-semibold text-slate-900">{product.name}</p>
                          <p className="text-[11px] text-slate-500">
                            SKU {product.sku}
                            {product.barcode ? ` · ${product.barcode}` : ""}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td>{product.categoryName ?? <span className="text-slate-400">—</span>}</td>
                    <td className="lowercase">{product.unit}</td>
                    <td className="text-right">{formatMoney(product.purchasePrice)}</td>
                    <td className="text-right font-medium">{formatMoney(product.sellingPrice)}</td>
                    <td className="text-right font-semibold">
                      {formatQty(product.currentStock)}
                    </td>
                    <td>{stockStatus(product)}</td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          className="btn btn-ghost btn-sm"
                          onClick={() => openEdit(product)}
                          aria-label={`Edit ${product.name}`}
                        >
                          <Icon name="edit" className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                          onClick={() => setDeleteTarget(product)}
                          aria-label={`Delete ${product.name}`}
                        >
                          <Icon name="trash" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="px-4 py-3 text-[11px] text-slate-500">
          Stock is never edited from this form after creation. Use Inventory → Stock Adjustment so every change
          leaves an audit trail.
        </div>
      </Card>

      <Modal
        open={formOpen}
        title={form.id ? "Edit product" : "Add product"}
        description="Opening stock is only set when creating a product."
        onClose={() => setFormOpen(false)}
        size="lg"
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setFormOpen(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-primary" onClick={saveProduct} disabled={saving}>
              {saving ? "Saving…" : form.id ? "Save changes" : "Add product"}
            </button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="label" htmlFor="product-name">Product name *</label>
            <input
              id="product-name"
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Fresh Miniket Rice 5kg"
            />
          </div>
          <div>
            <label className="label" htmlFor="product-sku">SKU *</label>
            <input
              id="product-sku"
              className="input"
              value={form.sku}
              onChange={(e) => setForm({ ...form, sku: e.target.value.toUpperCase() })}
              placeholder="RICE-5KG"
            />
          </div>
          <div>
            <label className="label" htmlFor="product-barcode">Barcode</label>
            <input
              id="product-barcode"
              className="input"
              value={form.barcode}
              onChange={(e) => setForm({ ...form, barcode: e.target.value })}
              placeholder="Scan or type barcode"
            />
          </div>
          <div>
            <label className="label" htmlFor="product-category">Category</label>
            <select
              id="product-category"
              className="select"
              value={form.categoryId}
              onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
            >
              <option value="">Uncategorised</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="product-unit">Unit</label>
            <select
              id="product-unit"
              className="select"
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
            >
              {UNITS.map((unit) => (
                <option key={unit} value={unit}>{unit}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="product-purchase">Purchase price (৳)</label>
            <input
              id="product-purchase"
              type="number"
              min="0"
              step="0.01"
              className="input"
              value={form.purchasePrice}
              onChange={(e) => setForm({ ...form, purchasePrice: e.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="product-selling">Selling price (৳)</label>
            <input
              id="product-selling"
              type="number"
              min="0"
              step="0.01"
              className="input"
              value={form.sellingPrice}
              onChange={(e) => setForm({ ...form, sellingPrice: e.target.value })}
            />
          </div>
          {!form.id ? (
            <div>
              <label className="label" htmlFor="product-opening">Opening stock</label>
              <input
                id="product-opening"
                type="number"
                min="0"
                step="0.001"
                className="input"
                value={form.currentStock}
                onChange={(e) => setForm({ ...form, currentStock: e.target.value })}
              />
            </div>
          ) : (
            <div>
              <label className="label">Current stock</label>
              <input className="input" value={formatQty(form.currentStock)} disabled />
            </div>
          )}
          <div>
            <label className="label" htmlFor="product-min">Minimum stock alert</label>
            <input
              id="product-min"
              type="number"
              min="0"
              step="0.001"
              className="input"
              value={form.minStock}
              onChange={(e) => setForm({ ...form, minStock: e.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="product-image">Product image (optional, max 1.5 MB)</label>
            <div className="flex items-center gap-3">
              <input
                id="product-image"
                type="file"
                accept="image/*"
                className="input"
                onChange={(e) => handleImage(e.target.files?.[0] ?? null)}
              />
              {form.imageUrl ? (
                <>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={form.imageUrl} alt="Preview" className="h-10 w-10 rounded object-cover" />
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm text-rose-600"
                    onClick={() => setForm({ ...form, imageUrl: "" })}
                  >
                    Remove
                  </button>
                </>
              ) : null}
            </div>
            <p className="muted mt-1">Images are stored inside the database and are included in backups.</p>
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="product-description">Description</label>
            <textarea
              id="product-description"
              className="textarea"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>
          {form.id ? (
            <label className="flex items-center gap-2 text-sm text-slate-700 sm:col-span-2">
              <input
                type="checkbox"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                className="h-4 w-4 rounded border-slate-300"
              />
              Product is active (available in POS)
            </label>
          ) : null}
        </div>
        {notice && notice.tone === "error" ? (
          <div className="mt-3"><Alert tone="error">{notice.text}</Alert></div>
        ) : null}
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete product?"
        message={
          <>
            <p>
              <strong>{deleteTarget?.name}</strong> will be permanently deleted along with its stock movement
              history.
            </p>
            <p className="mt-2 text-xs text-slate-500">
              Products that already appear in sales or purchases cannot be deleted; mark them inactive instead.
            </p>
          </>
        }
        confirmLabel="Delete product"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
      />

      <Modal
        open={categoryOpen}
        title="Category management"
        description="Categories help you filter products and reports."
        onClose={() => setCategoryOpen(false)}
        size="md"
      >
        {categoryError ? <div className="mb-3"><Alert tone="error">{categoryError}</Alert></div> : null}
        <div className="space-y-2">
          <div className="flex gap-2">
            <input
              className="input"
              placeholder="New category name"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
            />
            <button type="button" className="btn btn-primary" onClick={saveCategory} disabled={categoryBusy}>
              {categoryEditing ? "Update" : "Add"}
            </button>
          </div>
          {categoryEditing ? (
            <button
              type="button"
              className="text-xs text-slate-500 underline"
              onClick={() => {
                setCategoryEditing(null);
                setCategoryName("");
                setCategoryDescription("");
              }}
            >
              Cancel edit
            </button>
          ) : null}
        </div>
        <ul className="mt-4 divide-y divide-slate-100 rounded-lg border border-slate-200">
          {categories.length === 0 ? (
            <li className="px-3 py-4 text-sm text-slate-500">No categories yet.</li>
          ) : (
            categories.map((category) => (
              <li key={category.id} className="flex items-center justify-between gap-2 px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-800">{category.name}</p>
                  {category.description ? <p className="truncate text-[11px] text-slate-500">{category.description}</p> : null}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => {
                      setCategoryEditing(category);
                      setCategoryName(category.name);
                      setCategoryDescription(category.description ?? "");
                    }}
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm text-rose-600"
                    onClick={() => removeCategory(category)}
                    disabled={categoryBusy}
                  >
                    Delete
                  </button>
                </div>
              </li>
            ))
          )}
        </ul>
      </Modal>
    </div>
  );
}
