import { db } from "@/db";
import { requireApiUser } from "@/lib/auth";
import { expenses } from "@/db/schema";
import { getExpenses } from "@/lib/queries";
import {
  fail,
  ok,
  optionalText,
  parseMoney,
  parsePaymentMethod,
  readJson,
  requiredText,
} from "@/lib/api-helpers";
import { inputDateToDate, money } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    return ok({
      expenses: await getExpenses({
        search: url.searchParams.get("search") ?? undefined,
        from: url.searchParams.get("from") ?? undefined,
        to: url.searchParams.get("to") ?? undefined,
        category: url.searchParams.get("category") ?? undefined,
      }),
    });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson(request);
    const category = requiredText(body.category, "Expense category", 80);
    const amount = parseMoney(body.amount, "Amount", { min: 0.01 });
    const [created] = await db
      .insert(expenses)
      .values({
        category,
        amount: money(amount),
        expenseDate: inputDateToDate(typeof body.expenseDate === "string" ? body.expenseDate : null),
        description: optionalText(body.description, 500),
        paymentMethod: parsePaymentMethod(body.paymentMethod),
      })
      .returning();
    return ok({ expense: created, message: "Expense recorded." }, 201);
  } catch (error) {
    return fail(error);
  }
}
