import { num } from "@/lib/format";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function ok<T>(data: T, status = 200) {
  return Response.json(data as object, { status });
}

export function fail(error: unknown) {
  if (error instanceof ApiError) {
    return Response.json({ error: error.message }, { status: error.status });
  }
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  if (/duplicate key/i.test(message)) {
    if (/sku/i.test(message)) return Response.json({ error: "This SKU already exists." }, { status: 409 });
    if (/barcode/i.test(message)) return Response.json({ error: "This barcode already exists." }, { status: 409 });
    if (/invoice/i.test(message)) return Response.json({ error: "This invoice number already exists." }, { status: 409 });
    return Response.json({ error: "A record with the same unique value already exists." }, { status: 409 });
  }
  if (/foreign key/i.test(message)) {
    return Response.json(
      { error: "This record is used by other transactions and cannot be removed." },
      { status: 409 },
    );
  }
  console.error("[api]", error);
  return Response.json({ error: message }, { status: 500 });
}

export async function readJson<T = Record<string, unknown>>(request: Request): Promise<T> {
  // CSRF protection: browsers cannot send application/json from cross-site
  // HTML forms, so requiring it blocks forged state-changing requests now
  // that session cookies use SameSite=None for embedded preview support.
  const contentType = request.headers.get("content-type") ?? "";
  if (!contentType.toLowerCase().includes("application/json")) {
    throw new ApiError("Unsupported request format. Please use the app buttons.", 415);
  }
  try {
    return (await request.json()) as T;
  } catch {
    throw new ApiError("Invalid request body.");
  }
}

export function requiredText(value: unknown, label: string, max = 200): string {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text) throw new ApiError(`${label} is required.`);
  if (text.length > max) throw new ApiError(`${label} is too long.`);
  return text;
}

export function optionalText(value: unknown, max = 4000): string | null {
  if (typeof value !== "string") return null;
  const text = value.trim();
  if (!text) return null;
  return text.slice(0, max);
}

export function parseMoney(value: unknown, label: string, options?: { min?: number; max?: number }): number {
  const parsed = typeof value === "number" ? value : Number.parseFloat(String(value ?? ""));
  if (!Number.isFinite(parsed)) throw new ApiError(`${label} must be a valid number.`);
  const min = options?.min ?? 0;
  const max = options?.max ?? 1_000_000_000;
  if (parsed < min) throw new ApiError(`${label} cannot be less than ${min}.`);
  if (parsed > max) throw new ApiError(`${label} is unrealistically large.`);
  return Math.round(parsed * 100) / 100;
}

export function parseQuantity(value: unknown, label: string, options?: { allowZero?: boolean }): number {
  const parsed = typeof value === "number" ? value : Number.parseFloat(String(value ?? ""));
  if (!Number.isFinite(parsed)) throw new ApiError(`${label} must be a valid number.`);
  if (options?.allowZero ? parsed < 0 : parsed <= 0) {
    throw new ApiError(`${label} must be greater than zero.`);
  }
  if (parsed > 1_000_000) throw new ApiError(`${label} is too large.`);
  return Math.round(parsed * 1000) / 1000;
}

export function parseId(value: unknown, label = "Record"): number {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  if (!Number.isInteger(parsed) || parsed <= 0) throw new ApiError(`${label} not found.`, 404);
  return parsed;
}

export function idFromParam(params: { id: string }): number {
  return parseId(params.id);
}

export const PAYMENT_METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Card", "Bank Transfer", "Credit"] as const;

export function parsePaymentMethod(value: unknown): string {
  const text = typeof value === "string" ? value.trim() : "Cash";
  return text && text.length <= 40 ? text : "Cash";
}

export function isPaymentMethod(value: string): boolean {
  return (PAYMENT_METHODS as readonly string[]).includes(value);
}

export { num };
