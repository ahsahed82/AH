import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import {
  adminExists,
  createSession,
  hashPassword,
  validateCredentials,
} from "@/lib/auth";
import { fail, ok, optionalText, readJson } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

/**
 * First-run administrator creation. Works only while no admin account exists,
 * so the shop owner claims the account on their very first visit.
 */
export async function POST(request: Request) {
  try {
    if (await adminExists()) {
      return Response.json(
        { error: "An administrator account already exists. Please sign in." },
        { status: 409 },
      );
    }
    const body = await readJson<Record<string, unknown>>(request);
    const { username, password } = validateCredentials(body.username, body.password);
    const name = optionalText(body.name, 80) ?? "Administrator";

    const user = await db.transaction(async (tx) => {
      const [existing] = await tx.select({ id: adminUsers.id }).from(adminUsers).limit(1);
      if (existing) throw new Error("An administrator account already exists. Please sign in.");
      const [created] = await tx
        .insert(adminUsers)
        .values({ username, name, passwordHash: hashPassword(password) })
        .returning({ id: adminUsers.id, username: adminUsers.username, name: adminUsers.name });
      return created;
    });

    await createSession(user.id);
    return ok(
      { user, message: "Administrator account created. You are now signed in." },
      201,
    );
  } catch (error) {
    return fail(error);
  }
}
