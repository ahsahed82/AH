import { eq, inArray } from "drizzle-orm";
import { requireApiUser } from "@/lib/auth";
import { db } from "@/db";
import { customers, products, saleItems, sales, stockMovements } from "@/db/schema";
import { getSalesList } from "@/lib/queries";
import {
  ApiError,
  fail,
  ok,
  optionalText,
  parseId,
  parseMoney,
  parsePaymentMethod,
  parseQuantity,
  readJson,
} from "@/lib/api-helpers";
import { getSettings } from "@/lib/settings";
import { inputDateToDate, money, qty, round2 } from "@/lib/format";

export const dynamic = "force-dynamic";

type RawItem = { productId?: unknown; quantity?: unknown; unitPrice?: unknown };

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const url = new URL(request.url);
    const rows = await getSalesList({
      search: url.searchParams.get("search") ?? undefined,
      from: url.searchParams.get("from") ?? undefined,
      to: url.searchParams.get("to") ?? undefined,
      method: url.searchParams.get("method") ?? undefined,
    });
    return ok({ sales: rows });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if (!auth.ok) return auth.response;
  try {
    const body = await readJson<Record<string, unknown>>(request);
    const rawItems = Array.isArray(body.items) ? (body.items as RawItem[]) : [];
    if (rawItems.length === 0) throw new ApiError("Add at least one product to the sale.");

    const parsedItems = rawItems.map((item, index) => ({
      productId: parseId(item.productId, `Product on line ${index + 1}`),
      quantity: parseQuantity(item.quantity, `Quantity on line ${index + 1}`),
      unitPrice: parseMoney(item.unitPrice, `Unit price on line ${index + 1}`),
    }));

    const productIds = [...new Set(parsedItems.map((i) => i.productId))];
    const discount = parseMoney(body.discount ?? 0, "Discount");
    const paidInput = parseMoney(body.paidAmount ?? body.paid ?? 0, "Paid amount");
    const paymentMethod = parsePaymentMethod(body.paymentMethod);
    const note = optionalText(body.note, 500);
    const saleDate = inputDateToDate(typeof body.saleDate === "string" ? body.saleDate : null);
    const customerId = body.customerId ? Number(body.customerId) : null;
    if (customerId !== null && !Number.isInteger(customerId)) throw new ApiError("Invalid customer.");

    const settingsRow = await getSettings();
    const prefix = settingsRow.invoicePrefix || "INV";

    const created = await db.transaction(async (tx) => {
      const productRows = await tx
        .select()
        .from(products)
        .where(inArray(products.id, productIds))
        .for("update");
      if (productRows.length !== productIds.length) throw new ApiError("One of the selected products no longer exists.");

      if (customerId) {
        const [customer] = await tx.select({ id: customers.id }).from(customers).where(eq(customers.id, customerId)).limit(1);
        if (!customer) throw new ApiError("Selected customer was not found.");
      }

      const subtotal = round2(
        parsedItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0),
      );
      if (discount > subtotal) throw new ApiError("Discount cannot be greater than the subtotal.");
      const total = round2(subtotal - discount);
      const paid = round2(Math.min(paidInput, total));
      const due = round2(total - paid);
      if (!customerId && due > 0) {
        throw new ApiError(
          "A walk-in sale cannot have a due amount. Select a customer to record this sale with due, or receive full payment.",
        );
      }

      // Aggregate duplicate product lines so stock is validated once.
      const needed = new Map<number, number>();
      for (const item of parsedItems) {
        needed.set(item.productId, round2((needed.get(item.productId) ?? 0) + item.quantity));
      }
      for (const [productId, quantity] of needed) {
        const product = productRows.find((p) => p.id === productId);
        if (!product) throw new ApiError("Product not found.");
        if (Number(product.currentStock) < quantity) {
          throw new ApiError(
            `Insufficient stock for ${product.name}. Available: ${Number(product.currentStock)} ${product.unit}.`,
          );
        }
      }

      const [sale] = await tx
        .insert(sales)
        .values({
          invoiceNo: `TMP-${crypto.randomUUID()}`,
          customerId,
          saleDate,
          subtotal: money(subtotal),
          discount: money(discount),
          total: money(total),
          paid: money(paid),
          due: money(due),
          paymentMethod,
          note,
        })
        .returning();

      const stamp = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Dhaka",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      })
        .format(saleDate)
        .replaceAll("-", "");
      const invoiceNo = `${prefix}-${stamp}-${String(sale.id).padStart(4, "0")}`;

      await tx.update(sales).set({ invoiceNo }).where(eq(sales.id, sale.id));

      for (const item of parsedItems) {
        const product = productRows.find((p) => p.id === item.productId);
        if (!product) throw new ApiError("Product not found.");
        await tx.insert(saleItems).values({
          saleId: sale.id,
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          quantity: qty(item.quantity),
          unitPrice: money(item.unitPrice),
          costPrice: product.purchasePrice,
          total: money(round2(item.quantity * item.unitPrice)),
        });
        const updated = await tx
          .update(products)
          .set({
            currentStock: qty(Number(product.currentStock) - item.quantity),
            updatedAt: new Date(),
          })
          .where(eq(products.id, product.id))
          .returning({ id: products.id });
        if (updated.length === 0) throw new ApiError("Stock could not be updated. Please try again.");
        product.currentStock = qty(Number(product.currentStock) - item.quantity);

        await tx.insert(stockMovements).values({
          productId: product.id,
          type: "sale",
          quantity: qty(-item.quantity),
          referenceType: "sale",
          referenceId: sale.id,
          referenceNo: invoiceNo,
          note: `Sale to ${customerId ? "customer" : "walk-in customer"}`,
        });
      }

      return { id: sale.id, invoiceNo, total, paid, due };
    });

    return ok({ ...created, message: `Sale ${created.invoiceNo} saved successfully.` }, 201);
  } catch (error) {
    return fail(error);
  }
}
